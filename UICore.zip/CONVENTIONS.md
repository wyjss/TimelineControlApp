# UICore 代码与使用约定

本文档是 UICore 的代码风格和接入约定。目录、公共 API、主题机制或构建方式变化时，必须在同一次修改中更新本文档。

## 1. 边界与目录

- UICore 只包含跨项目通用能力，不包含具体业务名称、流程和数据。
- 公共头文件放在 `include/UICore/<领域>`，实现放在 `src/<领域>`。
- QML 放在 `qml`，图标放在 `assets`，资源清单放在 `resources`。
- 只建立 `UICore::Core` 和 `UICore::Quick` 两个编译库，不为 Fields、Style、Forms、Shell、Task 等源码逻辑层单独建立 target。
- `UICore::Core` 包含公共 C++ 类型，只依赖 Qt Core/Gui；`UICore::Quick` 包含全部 QML、主题、图标和资源初始化，并公开依赖 `UICore::Core`。
- 源码依赖方向保持为 `Fields/Style -> Forms -> Shell`，Task 不依赖 Forms 或 Shell；C++ 层不依赖 QML 文件或 Qt Quick 类型。

## 2. C++

- 使用 C++17、Qt 5.14 和一个根命名空间 `UICore`；CMake target 名称不形成 `Core` 或 `Quick` C++ 子命名空间。
- 类型使用 `PascalCase`，函数和变量使用 `camelCase`，私有成员使用 `m_` 前缀。
- 指针和引用写作 `Type *value`、`const Type &value`。
- `.cpp` 首先包含自己的公共头文件，随后按 Qt、标准库分组。
- UICore 的 `.cpp` 在所有 include 后统一使用 `using namespace UICore;`，不使用文件级 `namespace UICore { ... }` 包裹；命名空间自由函数在定义处保留 `UICore::` 限定。
- 对外头文件统一使用安装式路径，例如：

```cpp
#include <UICore/Forms/AppForm.h>
```

- 类和函数的大括号独占一行；短小的单语句判断可以省略大括号。
- setter 先比较新旧值，无变化立即返回；变化后只发送必要的 `...Changed` 信号。
- 暴露给 QML 的稳定属性使用 `Q_PROPERTY`，按语义选择 `FINAL`、`CONSTANT` 和 `NOTIFY`。
- 通用视觉、皮肤和布局枚举统一定义在 `UICore::UiStyle`，使用 `enum class` 和显式数值。
- 表面语义、文本语义和排版角色是封闭的公共集合，分别使用 `UiStyle::SurfaceTone`、`UiStyle::TextTone` 和 `UiStyle::TypographyRole`。
- 字段渲染类型定义为 `AppField::Kind`；Form 结构枚举定义在 `UICore::UiForm`，不放入 `UiStyle`。
- `BaseField` 是字段数据和约束的唯一来源；`AppField` 只保存 UI 描述，并通过内部或外部 `BaseField` 代理公共字段属性，不复制两份状态。
- `valueType` 决定字段写回类型，`editorHint` 决定推荐编辑器，`options` 提供候选值，`allowCustomValue` 决定候选值之外的内容是否可输入。
- 枚举默认行为在实际消费位置通过 `switch/default` 表达，不为单次使用增加归一化辅助函数。
- QObject 所有权优先使用 parent；观察外部 QObject 时使用 `QPointer`。
- 实现保持最小，不为单次调用增加辅助函数，不做与当前修改无关的格式化。
- `.h`、`.cpp` 使用 UTF-8；修改已有注释时保持原注释语言。

## 3. QML

- 文件名和公共组件名使用 `App` 前缀及 `PascalCase`，根对象统一使用 `id: root`。
- 使用 4 空格缩进；属性、只读派生属性、信号、函数、视觉子项依次组织。
- 可派生状态使用 `readonly property`，避免保存可由其他状态计算出的重复数据。
- 通用交互事件使用明确语义，如 `...Requested`、`...Edited`、`...Triggered`。
- 通用 Style 枚举通过 `import UICore.Style 1.0` 使用，例如 `UiStyle.LayoutMode.Horizontal`；QML 不重复定义。
- 通用字段通过 `import UICore.Fields 1.0` 创建，字段类型使用 `AppField.Kind.TextField`。
- `AppField.sourceField` 绑定外部 `BaseField` 后直接读写该对象；不在 QML 或 C++ 中增加额外同步层。
- `AppSelect` 只负责封闭选择；允许自定义值的候选输入由 `AppTextField` 提供。
- `AppFieldControl` 只负责渲染单个 `AppField`；`AppFormContent` 负责 Form/Section 组织并复用 `AppFieldControl`。
- 没有字段 schema 的静态 UI 直接使用 Base 控件，不为其额外创建 `AppField`。
- 纯 QML 的通用 Style 枚举属性使用 `int` 保存，默认值和赋值均使用对应的 `UiStyle` 枚举常量。
- 皮肤只替换固定视觉角色对应的主题 Token 值；颜色、尺寸等内部 Token 名称继续使用字符串。
- 尺寸、颜色、字体、圆角和动画必须读取主题 Token，组件内部不得为缺失主题或缺失 Token 提供字面值回退。
- QML 资源路径是公共接口，修改 `.qrc` alias 前必须确认兼容性。

### 主题

主题由应用窗口持有一次。当前 `Theme.AppTheme` 同时作为标准主题和默认主题：

```qml
ApplicationWindow {
    property QtObject appTheme: Theme.AppTheme {}
}
```

- UICore 组件从所属 `ApplicationWindow` 自动读取 `appTheme`。
- 不在组件上声明 `theme` 属性，不编写 `theme: root.theme`，不向 Loader 项手动注入主题。
- `appTheme` 是必需依赖，且必须完整提供 `colors`、`density`、`metrics`、`shell`、`shape`、`motion`、`typography`、`controlStyles`、`icons` 和 `z`。
- 自定义组件需要直接读取 Token 时使用窗口主题，不提供本地回退值；缺少主题或 Token 时应直接暴露 QML 错误。
- 主题组件会保留最后一次取得的有效窗口主题，避免 `AppPopup` 关闭时视觉项暂时脱离窗口而丢失主题；业务组件不需要手动传递主题。
- Qt Quick Controls Style 由宿主程序选择；UICore 不在库内部强制设置。示例程序使用 `Basic`。

## 4. 接入

```cmake
add_subdirectory(path/to/UICore)
target_link_libraries(MyApp PRIVATE UICore::Quick)
```

创建 `QQmlEngine` 前初始化静态资源：

```cpp
#include <UICore/UICore.h>

UICore::initialize();
```

常用 QML 导入：

```qml
import UICore.Forms 1.0
import UICore.Fields 1.0
import UICore.Style 1.0

import "qrc:/UICore/qml" as Ui
import "qrc:/UICore/qml/components/base" as Base
import "qrc:/UICore/qml/components/field" as Field
import "qrc:/UICore/qml/theme" as Theme
```

## 5. 修改检查

- 新文件是否位于正确领域，是否引入了业务耦合。
- 新公共 C++ 文件是否加入 `UICore::Core`；仅负责 QML 注册或资源初始化的 C++ 文件是否加入 `UICore::Quick`。
- 新 QML、JS 或图标是否加入对应 `.qrc`。
- 是否保持公共 include 路径和 QML alias 稳定。
- 是否误加了逐层主题传递或重复状态。
- 约定发生变化时是否同步更新本文档。
- 公共 QML/C++ 用法发生变化时是否同步更新 `CHANGELIST.md`。
- 至少完成 Release 构建；涉及 QML 时再完成一次启动检查。
