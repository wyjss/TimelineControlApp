# UICore 代码与使用约定

本文档是 UICore 的代码风格和接入约定。目录、公共 API、主题机制或构建方式变化时，必须在同一次修改中更新本文档。

## 1. 边界与目录

- UICore 只包含跨项目通用能力，不包含具体业务名称、流程和数据。
- 公共头文件放在 `include/UICore/<领域>`，实现放在 `src/<领域>`。
- QML 放在 `qml`，图标放在 `assets`，资源清单放在 `resources`。
- 依赖方向保持为 `Foundation/Quick -> Forms -> Shell`，`Task` 独立；禁止反向依赖。

## 2. C++

- 使用 C++17、Qt 5.14 和 `UICore` 命名空间。
- 类型使用 `PascalCase`，函数和变量使用 `camelCase`，私有成员使用 `m_` 前缀。
- 指针和引用写作 `Type *value`、`const Type &value`。
- `.cpp` 首先包含自己的公共头文件，随后按 Qt、标准库分组。
- 对外头文件统一使用安装式路径，例如：

```cpp
#include <UICore/Forms/AppForm.h>
```

- 类和函数的大括号独占一行；短小的单语句判断可以省略大括号。
- setter 先比较新旧值，无变化立即返回；变化后只发送必要的 `...Changed` 信号。
- 暴露给 QML 的稳定属性使用 `Q_PROPERTY`，按语义选择 `FINAL`、`CONSTANT` 和 `NOTIFY`。
- QObject 所有权优先使用 parent；观察外部 QObject 时使用 `QPointer`。
- 实现保持最小，不为单次调用增加辅助函数，不做与当前修改无关的格式化。
- `.h`、`.cpp` 使用 UTF-8；修改已有注释时保持原注释语言。

## 3. QML

- 文件名和公共组件名使用 `App` 前缀及 `PascalCase`，根对象统一使用 `id: root`。
- 使用 4 空格缩进；属性、只读派生属性、信号、函数、视觉子项依次组织。
- 可派生状态使用 `readonly property`，避免保存可由其他状态计算出的重复数据。
- 通用交互事件使用明确语义，如 `...Requested`、`...Edited`、`...Triggered`。
- 封闭行为选项使用 `Enums.<类型>.<值>`，例如 `Enums.LayoutMode.Horizontal`；不直接使用对应字符串。
- 尺寸、颜色、字体、圆角和动画优先读取主题 Token；字面值只作为无主题时的回退值。
- QML 资源路径是公共接口，修改 `.qrc` alias 前必须确认兼容性。

### 主题

主题由应用窗口持有一次：

```qml
ApplicationWindow {
    property QtObject appTheme: Theme.AppTheme {}
}
```

- UICore 组件从所属 `ApplicationWindow` 自动读取 `appTheme`。
- 不在组件上声明 `theme` 属性，不编写 `theme: root.theme`，不向 Loader 项手动注入主题。
- 自定义组件需要直接读取 Token 时，使用窗口主题并提供回退值。
- Qt Quick Controls Style 由宿主程序选择；UICore 不在库内部强制设置。示例程序使用 `Basic`。

## 4. 接入

```cmake
add_subdirectory(path/to/UICore)
target_link_libraries(MyApp PRIVATE UICore::UICore)
```

创建 `QQmlEngine` 前初始化静态资源：

```cpp
#include <UICore/UICore.h>

UICore::initialize();
```

常用 QML 导入：

```qml
import "qrc:/UICore/qml" as Ui
import "qrc:/UICore/qml/components/base" as Base
import "qrc:/UICore/qml/theme" as Theme
```

## 5. 修改检查

- 新文件是否位于正确领域，是否引入了业务耦合。
- 新公共 C++ 文件是否加入对应 CMake target。
- 新 QML、JS 或图标是否加入对应 `.qrc`。
- 是否保持公共 include 路径和 QML alias 稳定。
- 是否误加了逐层主题传递或重复状态。
- 约定发生变化时是否同步更新本文档。
- 至少完成 Release 构建；涉及 QML 时再完成一次启动检查。
