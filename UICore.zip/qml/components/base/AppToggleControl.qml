import QtQuick 2.14
import QtQuick.Controls 2.14
import QtQuick.Window 2.14
import UICore.Style 1.0
import "internal" as Internal
import "internal/AppThemeUtils.js" as ThemeUtils

Item {
    id: root

    property bool checked: false
    property bool enabled: true

    readonly property QtObject applicationWindowTheme: ApplicationWindow.window && ApplicationWindow.window.appTheme
        ? ApplicationWindow.window.appTheme
        : null
    readonly property QtObject windowTheme: Window.window && Window.window.appTheme
        ? Window.window.appTheme
        : null
    readonly property QtObject resolvedTheme: themeContext.theme
    readonly property bool interactionHovered: toggleTap.hovered
    readonly property bool interactionActive: false

    Internal.AppThemeContext {
        id: themeContext

        applicationWindowTheme: root.applicationWindowTheme
        windowTheme: root.windowTheme
    }

    signal toggled(bool nextChecked)

    function colorValue(name) {
        return ThemeUtils.colorValue(resolvedTheme, name)
    }

    function commit(nextChecked) {
        if (checked === nextChecked)
            return

        checked = nextChecked
        toggled(nextChecked)
    }

    implicitWidth: 42
    implicitHeight: 24
    opacity: enabled ? 1 : 0.68

    AppSurface {
        anchors.fill: parent
        surfaceTone: root.checked
            ? UiStyle.SurfaceTone.Highlight
            : UiStyle.SurfaceTone.Section
        shapeRole: UiStyle.ShapeRole.Pill
        active: root.checked
        hoveredState: toggleTap.hovered
        interactive: root.enabled
        strokeWidth: root.checked ? 0 : 1
        fillOverride: root.checked
            ? root.colorValue("highlightFill")
            : root.colorValue("section")
        borderOverride: root.checked
            ? root.colorValue("highlightFill")
            : root.colorValue("border")
        hoverOverlayOpacity: 0.08
        activeOverlayOpacity: 0.06
    }

    Rectangle {
        width: 18
        height: 18
        radius: 9
        y: 3
        x: root.checked ? parent.width - width - 3 : 3
        color: root.colorValue("inverseText")
        border.width: 1
        border.color: root.checked
            ? Qt.rgba(0, 0, 0, 0.08)
            : root.colorValue("border")

        Behavior on x {
            NumberAnimation {
                duration: root.resolvedTheme.motion.durationStandard
                easing.type: root.resolvedTheme.motion.easingStandard
            }
        }
    }

    Internal.AppTapRegion {
        id: toggleTap

        anchors.fill: parent
        enabled: root.enabled
        onTapped: root.commit(!root.checked)
        onDoubleTapped: root.commit(!root.checked)
    }
}
