import QtQuick 2.14
import QtQuick.Controls 2.14
import QtQuick.Layouts 1.14
import QtQuick.Window 2.14
import UICore.Style 1.0
import "internal" as Internal

Popup {
    id: root

    default property alias popupContent: contentColumn.data

    property int surfaceTone: UiStyle.SurfaceTone.SurfaceOverlay
    property real cornerRadius: -1
    property int strokeWidth: 1
    property int revealOrigin: Item.Center
    property real revealOffsetY: 0
    property color overlayColor: resolvedTheme.colors.scrim
    property real overlayOpacity: 0.44
    property bool showModalOverlay: modal
    property bool elevated: true
    property color shadowColor: resolvedTheme.colors.scrim
    property real shadowOpacity: 0.32
    property int shadowSize: resolvedTheme.density.controlGap
    property bool draggable: false
    property Item dragHandle: null
    property bool constrainDragToParent: true
    readonly property QtObject applicationWindowTheme: ApplicationWindow.window && ApplicationWindow.window.appTheme
        ? ApplicationWindow.window.appTheme
        : null
    readonly property QtObject windowTheme: Window.window && Window.window.appTheme
        ? Window.window.appTheme
        : null
    readonly property QtObject resolvedTheme: themeContext.theme
    readonly property real popupRevealOffset: resolvedTheme.motion.transitionOffset
    readonly property real popupRevealStartScale: 0.985
    readonly property real contentRevealProgress: motionState.contentRevealProgress
    readonly property real overlayRevealProgress: motionState.overlayRevealProgress
    readonly property real resolvedCornerRadius: cornerRadius >= 0
        ? cornerRadius
        : resolvedTheme.shape.overlayRadius

    Internal.AppThemeContext {
        id: themeContext

        applicationWindowTheme: root.applicationWindowTheme
        windowTheme: root.windowTheme
    }

    padding: resolvedTheme.density.panePadding
    spacing: resolvedTheme.density.paneContentSpacing
    opacity: root.contentRevealProgress
    scale: root.popupRevealStartScale + (1 - root.popupRevealStartScale) * root.contentRevealProgress
    transformOrigin: root.revealOrigin

    QtObject {
        id: motionState

        property real contentRevealProgress: root.visible ? 1 : 0
        property real overlayRevealProgress: root.visible && root.showModalOverlay ? 1 : 0
    }

    MouseArea {
        id: dragArea

        parent: root.dragHandle
        anchors.fill: parent
        enabled: root.draggable && !!root.dragHandle && !!root.parent
        acceptedButtons: Qt.LeftButton
        cursorShape: Qt.SizeAllCursor
        preventStealing: true

        property real pressParentX: 0
        property real pressParentY: 0
        property real popupStartX: 0
        property real popupStartY: 0

        onPressed: {
            var pressPosition = mapToItem(root.parent, mouse.x, mouse.y)
            pressParentX = pressPosition.x
            pressParentY = pressPosition.y
            popupStartX = root.x
            popupStartY = root.y
        }

        onPositionChanged: {
            if (!pressed || !root.parent)
                return

            var currentPosition = mapToItem(root.parent, mouse.x, mouse.y)
            var nextX = popupStartX + currentPosition.x - pressParentX
            var nextY = popupStartY + currentPosition.y - pressParentY

            if (root.constrainDragToParent) {
                nextX = Math.max(0, Math.min(nextX, root.parent.width - root.width))
                nextY = Math.max(0, Math.min(nextY, root.parent.height - root.height))
            }

            root.x = nextX
            root.y = nextY
        }
    }

    function resolvedOverlayColor() {
        return Qt.rgba(overlayColor.r, overlayColor.g, overlayColor.b, overlayOpacity)
    }

    Overlay.modal: Rectangle {
        visible: root.showModalOverlay || opacity > 0.001
        color: root.resolvedOverlayColor()
        opacity: root.showModalOverlay ? root.overlayRevealProgress : 0
    }

    enter: Transition {
        ParallelAnimation {
            NumberAnimation {
                target: motionState
                property: "contentRevealProgress"
                from: 0
                to: 1
                duration: root.resolvedTheme.motion.durationStandard
                easing.type: root.resolvedTheme.motion.easingEmphasized
            }

            NumberAnimation {
                target: motionState
                property: "overlayRevealProgress"
                from: root.showModalOverlay ? 0 : 0
                to: root.showModalOverlay ? 1 : 0
                duration: root.resolvedTheme.motion.durationFast
                easing.type: root.resolvedTheme.motion.easingStandard
            }

            NumberAnimation {
                target: root.contentItem
                property: "y"
                from: root.topPadding + root.revealOffsetY
                to: root.topPadding
                duration: root.resolvedTheme.motion.durationStandard
                easing.type: root.resolvedTheme.motion.easingEmphasized
            }
        }
    }

    exit: Transition {
        ParallelAnimation {
            NumberAnimation {
                target: motionState
                property: "contentRevealProgress"
                from: 1
                to: 0
                duration: root.resolvedTheme.motion.durationFast
                easing.type: root.resolvedTheme.motion.easingStandard
            }

            NumberAnimation {
                target: motionState
                property: "overlayRevealProgress"
                from: root.showModalOverlay ? 1 : 0
                to: 0
                duration: root.resolvedTheme.motion.durationFast
                easing.type: root.resolvedTheme.motion.easingStandard
            }

            NumberAnimation {
                target: root.contentItem
                property: "y"
                from: root.topPadding
                to: root.topPadding + root.revealOffsetY
                duration: root.resolvedTheme.motion.durationFast
                easing.type: root.resolvedTheme.motion.easingStandard
            }
        }
    }

    background: Item {
        Rectangle {
            x: -root.shadowSize
            y: root.shadowSize * 0.5
            width: parent.width + root.shadowSize * 2
            height: parent.height + root.shadowSize * 1.5
            radius: root.resolvedCornerRadius + root.shadowSize
            color: root.shadowColor
            opacity: root.elevated
                ? root.shadowOpacity * 0.34 * root.contentRevealProgress
                : 0
            antialiasing: true
        }

        Rectangle {
            x: -root.shadowSize * 0.5
            y: root.shadowSize * 0.5
            width: parent.width + root.shadowSize
            height: parent.height + root.shadowSize
            radius: root.resolvedCornerRadius + root.shadowSize * 0.5
            color: root.shadowColor
            opacity: root.elevated
                ? root.shadowOpacity * 0.66 * root.contentRevealProgress
                : 0
            antialiasing: true
        }

        AppSurface {
            anchors.fill: parent
            surfaceTone: root.surfaceTone
            shapeRole: UiStyle.ShapeRole.Overlay
            cornerRadius: root.cornerRadius
            strokeWidth: root.strokeWidth
        }
    }

    contentItem: ColumnLayout {
        id: contentColumn

        spacing: root.spacing
    }

    Component.onCompleted: {
        motionState.contentRevealProgress = root.visible ? 1 : 0
        motionState.overlayRevealProgress = root.visible && root.showModalOverlay ? 1 : 0
    }
}
