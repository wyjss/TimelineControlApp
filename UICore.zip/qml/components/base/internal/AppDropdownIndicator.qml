import QtQuick 2.14

Canvas {
    id: root

    property color strokeColor: "#97a3b6"
    property bool expanded: false
    property int transitionDuration: 180
    property int transitionEasing: Easing.OutCubic

    width: 10
    height: 10
    contextType: "2d"
    rotation: expanded ? 180 : 0

    onStrokeColorChanged: requestPaint()
    onWidthChanged: requestPaint()
    onHeightChanged: requestPaint()

    onPaint: {
        var ctx = getContext("2d")
        var inset = Math.max(1.6, width * 0.22)
        var topY = height * 0.34

        ctx.clearRect(0, 0, width, height)
        ctx.strokeStyle = strokeColor
        ctx.lineWidth = 1.6
        ctx.lineCap = "round"
        ctx.lineJoin = "round"
        ctx.beginPath()
        ctx.moveTo(inset, topY)
        ctx.lineTo(width * 0.5, height - inset)
        ctx.lineTo(width - inset, topY)
        ctx.stroke()
    }

    Behavior on strokeColor {
        ColorAnimation {
            duration: root.transitionDuration
            easing.type: root.transitionEasing
        }
    }

    Behavior on rotation {
        NumberAnimation {
            duration: root.transitionDuration
            easing.type: root.transitionEasing
        }
    }
}
