import QtQuick 2.14
import UICore.Style 1.0
import ".." as Base

Base.AppSurface {
    id: root

    property string text: ""
    property bool selected: false
    property bool highlighted: false
    property int optionHeight: 36

    signal triggered()

    Accessible.role: Accessible.ListItem
    Accessible.name: text
    Accessible.selectable: true
    Accessible.selected: selected
    Accessible.onPressAction: {
        if (enabled)
            triggered()
    }

    implicitHeight: optionHeight
    surfaceTone: selected
        ? UiStyle.SurfaceTone.Highlight
        : UiStyle.SurfaceTone.Ghost
    shapeRole: UiStyle.ShapeRole.Control
    active: selected
    hoveredState: optionTap.hovered
    interactive: enabled
    strokeWidth: highlighted ? 1 : 0
    fillOverride: selected
        ? colorValue("highlightSoft")
        : (highlighted ? colorValue("windowAccent") : "transparent")
    borderOverride: highlighted
        ? colorValue("highlightText")
        : "transparent"
    hoverOverlayColorOverride: colorValue("highlightText")
    hoverOverlayOpacity: selected ? 0 : 0.08
    activeOverlayOpacity: selected ? 0.04 : 0

    Rectangle {
        width: 3
        height: parent.height - 16
        radius: width / 2
        anchors.left: parent.left
        anchors.leftMargin: 10
        anchors.verticalCenter: parent.verticalCenter
        color: root.colorValue("highlightText")
        opacity: root.selected ? 1 : (root.highlighted ? 0.56 : (optionTap.hovered ? 0.24 : 0))

        Behavior on opacity {
            NumberAnimation {
                duration: root.resolvedTheme.motion.durationFast
                easing.type: root.resolvedTheme.motion.easingStandard
            }
        }
    }

    Base.AppText {
        anchors.left: parent.left
        anchors.leftMargin: 22
        anchors.right: parent.right
        anchors.rightMargin: 14
        anchors.verticalCenter: parent.verticalCenter
        text: root.text
        styleRole: UiStyle.TypographyRole.BodyM
        textTone: root.selected
            ? UiStyle.TextTone.Accent
            : UiStyle.TextTone.Primary
        elide: Text.ElideRight
    }

    AppTapRegion {
        id: optionTap

        anchors.fill: parent
        enabled: root.enabled
        takeFocusOnPress: false
        onTapped: root.triggered()
    }
}
