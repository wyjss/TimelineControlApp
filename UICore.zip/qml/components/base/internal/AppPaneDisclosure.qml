import QtQuick 2.14

Item {
    id: root

    property var control
    property bool expanded: true

    readonly property bool resolvedAnimated: control.animated
    readonly property int resolvedDuration: control.transitionDuration
    readonly property int resolvedEasing: control.transitionEasing
    readonly property int resolvedEmphasizedEasing: control.resolvedTheme.motion.easingEmphasized
    readonly property int buttonSize: control.densityValue("controlHeightSm")
    readonly property int iconSize: Math.max(11, Math.round(buttonSize * 0.36))
    readonly property bool hovered: disclosureTap.hovered

    property color iconColor: hovered
        ? controlColor("highlightText")
        : controlColor("subtleText")

    signal toggleRequested(bool nextExpanded)

    function controlColor(name) {
        return control.colorValue(name)
    }

    objectName: "paneDisclosure"
    implicitWidth: buttonSize
    implicitHeight: buttonSize

    Behavior on iconColor {
        enabled: root.resolvedAnimated
        ColorAnimation {
            duration: root.resolvedDuration
            easing.type: root.resolvedEasing
        }
    }

    Rectangle {
        anchors.fill: parent
        radius: root.control.shapeValue("controlRadius")
        color: root.controlColor("highlightSoft")
        opacity: root.hovered ? 0.72 : 0
        antialiasing: true

        Behavior on opacity {
            enabled: root.resolvedAnimated
            NumberAnimation {
                duration: root.resolvedDuration
                easing.type: root.resolvedEasing
            }
        }
    }

    Canvas {
        id: chevronCanvas

        anchors.centerIn: parent
        width: root.iconSize
        height: root.iconSize
        rotation: root.expanded ? 0 : -90
        contextType: "2d"

        onWidthChanged: requestPaint()
        onHeightChanged: requestPaint()

        Behavior on rotation {
            enabled: root.resolvedAnimated
            NumberAnimation {
                duration: root.resolvedDuration
                easing.type: root.resolvedEmphasizedEasing
            }
        }

        Connections {
            target: root

            function onIconColorChanged() {
                chevronCanvas.requestPaint()
            }
        }

        onPaint: {
            var ctx = getContext("2d")
            var inset = Math.max(1.8, width * 0.18)
            var topY = height * 0.34
            var midY = height * 0.66

            ctx.clearRect(0, 0, width, height)
            ctx.strokeStyle = root.iconColor
            ctx.lineWidth = Math.max(1.8, width * 0.15)
            ctx.lineCap = "round"
            ctx.lineJoin = "round"
            ctx.beginPath()
            ctx.moveTo(inset, topY)
            ctx.lineTo(width * 0.5, midY)
            ctx.lineTo(width - inset, topY)
            ctx.stroke()
        }
    }

    AppTapRegion {
        id: disclosureTap

        anchors.fill: parent
        onTapped: root.toggleRequested(!root.expanded)
    }
}
