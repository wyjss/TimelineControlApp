import QtQuick 2.14

QtObject {
    id: root

    property QtObject applicationWindowTheme: null
    property QtObject windowTheme: null
    readonly property QtObject currentTheme: applicationWindowTheme
        ? applicationWindowTheme
        : windowTheme
    property QtObject theme: null

    onCurrentThemeChanged: {
        if (currentTheme)
            theme = currentTheme
    }

    Component.onCompleted: {
        if (currentTheme)
            theme = currentTheme
    }
}
