import QtQuick 2.14
import QtQuick.Controls 2.14
import QtQuick.Window 2.14
import UICore.Style 1.0
import "internal" as Internal
import "internal/AppThemeUtils.js" as ThemeUtils

Button {
    id: root

    property int variant: UiStyle.ButtonVariant.Secondary
    property int size: UiStyle.ButtonSize.Medium
    property string contentAlignment: "center"

    property int minWidth: 0
    property string iconName: ""
    property url iconSource: ""
    property string iconSymbol: ""

    property bool animated: true
    property bool animateScale: animated

    readonly property QtObject applicationWindowTheme: ApplicationWindow.window && ApplicationWindow.window.appTheme
        ? ApplicationWindow.window.appTheme
        : null
    readonly property QtObject windowTheme: Window.window && Window.window.appTheme
        ? Window.window.appTheme
        : null
    readonly property QtObject resolvedTheme: themeContext.theme

    Internal.AppThemeContext {
        id: themeContext

        applicationWindowTheme: root.applicationWindowTheme
        windowTheme: root.windowTheme
    }

    readonly property bool activeState: checked || highlighted
    readonly property bool disabledState: !enabled
    readonly property bool hoverState: hovered && enabled
    readonly property bool pressedState: down && enabled
    readonly property bool emphasisState: activeState || hoverState || pressedState
    readonly property bool hasIcon: iconName.length > 0 || iconSource.toString().length > 0 || iconSymbol.length > 0
    readonly property var resolvedSizeSpec: sizeSpec()
    readonly property var resolvedVariantSpec: variantSpec()
    readonly property int resolvedStrokeWidth: disabledState
        ? resolvedVariantSpec.disabledStrokeWidth
        : (emphasisState ? resolvedVariantSpec.emphasisStrokeWidth : resolvedVariantSpec.idleStrokeWidth)

    function densityValue(name) {
        return ThemeUtils.densityValue(resolvedTheme, name)
    }

    function metricValue(name) {
        return ThemeUtils.metricValue(resolvedTheme, name)
    }

    function colorValue(name) {
        return ThemeUtils.colorValue(resolvedTheme, name)
    }

    function resolvedColorSpec(colorSpec) {
        return ThemeUtils.resolvedColorSpec(resolvedTheme, colorSpec)
    }

    function sizeSpec() {
        return resolvedTheme.controlStyles.buttonSizeSpec(size)
    }

    function variantSpec() {
        return resolvedTheme.controlStyles.buttonVariantSpec(variant)
    }

    function resolvedHeight() {
        return densityValue(resolvedSizeSpec.heightToken)
    }

    function resolvedPaddingX() {
        return densityValue(resolvedSizeSpec.paddingToken)
    }

    function resolvedIconSize() {
        return metricValue(resolvedSizeSpec.iconToken)
    }

    function resolvedGap() {
        return densityValue("controlGap")
    }

    function resolvedFill() {
        var colorSpec = disabledState
            ? resolvedVariantSpec.disabledFill
            : (activeState ? resolvedVariantSpec.activeFill : resolvedVariantSpec.idleFill)
        return resolvedColorSpec(colorSpec)
    }

    function resolvedBorder() {
        if (disabledState)
            return colorValue("border")

        var colorSpec = emphasisState
            ? resolvedVariantSpec.emphasisBorder
            : resolvedVariantSpec.idleBorder
        return resolvedColorSpec(colorSpec)
    }

    function resolvedIconColor() {
        if (disabledState)
            return colorValue("subtleText")

        var colorSpec = emphasisState
            ? resolvedVariantSpec.emphasisIconColor
            : resolvedVariantSpec.idleIconColor
        return resolvedColorSpec(colorSpec)
    }

    function resolvedHoverOverlayColor() {
        return resolvedColorSpec(resolvedVariantSpec.hoverOverlayColor)
    }

    function resolvedActiveOverlayColor() {
        return resolvedColorSpec(resolvedVariantSpec.activeOverlayColor)
    }

    function resolvedHoverOpacity() {
        return disabledState ? 0 : resolvedVariantSpec.hoverOpacity
    }

    function resolvedActiveOpacity() {
        return disabledState ? 0 : resolvedVariantSpec.activeOpacity
    }

    flat: true
    padding: 0
    hoverEnabled: true
    focusPolicy: Qt.StrongFocus
    implicitHeight: resolvedHeight()
    implicitWidth: Math.max(minWidth, buttonContent.implicitWidth)
    opacity: enabled ? 1 : 0.72

    onPressed: root.forceActiveFocus(Qt.MouseFocusReason)

    background: AppSurface {
        enabled: false
        shapeRole: UiStyle.ShapeRole.Control
        active: root.activeState && root.enabled
        hoveredState: root.hovered
        pressedState: root.down
        interactive: root.enabled
        animated: root.animated
        animateScale: root.animateScale
        strokeWidth: root.resolvedStrokeWidth
        fillOverride: root.resolvedFill()
        borderOverride: root.resolvedBorder()
        hoverOverlayColorOverride: root.resolvedHoverOverlayColor()
        activeOverlayColorOverride: root.resolvedActiveOverlayColor()
        hoverOverlayOpacity: root.resolvedHoverOpacity()
        activeOverlayOpacity: root.resolvedActiveOpacity()
        transitionDuration: root.resolvedTheme.motion.durationStandard
    }

    contentItem: Item {
        id: buttonContent

        implicitWidth: contentRow.implicitWidth + root.resolvedPaddingX() * 2
        implicitHeight: root.resolvedHeight()

        Row {
            id: contentRow

            anchors.verticalCenter: parent.verticalCenter
            x: root.contentAlignment === "start"
                ? root.resolvedPaddingX()
                : Math.max(root.resolvedPaddingX(), (parent.width - width) / 2)
            spacing: root.resolvedGap()

            AppIcon {
                visible: root.hasIcon
                name: root.iconName
                source: root.iconSource
                symbol: root.iconSymbol
                size: root.resolvedIconSize()
                color: root.resolvedIconColor()
            }

            AppText {
                text: root.text
                styleRole: root.resolvedSizeSpec.textStyleRole
                textTone: root.disabledState
                    ? UiStyle.TextTone.Secondary
                    : (root.emphasisState
                        ? root.resolvedVariantSpec.emphasisTextTone
                        : root.resolvedVariantSpec.textTone)
                elide: Text.ElideRight
            }
        }
    }
}
