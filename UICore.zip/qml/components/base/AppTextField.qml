import QtQuick 2.14
import QtQuick.Controls 2.14
import QtQuick.Layouts 1.14
import QtQuick.Window 2.14
import UICore.Style 1.0
import "internal" as Internal
import "internal/AppOptionData.js" as OptionData
import "internal/AppThemeUtils.js" as ThemeUtils

TextField {
    id: root

    property int surfaceTone: UiStyle.SurfaceTone.Section
    property int appearance: UiStyle.ControlAppearance.Filled
    property bool emphasized: false
    property var options: []
    property string textRole: "label"
    property string valueRole: "value"

    property real cornerRadius: -1
    property int controlHeight: densityValue("controlHeightMd")
    property int maxPopupHeight: 220
    property int contentPaddingX: densityValue("controlPaddingXMd")
    property int contentPaddingY: 8
    property int slotSpacing: densityValue("controlGap")
    property real leadingInset: 0
    property real trailingInset: 0

    property alias leadingContent: leadingSlot.data
    property alias trailingContent: trailingSlot.data

    readonly property QtObject applicationWindowTheme: ApplicationWindow.window && ApplicationWindow.window.appTheme
        ? ApplicationWindow.window.appTheme
        : null
    readonly property QtObject windowTheme: Window.window && Window.window.appTheme
        ? Window.window.appTheme
        : null
    readonly property QtObject resolvedTheme: themeContext.theme

    Internal.AppThemeContext {
        id: themeContext

        applicationWindowTheme: root.applicationWindowTheme
        windowTheme: root.windowTheme
    }

    readonly property var resolvedInputChromeSpec: resolvedTheme.controlStyles.inputChromeSpec(
        appearance,
        hasSelection
    )
    readonly property real leadingSlotWidth: leadingSlot.childrenRect.width > 0
        ? leadingSlot.childrenRect.width + slotSpacing
        : 0
    readonly property real trailingSlotWidth: trailingSlot.childrenRect.width > 0
        ? trailingSlot.childrenRect.width + slotSpacing
        : 0
    readonly property var resolvedOptions: options && options.length !== undefined ? options : []
    readonly property bool hasOptions: resolvedOptions.length > 0
    readonly property bool popupVisible: optionsPopup.visible
    readonly property real optionsIndicatorWidth: hasOptions ? 12 + slotSpacing : 0
    readonly property bool hasSelection: selectionStart >= 0
        && selectionEnd >= 0
        && selectionStart !== selectionEnd
    readonly property bool ghostAppearance: resolvedInputChromeSpec.ghost
    readonly property bool interactionHovered: fieldHoverHandler.hovered
    readonly property bool interactionActive: activeFocus || emphasized || hasSelection || popupVisible

    function densityValue(name) {
        return ThemeUtils.densityValue(resolvedTheme, name)
    }

    function typographyValue(name) {
        return ThemeUtils.typographyValue(resolvedTheme, name)
    }

    function colorValue(name) {
        return ThemeUtils.colorValue(resolvedTheme, name)
    }

    selectByMouse: true
    implicitHeight: controlHeight
    color: enabled
        ? colorValue("text")
        : colorValue("disabledText")
    placeholderTextColor: enabled
        ? colorValue("subtleText")
        : colorValue("disabledText")
    selectedTextColor: colorValue("inverseText")
    selectionColor: colorValue("highlightFill")

    font.family: typographyValue("familySans")
    font.pixelSize: Number(typographyValue("bodyM"))
    font.weight: Number(typographyValue("weightRegular"))

    leftPadding: contentPaddingX + leadingInset + leadingSlotWidth
    rightPadding: contentPaddingX + trailingInset + trailingSlotWidth + optionsIndicatorWidth
    topPadding: contentPaddingY
    bottomPadding: contentPaddingY

    background: AppSurface {
        enabled: false
        surfaceTone: root.ghostAppearance ? UiStyle.SurfaceTone.Ghost : root.surfaceTone
        shapeRole: root.resolvedInputChromeSpec.shapeRole
        active: root.enabled && !root.ghostAppearance && root.interactionActive
        hoveredState: root.enabled && !root.ghostAppearance && root.interactionHovered
        strokeWidth: root.enabled && root.interactionActive
            ? root.resolvedInputChromeSpec.activeStrokeWidth
            : root.resolvedInputChromeSpec.idleStrokeWidth
        cornerRadius: root.cornerRadius
        fillOverride: root.enabled || root.ghostAppearance
            ? undefined
            : root.colorValue("disabledFill")
        borderOverride: root.enabled || root.ghostAppearance
            ? undefined
            : root.colorValue("disabledBorder")
        hoverOverlayOpacity: root.resolvedInputChromeSpec.hoverOverlayOpacity
        activeOverlayOpacity: root.resolvedInputChromeSpec.activeOverlayOpacity
    }

    HoverHandler {
        id: fieldHoverHandler
        enabled: root.enabled
    }

    // Raw accessory slots keep the field generic for future search, filter, and picker variants.
    Item {
        id: leadingSlot
        z: 1
        width: childrenRect.width
        height: parent.height
        anchors.left: parent.left
        anchors.leftMargin: root.contentPaddingX + root.leadingInset
        anchors.verticalCenter: parent.verticalCenter
        visible: width > 0
        opacity: root.enabled ? 1 : 0.56
    }

    Item {
        id: trailingSlot
        z: 1
        width: childrenRect.width
        height: parent.height
        anchors.right: optionsIndicator.visible ? optionsIndicator.left : parent.right
        anchors.rightMargin: optionsIndicator.visible
            ? root.slotSpacing
            : root.contentPaddingX + root.trailingInset
        anchors.verticalCenter: parent.verticalCenter
        visible: width > 0
        opacity: root.enabled ? 1 : 0.56
    }

    Item {
        id: optionsIndicator
        z: 2
        width: 12
        height: parent.height
        anchors.right: parent.right
        anchors.rightMargin: root.contentPaddingX + root.trailingInset
        anchors.verticalCenter: parent.verticalCenter
        visible: root.hasOptions

        Internal.AppDropdownIndicator {
            anchors.centerIn: parent
            expanded: root.popupVisible
            strokeColor: !root.enabled
                ? root.colorValue("disabledText")
                : root.interactionActive
                ? root.colorValue("highlightText")
                : root.colorValue("subtleText")
            transitionDuration: root.resolvedTheme.motion.durationStandard
            transitionEasing: root.resolvedTheme.motion.easingStandard
        }

        MouseArea {
            anchors.fill: parent
            anchors.margins: -6
            enabled: root.enabled && !root.readOnly
            acceptedButtons: Qt.LeftButton
            onClicked: root.popupVisible ? optionsPopup.close() : optionsPopup.open()
        }
    }

    AppPopup {
        id: optionsPopup
        objectName: "appTextFieldOptionsPopup"

        parent: root
        x: 0
        y: root.height + 6
        width: Math.max(root.width, 180)
        padding: 6
        spacing: 0
        modal: false
        focus: false
        showModalOverlay: false
        surfaceTone: UiStyle.SurfaceTone.Surface
        closePolicy: Popup.CloseOnEscape | Popup.CloseOnPressOutsideParent
        cornerRadius: root.cornerRadius

        AppScrollPane {
            id: optionsScroll

            objectName: "appTextFieldOptionsScroll"
            Layout.fillWidth: true
            Layout.preferredHeight: Math.min(contentLayout.implicitHeight, root.maxPopupHeight)
            contentSpacing: 4
            showEdgeHints: false

            Repeater {
                model: root.resolvedOptions

                delegate: Internal.AppDropdownOption {
                    readonly property var optionValue: OptionData.optionValue(modelData, root.valueRole)

                    Layout.fillWidth: true
                    optionHeight: root.controlHeight
                    enabled: root.enabled && !root.readOnly
                    text: OptionData.optionLabel(modelData, root.textRole)
                    selected: OptionData.valuesEqual(optionValue, root.text)
                    onTriggered: {
                        root.text = optionValue !== undefined && optionValue !== null
                            ? String(optionValue)
                            : ""
                        root.cursorPosition = root.length
                        optionsPopup.close()
                        root.forceActiveFocus(Qt.MouseFocusReason)
                    }
                }
            }
        }
    }

}
