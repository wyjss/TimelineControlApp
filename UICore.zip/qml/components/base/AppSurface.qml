import QtQuick 2.14
import UICore.Style 1.0
import "internal" as Internal

Internal.AppControlBase {
    id: root

    surfaceTone: UiStyle.SurfaceTone.Surface
}
