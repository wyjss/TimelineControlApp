import QtQuick 2.14
import QtQuick.Controls 2.14
import QtQuick.Layouts 1.14
import QtQuick.Window 2.14
import UICore.Style 1.0
import "internal" as Internal
import "internal/AppOptionData.js" as OptionData
import "internal/AppThemeUtils.js" as ThemeUtils

Internal.AppControlBase {
    id: root

    property var options: []
    property var value: undefined

    property string textRole: "label"
    property string valueRole: "value"
    property string placeholderText: ""
    property int appearance: UiStyle.ControlAppearance.Filled
    property bool emphasized: false

    property int controlHeight: densityValue("controlHeightMd")
    property int optionHeight: controlHeight
    property int contentPaddingX: densityValue("controlPaddingXMd")
    property int slotSpacing: densityValue("controlGap")
    property int popupMinWidth: 0
    property int popupMaxWidth: 320
    property int maxPopupHeight: 220
    property real leadingInset: 0
    property real trailingInset: 0

    property alias leadingContent: leadingSlot.data
    property alias trailingContent: trailingSlot.data

    readonly property var resolvedOptions: options && options.length !== undefined ? options : []
    readonly property int currentIndex: OptionData.indexOfValue(resolvedOptions, value, valueRole)
    readonly property var currentOption: currentIndex >= 0 ? resolvedOptions[currentIndex] : null
    readonly property string currentLabel: currentOption !== null
        ? OptionData.optionLabel(currentOption, textRole)
        : ""
    readonly property bool popupVisible: dropdownPopup.visible
    readonly property real leadingSlotWidth: leadingSlot.childrenRect.width > 0
        ? leadingSlot.childrenRect.width + slotSpacing
        : 0
    readonly property real trailingSlotWidth: trailingSlot.childrenRect.width > 0
        ? trailingSlot.childrenRect.width + slotSpacing
        : 0
    readonly property int indicatorWidth: 12
    readonly property real desiredPopupWidth: Math.max(
        width,
        Math.min(popupMaxWidth, Math.max(popupMinWidth, measuredPopupWidth()))
    )
    readonly property real popupBoundaryWidth: resolvedPopupBoundaryWidth()
    readonly property real resolvedPopupWidth: popupBoundaryWidth > 0
        ? Math.min(desiredPopupWidth, popupBoundaryWidth)
        : desiredPopupWidth
    readonly property real resolvedPopupX: boundedPopupX()
    readonly property var resolvedInputChromeSpec: resolvedTheme.controlStyles.inputChromeSpec(
        appearance,
        false
    )
    readonly property bool ghostAppearance: resolvedInputChromeSpec.ghost
    readonly property bool interactionHovered: fieldHoverHandler.hovered
    readonly property bool interactionActive: popupVisible || activeFocus || emphasized

    signal valueSelected(var nextValue)

    function typographyValue(name) {
        return ThemeUtils.typographyValue(resolvedTheme, name)
    }

    function measuredPopupWidth() {
        var widest = currentLabel.length > 0
            ? selectFontMetrics.advanceWidth(currentLabel)
            : selectFontMetrics.advanceWidth(placeholderText)

        for (var i = 0; i < resolvedOptions.length; ++i)
            widest = Math.max(widest, selectFontMetrics.advanceWidth(OptionData.optionLabel(resolvedOptions[i], textRole)))

        return Math.ceil(widest + 60)
    }

    function popupBoundaryItem() {
        return Window.window && Window.window.contentItem
            ? Window.window.contentItem
            : null
    }

    function resolvedPopupBoundaryWidth() {
        var boundary = popupBoundaryItem()
        return boundary && boundary.width > 0 ? boundary.width : 0
    }

    function boundedPopupX() {
        var boundary = popupBoundaryItem()
        if (!boundary || !(boundary.width > 0))
            return 0

        var mapped = root.mapToItem(boundary, 0, 0)
        var nextX = 0

        if (mapped.x + nextX + resolvedPopupWidth > boundary.width)
            nextX = boundary.width - mapped.x - resolvedPopupWidth

        if (mapped.x + nextX < 0)
            nextX = -mapped.x

        return nextX
    }

    function commitOption(optionData) {
        var nextValue = OptionData.optionValue(optionData, valueRole)
        root.value = nextValue
        root.valueSelected(nextValue)
        popupState.closingFromOptionCommit = true
        dropdownPopup.close()
    }

    surfaceTone: UiStyle.SurfaceTone.Section
    implicitWidth: 180
    implicitHeight: controlHeight

    background: AppSurface {
        enabled: false
        surfaceTone: root.ghostAppearance ? UiStyle.SurfaceTone.Ghost : root.surfaceTone
        shapeRole: root.resolvedInputChromeSpec.shapeRole
        active: root.enabled && !root.ghostAppearance && root.interactionActive
        hoveredState: root.enabled && !root.ghostAppearance && root.interactionHovered
        strokeWidth: root.enabled && root.interactionActive
            ? root.resolvedInputChromeSpec.activeStrokeWidth
            : root.resolvedInputChromeSpec.idleStrokeWidth
        cornerRadius: root.cornerRadius
        fillOverride: root.enabled || root.ghostAppearance
            ? undefined
            : root.colorValue("disabledFill")
        borderOverride: root.enabled || root.ghostAppearance
            ? undefined
            : root.colorValue("disabledBorder")
        hoverOverlayOpacity: root.resolvedInputChromeSpec.hoverOverlayOpacity
        activeOverlayOpacity: root.resolvedInputChromeSpec.activeOverlayOpacity
    }

    contentItem: Item {
        implicitWidth: root.implicitWidth
        implicitHeight: root.controlHeight

        Item {
            id: leadingSlot
            z: 1
            width: childrenRect.width
            height: parent.height
            anchors.left: parent.left
            anchors.leftMargin: root.contentPaddingX + root.leadingInset
            anchors.verticalCenter: parent.verticalCenter
            visible: width > 0
            opacity: root.enabled ? 1 : 0.56
        }

        Item {
            id: indicatorWrap
            z: 1
            width: root.indicatorWidth
            height: parent.height
            anchors.right: parent.right
            anchors.rightMargin: root.contentPaddingX + root.trailingInset
            anchors.verticalCenter: parent.verticalCenter

            Internal.AppDropdownIndicator {
                anchors.centerIn: parent
                expanded: root.popupVisible
                strokeColor: !root.enabled
                    ? root.colorValue("disabledText")
                    : root.interactionActive
                    ? root.colorValue("highlightText")
                    : root.colorValue("subtleText")
                transitionDuration: root.resolvedTheme.motion.durationStandard
                transitionEasing: root.resolvedTheme.motion.easingStandard
            }
        }

        Item {
            id: trailingSlot
            z: 1
            width: childrenRect.width
            height: parent.height
            anchors.right: indicatorWrap.left
            anchors.rightMargin: width > 0 ? root.slotSpacing : 0
            anchors.verticalCenter: parent.verticalCenter
            visible: width > 0
            opacity: root.enabled ? 1 : 0.56
        }

        AppText {
            z: 1
            anchors.left: leadingSlot.visible ? leadingSlot.right : parent.left
            anchors.leftMargin: root.contentPaddingX + (leadingSlot.visible ? root.slotSpacing + root.leadingInset : root.leadingInset)
            anchors.right: trailingSlot.visible ? trailingSlot.left : indicatorWrap.left
            anchors.rightMargin: root.slotSpacing
            anchors.verticalCenter: parent.verticalCenter
            text: root.currentLabel.length > 0 ? root.currentLabel : root.placeholderText
            styleRole: UiStyle.TypographyRole.BodyM
            textTone: root.currentLabel.length > 0
                ? UiStyle.TextTone.Primary
                : UiStyle.TextTone.Secondary
            colorOverride: root.enabled
                ? undefined
                : root.colorValue("disabledText")
            elide: Text.ElideRight
        }

        MouseArea {
            id: controlTapArea

            anchors.fill: parent
            enabled: root.enabled
            acceptedButtons: Qt.LeftButton
            hoverEnabled: true
            preventStealing: true
            onClicked: {
                root.forceActiveFocus(Qt.MouseFocusReason)

                if (popupState.suppressNextControlToggle) {
                    popupState.suppressNextControlToggle = false
                    suppressToggleReset.stop()
                    return
                }

                if (dropdownPopup.visible) {
                    popupState.closingFromControlToggle = true
                    dropdownPopup.close()
                } else {
                    dropdownPopup.open()
                }
            }
        }
    }

    resources: [
        QtObject {
            id: popupState

            property bool suppressNextControlToggle: false
            property bool closingFromControlToggle: false
            property bool closingFromOptionCommit: false
        },

        HoverHandler {
            id: fieldHoverHandler
            enabled: root.enabled
        },

        FontMetrics {
            id: selectFontMetrics

            font.family: typographyValue("familySans")
            font.pixelSize: Number(typographyValue("bodyM"))
            font.weight: Number(typographyValue("weightRegular"))
        },

        Timer {
            id: suppressToggleReset

            interval: 120
            repeat: false
            onTriggered: popupState.suppressNextControlToggle = false
        },

        AppPopup {
            id: dropdownPopup
            objectName: "appSelectPopup"

            parent: root
            x: root.resolvedPopupX
            y: root.height + 6
            width: root.resolvedPopupWidth
            padding: 6
            spacing: 0
            modal: false
            focus: true
            showModalOverlay: false
            surfaceTone: UiStyle.SurfaceTone.Surface
            closePolicy: Popup.CloseOnEscape | Popup.CloseOnPressOutsideParent
            cornerRadius: root.cornerRadius
            onClosed: {
                if (popupState.closingFromControlToggle) {
                    popupState.closingFromControlToggle = false
                    return
                }

                if (popupState.closingFromOptionCommit) {
                    popupState.closingFromOptionCommit = false
                    return
                }

                popupState.suppressNextControlToggle = true
                suppressToggleReset.restart()
            }

            ListView {
                id: dropdownList

                objectName: "appSelectListView"
                Layout.fillWidth: true
                Layout.preferredHeight: Math.min(contentHeight, root.maxPopupHeight)
                implicitHeight: Math.min(contentHeight, root.maxPopupHeight)
                width: parent ? parent.width : root.resolvedPopupWidth
                clip: true
                boundsBehavior: Flickable.StopAtBounds
                interactive: contentHeight > height + 1
                model: root.resolvedOptions
                spacing: 4
                currentIndex: root.currentIndex

                ScrollBar.vertical: ScrollBar {
                    policy: ScrollBar.AsNeeded
                }

                delegate: Internal.AppDropdownOption {
                    id: optionItem
                    objectName: "appSelectOption_" + index

                    readonly property var optionData: modelData
                    width: dropdownList.width
                    height: root.optionHeight
                    optionHeight: root.optionHeight
                    text: OptionData.optionLabel(optionData, root.textRole)
                    selected: OptionData.valuesEqual(
                        OptionData.optionValue(optionData, root.valueRole),
                        root.value
                    )
                    enabled: root.enabled
                    onTriggered: root.commitOption(optionData)
                }
            }
        }
    ]
}
