import QtQuick 2.14
import QtQuick.Controls 2.14
import QtQuick.Window 2.14
import QtGraphicalEffects 1.14
import "internal" as Internal

Control {
    id: root

    property string name: ""
    property url source: ""
    property string symbol: fallbackSymbol()
    readonly property QtObject applicationWindowTheme: ApplicationWindow.window && ApplicationWindow.window.appTheme
        ? ApplicationWindow.window.appTheme
        : null
    readonly property QtObject windowTheme: Window.window && Window.window.appTheme
        ? Window.window.appTheme
        : null
    readonly property QtObject resolvedTheme: themeContext.theme
    property color color: resolvedTheme.colors.text
    property bool animateColor: true
    property int size: resolvedTheme.metrics.iconSizeMd
    property bool tintSource: true

    readonly property url resolvedSource: source.toString().length > 0
        ? source
        : (name.length > 0 ? resolvedTheme.icons.icon(name) : "")

    Internal.AppThemeContext {
        id: themeContext

        applicationWindowTheme: root.applicationWindowTheme
        windowTheme: root.windowTheme
    }

    function fallbackSymbol() {
        return name.length > 0 ? name.charAt(0).toUpperCase() : ""
    }

    padding: 0
    width: size
    height: size
    implicitWidth: size
    implicitHeight: size

    background: null

    Behavior on color {
        enabled: root.animateColor
        ColorAnimation {
            duration: root.resolvedTheme.motion.durationStandard
            easing.type: root.resolvedTheme.motion.easingStandard
        }
    }

    contentItem: Item {
        implicitWidth: root.size
        implicitHeight: root.size

        Image {
            id: iconImage
            anchors.fill: parent
            source: root.resolvedSource
            fillMode: Image.PreserveAspectFit
            smooth: true
            mipmap: true
            visible: status === Image.Ready
            layer.enabled: root.tintSource && status === Image.Ready
            layer.effect: ColorOverlay {
                color: root.color
            }
        }

        Text {
            anchors.centerIn: parent
            visible: iconImage.status !== Image.Ready
            text: root.symbol
            color: root.color
            font.family: root.resolvedTheme.typography.familySans
            font.pixelSize: Math.max(10, Math.round(root.size * 0.72))
            font.weight: root.resolvedTheme.typography.weightBold
        }
    }
}
