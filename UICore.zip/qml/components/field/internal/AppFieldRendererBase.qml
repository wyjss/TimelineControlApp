import QtQuick 2.14
import QtQuick.Layouts 1.14
import UICore.Style 1.0
import "../../base" as Base

Base.AppFieldBlock {
    id: root

    property var fieldBridge: null

    readonly property var bridge: fieldBridge
    readonly property int defaultAppearance: inheritedFieldFormContext
        && inheritedFieldFormContext.fieldAppearance !== undefined
        ? inheritedFieldFormContext.fieldAppearance
        : UiStyle.ControlAppearance.Filled

    objectName: bridge ? "field:" + bridge.fieldKey() : ""
    Layout.fillWidth: true
    label: bridge ? String(bridge.fieldValue("label", "")) : ""
    subtitle: bridge ? String(bridge.fieldValue("subtitle", "")) : ""
}
