import QtQuick 2.14
import QtQuick.Layouts 1.14
import QtQml 2.14
import UICore.Style 1.0
import "../../base" as Base

AppFieldRendererBase {
    id: root
    fieldControl: segmentedControl
    fieldContentFillWidth: true

    Base.AppSegmentedControl {
        id: segmentedControl

        Accessible.name: bridge ? String(bridge.fieldValue("label", "")) : ""
        Layout.fillWidth: true
        surfaceTone: bridge
            ? bridge.fieldSurfaceTone(UiStyle.SurfaceTone.Surface)
            : UiStyle.SurfaceTone.Surface
        options: bridge ? bridge.fieldValue("options", []) : []

        onValueSelected: {
            if (bridge)
                bridge.emitValueEdited(nextValue)
        }
    }

    resources: [
        Binding {
            target: segmentedControl
            property: "value"
            value: bridge ? bridge.fieldValue("value", undefined) : undefined
        }
    ]
}
