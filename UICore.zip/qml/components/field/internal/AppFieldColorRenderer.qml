import QtQuick 2.14
import QtQuick.Layouts 1.14
import QtQml 2.14
import UICore.Style 1.0
import "../../base" as Base

AppFieldRendererBase {
    id: root
    fieldControl: colorControl
    fieldContentFillWidth: true

    Base.AppColorControl {
        id: colorControl

        Layout.fillWidth: true
        surfaceTone: bridge
            ? bridge.fieldSurfaceTone(UiStyle.SurfaceTone.Section)
            : UiStyle.SurfaceTone.Section
        placeholderText: bridge
            ? String(bridge.fieldValue("placeholderText", "#A8C7FA"))
            : "#A8C7FA"

        onValueEdited: {
            if (bridge)
                bridge.emitValueEdited(nextValue)
        }
    }

    resources: [
        Binding {
            target: colorControl
            property: "value"
            value: bridge ? bridge.fieldValue("value", "") : ""
        }
    ]
}
