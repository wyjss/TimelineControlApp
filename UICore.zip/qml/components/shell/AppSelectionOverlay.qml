import QtQuick 2.14
import QtQuick.Layouts 1.14
import UICore.Style 1.0
import "../base" as Base

Base.AppPanel {
    id: root

    property var selectionData: ({})

    readonly property string resolvedTitle: selectionData && selectionData.title !== undefined
        ? String(selectionData.title)
        : ""
    readonly property var lines: selectionData && selectionData.lines !== undefined
        ? selectionData.lines
        : []

    function lineValue(lineData, key, fallback) {
        if (lineData !== undefined && lineData !== null && lineData[key] !== undefined)
            return lineData[key]

        return fallback
    }

    compact: true
    surfaceTone: UiStyle.SurfaceTone.Surface
    bodyFillHeight: false
    title: resolvedTitle

    ColumnLayout {
        Layout.fillWidth: true
        spacing: 6

        Repeater {
            model: root.lines

            delegate: Base.AppText {
                Layout.fillWidth: true
                text: String(root.lineValue(modelData, "text", ""))
                styleRole: root.lineValue(
                    modelData,
                    "styleRole",
                    UiStyle.TypographyRole.BodyS
                )
                textTone: root.lineValue(
                    modelData,
                    "textTone",
                    UiStyle.TextTone.Primary
                )
            }
        }
    }
}
