import QtQuick 2.14
import QtQuick.Controls 2.14
import QtQuick.Window 2.14
import "../base" as Base
import "../base/internal" as Internal

Item {
    id: root

    property Component content: null
    property bool opened: false
    property bool autoHideEnabled: false
    property bool autoHideSuspended: false
    property bool autoHideTriggerActive: false
    property bool animated: true
    property int edge: Qt.LeftEdge
    property Item anchorItem: null
    property real paneWidth: resolvedTheme.shell.sidebarWidth
    property real inset: resolvedTheme.shell.shellOverlayMargin
    property real gap: inset
    property int revealDelay: resolvedTheme.motion.shellPanelRevealDelay
    property int hideDelay: resolvedTheme.motion.shellPanelHideDelay

    readonly property Item paneItem: paneLoader.item
    readonly property bool hovered: paneHoverHandler.hovered || bridgeHoverHandler.hovered
    readonly property bool effectiveAutoHideTriggerActive: autoHideTriggerActive || hovered
    readonly property bool rightEdge: edge === Qt.RightEdge
    readonly property real anchorX: anchorItem
        ? (rightEdge ? anchorItem.x : anchorItem.x + anchorItem.width)
        : (rightEdge ? width : 0)
    readonly property QtObject applicationWindowTheme: ApplicationWindow.window && ApplicationWindow.window.appTheme
        ? ApplicationWindow.window.appTheme
        : null
    readonly property QtObject windowTheme: Window.window && Window.window.appTheme
        ? Window.window.appTheme
        : null
    readonly property QtObject resolvedTheme: themeContext.theme

    signal openRequested(bool opened)

    Internal.AppThemeContext {
        id: themeContext

        applicationWindowTheme: root.applicationWindowTheme
        windowTheme: root.windowTheme
    }

    Base.AppAutoHideController {
        enabled: root.autoHideEnabled
        suspended: root.autoHideSuspended
        opened: root.opened
        triggerActive: root.effectiveAutoHideTriggerActive
        revealDelay: root.revealDelay
        hideDelay: root.hideDelay
        onOpenRequested: function(opened) {
            root.openRequested(opened)
        }
    }

    Item {
        id: hoverBridge

        x: root.rightEdge ? root.anchorX - width : root.anchorX
        y: root.inset
        width: root.gap
        height: Math.max(0, parent.height - root.inset * 2)
        visible: root.autoHideEnabled && root.opened

        HoverHandler {
            id: bridgeHoverHandler

            acceptedDevices: PointerDevice.Mouse
        }
    }

    Item {
        id: pane

        x: root.rightEdge
            ? (root.opened ? root.anchorX - width - root.gap : root.anchorX + root.gap)
            : (root.opened ? root.anchorX + root.gap : root.anchorX - width - root.gap)
        y: root.inset
        width: root.paneWidth
        height: Math.max(0, parent.height - root.inset * 2)
        visible: opacity > 0 || root.opened
        opacity: root.opened ? 1 : 0

        Loader {
            id: paneLoader

            anchors.fill: parent
            sourceComponent: root.content
        }

        HoverHandler {
            id: paneHoverHandler

            enabled: root.autoHideEnabled
            acceptedDevices: PointerDevice.Mouse
        }

        Behavior on x {
            enabled: root.animated

            NumberAnimation {
                duration: root.resolvedTheme.motion.durationStandard
                easing.type: root.resolvedTheme.motion.easingStandard
            }
        }

        Behavior on width {
            enabled: root.animated

            NumberAnimation {
                duration: root.resolvedTheme.motion.durationStandard
                easing.type: root.resolvedTheme.motion.easingStandard
            }
        }

        Behavior on opacity {
            enabled: root.animated

            NumberAnimation {
                duration: root.resolvedTheme.motion.durationFast
                easing.type: root.resolvedTheme.motion.easingStandard
            }
        }
    }
}
