import QtQuick 2.14
import QtQuick.Layouts 1.14
import UICore.Style 1.0
import "components/base" as Base
import "components/shell" as Shell

Base.AppBackdrop {
    id: root

    property alias topNavigationBar: topMenuBar
    property alias bottomNavigationBar: bottomMenuBar
    property alias sidebar: leftSidebar
    property alias sidebarPane: leftSidebarPane
    property alias leftPaneContent: leftSidebarPane.content
    property alias leftPanelWidth: leftSidebarPane.paneWidth
    property alias topBarContent: topMenuBar.content
    property alias topBarActions: topMenuBar.trailingContent
    property alias topMenuItems: topMenuBar.menuItems
    property alias activeTopMenuKey: topMenuBar.activeItemKey
    property alias bottomBarContent: bottomMenuBar.content
    property alias bottomBarActions: bottomMenuBar.trailingContent
    property alias bottomMenuItems: bottomMenuBar.menuItems
    property alias activeBottomMenuKey: bottomMenuBar.activeItemKey
    property string applicationTitle: qsTr("应用")
    property bool showBottomBar: (bottomMenuItems && bottomMenuItems.length > 0)
        || bottomBarContent !== null
        || bottomBarActions !== null
    property var navigationItems: []
    property string activeNavigationKey: ""
    property bool sidebarOpen: true
    property bool leftPaneOpen: true
    property bool leftPanelAutoHide: false
    property bool sidebarAutoHideSuspended: false
    property bool sidebarAutoHideTriggerActive: false
    property bool leftPanelAutoHideSuspended: false
    property bool leftPanelAutoHideTriggerActive: false
    property bool rightPanelOpen: false
    property string canvasInteractionState: "idle"
    property string canvasDelegateSource: ""
    property var inspectorObject: null
    property var inspectorData: ({})

    signal navigationRequested(string key)
    signal sidebarOpenRequested(bool open)
    signal leftPaneOpenRequested(bool open)
    signal topMenuItemRequested(string key)
    signal bottomMenuItemRequested(string key)
    signal uiActionRequested(string actionId, var payload)

    readonly property QtObject shellTheme: resolvedTheme.shell
    readonly property int topBarHeight: shellTheme.topBarHeight
    readonly property int bottomBarHeight: shellTheme.bottomBarHeight
    readonly property int railWidth: shellTheme.railWidth
    readonly property real leftContentInset: leftSidebar.occupiedWidth
    readonly property int overlayMargin: shellTheme.shellOverlayMargin
    readonly property int rightPanelWidth: shellTheme.inspectorWidth

    readonly property bool leftPanelAutoHideActive: leftPanelAutoHide && canvasInteractionState === "idle"
    readonly property bool hasInteractiveCanvas: canvasDelegateSource.length > 0

    function focusCanvas() {
        if (canvasLoader.item)
            canvasLoader.item.forceActiveFocus(Qt.OtherFocusReason)
    }

    function requestLeftPaneOpen(open) {
        var nextValue = !!open
        if (leftPaneOpen === nextValue)
            return

        leftPaneOpenRequested(nextValue)
    }

    onLeftPanelAutoHideChanged: {
        if (!leftPanelAutoHideActive)
            requestLeftPaneOpen(true)
    }
    onCanvasInteractionStateChanged: {
        if (!leftPanelAutoHide)
            return

        if (!leftPanelAutoHideActive)
            requestLeftPaneOpen(true)
    }

    function handleInspectorFieldEdited(fieldKey, value) {
        var payload = {
            "fieldKey": fieldKey !== undefined && fieldKey !== null ? String(fieldKey) : ""
        }

        payload.value = value !== undefined && value !== null ? value : null

        uiActionRequested("inspector.fieldEdited", payload)
    }

    sizeToContent: false
    clipContent: true

    ColumnLayout {
        anchors.fill: parent
        spacing: 0

        Shell.AppTopNavigationBar {
            id: topMenuBar

            Layout.fillWidth: true
            Layout.preferredHeight: root.topBarHeight
            title: root.applicationTitle
            onItemTriggered: function(key) {
                root.topMenuItemRequested(key)
            }
        }

        Item {
            Layout.fillWidth: true
            Layout.fillHeight: true

            Shell.AppSidebar {
                id: leftSidebar

                anchors.top: parent.top
                anchors.bottom: parent.bottom
                width: root.railWidth
                z: 4

                opened: root.sidebarOpen
                menuItems: root.navigationItems
                activeItemKey: root.activeNavigationKey
                interactive: autoHideEnabled || root.leftPanelAutoHideActive
                autoHideSuspended: root.sidebarAutoHideSuspended
                autoHideTriggerActive: sidebarEdgeHover.hovered
                    || root.sidebarAutoHideTriggerActive
                onOpenRequested: function(opened) {
                    if (root.sidebarOpen !== opened)
                        root.sidebarOpenRequested(opened)
                }
                onItemTriggered: function(key) {
                    root.navigationRequested(key)
                    root.focusCanvas()
                }
            }

            Item {
                anchors.left: parent.left
                anchors.top: parent.top
                anchors.bottom: parent.bottom
                width: leftSidebar.padding
                visible: leftSidebar.autoHideEnabled
                z: leftSidebar.z

                HoverHandler {
                    id: sidebarEdgeHover

                    acceptedDevices: PointerDevice.Mouse
                }
            }

            Item {
                anchors.fill: parent
                anchors.leftMargin: root.leftContentInset

                Base.AppSurface {
                    id: canvasHost

                    anchors.fill: parent
                    sizeToContent: false
                    clipContent: true
                    surfaceTone: UiStyle.SurfaceTone.Canvas
                    shapeRole: UiStyle.ShapeRole.None
                    strokeWidth: 0

                    TapHandler {
                        enabled: !root.hasInteractiveCanvas
                        acceptedButtons: Qt.LeftButton
                        onTapped: {
                            if (root.leftPanelAutoHideActive)
                                root.requestLeftPaneOpen(false)
                        }
                    }

                    Loader {
                        id: canvasLoader

                        anchors.fill: parent
                        active: root.hasInteractiveCanvas
                        source: root.canvasDelegateSource
                        onLoaded: {
                            if (item)
                                item.forceActiveFocus(Qt.OtherFocusReason)
                        }
                    }

                    Shell.AppSidebarPane {
                        anchors.fill: parent
                        edge: Qt.RightEdge
                        opened: root.rightPanelOpen
                        paneWidth: root.rightPanelWidth
                        inset: root.overlayMargin
                        gap: root.overlayMargin
                        content: inspectorPaneComponent
                        z: 3
                    }

                    Component {
                        id: inspectorPaneComponent

                        Shell.AppInspectorPane {
                            inspectorObject: root.inspectorObject
                            inspectorData: root.inspectorData
                            cornerRadius: root.resolvedTheme.shape.overlayRadius
                            onFieldEdited: function(fieldKey, value) {
                                root.handleInspectorFieldEdited(fieldKey, value)
                            }
                            onActionTriggered: function(actionId, payload) {
                                root.uiActionRequested(
                                    actionId,
                                    payload !== undefined && payload !== null ? payload : ({})
                                )
                            }
                        }
                    }

                }
            }

            Shell.AppSidebarPane {
                id: leftSidebarPane

                anchors.fill: parent
                anchorItem: leftSidebar
                opened: root.leftPaneOpen
                autoHideEnabled: root.leftPanelAutoHideActive
                autoHideSuspended: root.leftPanelAutoHideSuspended
                autoHideTriggerActive: leftSidebar.effectiveHovered
                    || root.leftPanelAutoHideTriggerActive
                inset: root.overlayMargin
                gap: root.overlayMargin
                z: 3
                onOpenRequested: function(opened) {
                    root.requestLeftPaneOpen(opened)
                }
            }
        }

        Shell.AppBottomNavigationBar {
            id: bottomMenuBar

            Layout.fillWidth: true
            Layout.preferredHeight: root.bottomBarHeight
            visible: root.showBottomBar
            onItemTriggered: function(key) {
                root.bottomMenuItemRequested(key)
            }
        }
    }

}

