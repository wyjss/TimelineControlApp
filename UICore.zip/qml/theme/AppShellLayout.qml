import QtQuick 2.14

QtObject {
    readonly property int sidebarWidth: 272
    readonly property int inspectorWidth: 320
    readonly property int topBarHeight: 48
    readonly property int topBarPadding: 12
    readonly property int topBarSearchWidth: 320
    readonly property int topBarIconButtonSize: 32
    readonly property int windowControlButtonSize: 32
    readonly property int topBarDragWidth: 120
    readonly property int bottomBarHeight: 40
    readonly property int bottomBarPadding: 12
    readonly property int railWidth: 56
    readonly property int railPadding: 8
    readonly property int railButtonSize: 40
    readonly property int shellOverlayMargin: 12
}
