import QtQuick 2.14

QtObject {
    readonly property string familySans: "Microsoft YaHei UI"

    readonly property int titleXL: 28
    readonly property int titleL: 24
    readonly property int titleM: 20
    readonly property int sectionTitle: 16
    readonly property int bodyL: 14
    readonly property int bodyM: 14
    readonly property int bodyS: 12

    readonly property int weightRegular: Font.Normal
    readonly property int weightStrong: Font.Medium
    readonly property int weightBold: Font.DemiBold
}
