import QtQuick 2.14

QtObject {
    readonly property int controlRadius: 6
    readonly property int sectionRadius: 8
    readonly property int panelRadius: 10
    readonly property int shellRadius: 0
    readonly property int canvasRadius: 0
    readonly property int overlayRadius: 12

    readonly property real pillRadiusFactor: 0.5
}
