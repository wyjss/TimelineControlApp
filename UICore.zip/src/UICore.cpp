#include <UICore/UICore.h>

#include <QResource>

static void initializeResources()
{
    Q_INIT_RESOURCE(UICoreQuick);
    Q_INIT_RESOURCE(UICoreForms);
    Q_INIT_RESOURCE(UICoreShell);
    Q_INIT_RESOURCE(UICoreTask);
}

namespace UICore {

void initialize()
{
    static const bool initialized = []() {
        initializeResources();
        return true;
    }();
    Q_UNUSED(initialized)
}

} // namespace UICore
