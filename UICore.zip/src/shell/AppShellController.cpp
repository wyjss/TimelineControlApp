#include <UICore/Shell/AppShellController.h>

using namespace UICore;

namespace {

bool variantWrapsQObject(const QVariant &value)
{
    return value.isValid() && value.canConvert<QObject *>();
}

} // namespace

AppShellController::AppShellController(QObject *parent)
    : QObject(parent)
{
}

QString AppShellController::activeNavigationKey() const
{
    return m_activeNavigationKey;
}

void AppShellController::setActiveNavigationKey(const QString &key)
{
    const QString normalizedKey = key.trimmed();
    if (m_activeNavigationKey == normalizedKey)
        return;

    m_activeNavigationKey = normalizedKey;
    emit activeNavigationKeyChanged();
}

bool AppShellController::leftPaneOpen() const
{
    return m_leftPaneOpen;
}

void AppShellController::setLeftPaneOpen(bool open)
{
    if (m_leftPaneOpen == open)
        return;

    m_leftPaneOpen = open;
    emit leftPaneOpenChanged();
}

bool AppShellController::rightPanelOpen() const
{
    return m_rightPanelOpen;
}

void AppShellController::setRightPanelOpen(bool open)
{
    if (m_rightPanelOpen == open)
        return;

    m_rightPanelOpen = open;
    emit rightPanelOpenChanged();
}

bool AppShellController::leftPanelAutoHide() const
{
    return m_leftPanelAutoHide;
}

void AppShellController::setLeftPanelAutoHide(bool enabled)
{
    if (m_leftPanelAutoHide == enabled)
        return;

    m_leftPanelAutoHide = enabled;
    emit leftPanelAutoHideChanged();
}

QString AppShellController::canvasInteractionState() const
{
    return m_canvasInteractionState;
}

void AppShellController::setCanvasInteractionState(const QString &state)
{
    if (m_canvasInteractionState == state)
        return;

    m_canvasInteractionState = state;
    emit canvasInteractionStateChanged();
}

QObject *AppShellController::inspectorObject() const
{
    return m_inspectorObject.data();
}

void AppShellController::setInspectorObject(QObject *inspectorObject)
{
    if (m_inspectorObject.data() == inspectorObject)
        return;

    const bool mirrorVariant = !m_inspectorData.isValid()
        || (variantWrapsQObject(m_inspectorData)
            && qvariant_cast<QObject *>(m_inspectorData) == m_inspectorObject.data());

    syncInspectorObject(inspectorObject);

    emit inspectorObjectChanged();

    if (mirrorVariant) {
        const QVariant nextData = inspectorObject
            ? QVariant::fromValue(inspectorObject)
            : QVariant();
        if (m_inspectorData != nextData) {
            m_inspectorData = nextData;
            emit inspectorDataChanged();
        }
    }
}

QVariant AppShellController::inspectorData() const
{
    return m_inspectorData;
}

void AppShellController::setInspectorData(const QVariant &data)
{
    QObject *nextInspectorObject = variantWrapsQObject(data)
        ? qvariant_cast<QObject *>(data)
        : nullptr;
    const bool objectChanged = m_inspectorObject.data() != nextInspectorObject;
    const bool dataChanged = m_inspectorData != data;

    if (!objectChanged && !dataChanged)
        return;

    if (objectChanged) {
        syncInspectorObject(nextInspectorObject);
        emit inspectorObjectChanged();
    }

    if (dataChanged) {
        m_inspectorData = data;
        emit inspectorDataChanged();
    }
}

QVariantMap AppShellController::selectionData() const
{
    return m_selectionData;
}

void AppShellController::setSelectionData(const QVariantMap &data)
{
    if (m_selectionData == data)
        return;

    m_selectionData = data;
    emit selectionDataChanged();
}

void AppShellController::toggleRightPanel()
{
    setRightPanelOpen(!m_rightPanelOpen);
}

void AppShellController::handleUiAction(const QString &actionId, const QVariantMap &payload)
{
    emit uiActionTriggered(actionId, payload);
}

void AppShellController::syncInspectorObject(QObject *inspectorObject)
{
    if (m_inspectorObject.data() == inspectorObject)
        return;

    if (m_inspectorObject)
        QObject::disconnect(m_inspectorObject, nullptr, this, nullptr);

    m_inspectorObject = inspectorObject;

    if (m_inspectorObject) {
        QObject *watchedObject = m_inspectorObject.data();
        QObject::connect(watchedObject,
                         &QObject::destroyed,
                         this,
                         [this, watchedObject]() {
                             const bool mirroredVariant = variantWrapsQObject(m_inspectorData)
                                 && qvariant_cast<QObject *>(m_inspectorData) == watchedObject;

                             if (m_inspectorObject.data() == watchedObject) {
                                 m_inspectorObject = nullptr;
                                 emit inspectorObjectChanged();
                             }

                             if (mirroredVariant) {
                                 m_inspectorData = QVariant();
                                 emit inspectorDataChanged();
                             }
                         });
    }
}
