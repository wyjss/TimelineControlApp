# UICore 实现问题复核

本文档记录对现有 QML、C++ 与构建实现的只读复核结果，重点判断哪些自维护逻辑可以由 Qt 5.14 原生能力替代，哪些只是表面重复但承担了兼容职责。

本文所称“完整覆盖”至少同时满足：

- 保持 Qt 5.14、C++17、现有主题 Token 和公共资源路径兼容。
- 保持鼠标、触摸、键盘、焦点、无障碍和弹层关闭行为。
- 保持 `...Requested`、`...Edited`、`...Selected`、`...Toggled` 等现有意图信号及调用方持有状态的数据流。
- 不引入新的 binding loop、递归 Layout、重复状态或动画队列。
- 公共 API 发生变化时先提供迁移路径，并同步 `COMPONENT_GUIDE.md` 与 `CHANGELIST.md`。

只有无需迁移且行为等价的问题标记为“可直接处理”；其余问题即使方向正确，也必须满足列出的前置条件和验收项后才能落地。

## 1. 复核范围与依据

- 当前仓库的公共文档、QML、C++、资源清单和 CMake。
- 本机 Qt 5.14.2 的 `ComboBox`、`Switch`、`ItemDelegate`、`TapHandler`、`HoverHandler`、`Flickable`、`Popup`、`Binding`、`QRunnable` 和 `QThreadPool` 接口。
- 当前仓库内调用点，以及正式 EarthUI 调用层的兼容性抽样。
- 已有 [STYLE_ISSUES.md](STYLE_ISSUES.md) 与 [FOUNDATION_ISSUES.md](FOUNDATION_ISSUES.md)；本文件不重复维护其状态。

兼容性抽样确认：

- `AppToggleControl.toggled(bool)` 的仓库内调用已迁移为读取原生 `checked`，公共用法变化记录在 `CHANGELIST.md`。
- Drawer 兼容协议已删除；应用直接向 `AppShell.navigationItems` 提供导航数据。
- `inspectorObject` 与 `inspectorData` 仍被同时传入，兼容入口尚不能直接删除。
- `BaseField::defaultValue`、`BaseField` 便捷类型 getter 和 `TaskFlow` 在当前仓库及正式 EarthUI 调用层未找到使用；由于它们仍是公共 C++ API，这个结果不足以授权直接删除。

## 2. 结论总表

| 编号 | 问题 | 复核结论 | 优先级 |
| --- | --- | --- | --- |
| IMPL-QML-001 | `AppControlBase` 手工扫描子项尺寸 | 问题成立；不能只把根类型改成 `Pane`，需先收敛内容尺寸契约 | P0 |
| IMPL-QML-002 | `AppSelect` 自维护选择、键盘和弹层状态机 | 已解决；使用 `ComboBox` 状态机并保留公共数据与视觉适配 | P0 |
| IMPL-SHELL-001 | `AppDrawer` 反复转换、复制为 `QVariantMap` | 已解决；删除 Drawer 类型、注册表和 Map 镜像 | P0 |
| IMPL-QML-003 | `AppToggleControl` 重写 `Switch` 交互 | 已解决；组件直接使用原生 `Switch` 属性、信号和状态机，只保留主题与回车适配 | P1 |
| IMPL-QML-004 | `AppTapRegion` 使用 `MouseArea` 重写点击/悬停 | 已复核；`MouseArea` 已是原生输入组件，仅移除阻塞父级滚动的手势独占 | P1 |
| IMPL-QML-005 | `AppDropdownOption` 手工实现选项代理 | 已解决；使用 `ItemDelegate` 原生状态与 `clicked()` | P1 |
| IMPL-QML-006 | `AppSliderControl` 手工量化和同步 | 已解决；直接发送原生步进值，并用条件 `Binding` 保留受控值回退 | P1 |
| IMPL-SHELL-002 | Inspector 同时维护对象与动态数据 | 问题成立但承担兼容职责；只允许分阶段收口 | P1 |
| IMPL-MODEL-001 | Form/Menu 同时接受 QObject 与 JS Map | 不是可直接删除的冗余；正式类型优先，Map 兼容只在边界集中处理 | P1 |
| IMPL-QML-007 | `AppScrollPane` 手算滚动边界 | 已解决；使用 `atYBeginning/atYEnd`，保留直管 `Flickable` 的结构 | P2 |
| IMPL-SHELL-003 | 自定义 pane 通过函数反复赋值 | 可用带 `when` 的 `Binding` 替代，需覆盖缺少可选属性的 delegate | P2 |
| IMPL-SHELL-004 | Shell 按钮与 `AppButton` 有重复视觉实现 | `AppRailButton` 可保留外壳并复用 Nav 变体；Topbar 暂不强行合并 | P2 |
| IMPL-FIELD-001 | `AppFieldControl` 的空 `Component` 包装较多 | 不建议仅为减少行数改成动态 URL；当前写法有静态解析价值 | 保留 |
| IMPL-RENDER-001 | `Canvas` 与 `ColorOverlay` 看似可替换 | Qt 5.14 下承担动态绘制/主题染色；没有性能证据前保留 | 保留 |
| IMPL-PERF-001 | 多个容器存在尺寸依赖环 | Release 启动实测出现 16 条 binding loop；属于同一类尺寸契约问题 | P0 |
| IMPL-PERF-002 | 数据列表使用 `Repeater` 全量实例化 | 问题成立但随数据量放大；优先处理 Task、TextField 选项和 LeftPane | P1 |
| IMPL-PERF-003 | 图标离屏染色及大面积叠层 | 实现成本存在但严重度取决于数量和可见面积；不能单独解释持续空闲高 GPU | P2 |
| IMPL-PERF-004 | Standalone Gallery 一次创建大量示例 | 问题成立；它是压力场景，不应作为普通应用的性能基线 | Demo |
| IMPL-TASK-001 | `TaskFlow` 为 461 行 header-only 公共类型 | 先补契约与测试或走弃用流程；不因仓库内无调用直接删除 | 待决策 |
| IMPL-TASK-002 | Task 生命周期方法在线程池捕获裸 `Task *` | 问题成立；先消除对象销毁和线程亲和性风险，再保留独立后台工作入口 | P0 |
| IMPL-BUILD-001 | CMake 启用未使用自动化和全局 Widgets 查找 | 问题成立，可在不改产物的前提下精简 | P2 |
| IMPL-BUILD-002 | 当前验证环境与文档记录的 Qt 版本和构建类型不一致 | 问题成立；先建立可重复的 Debug/Release 验证基线 | P0 |
| IMPL-THEME-001 | 组件可见样式仍包含颜色、尺寸和动画字面值 | 问题成立；先区分主题值、数据值和计算常量，再分批收口 Token | P2 |
| IMPL-QML-008 | 数个无行为价值的小型重复 | 可直接处理 | P2 |
| IMPL-KEEP-001 | `ThreadRunnable` 可否换 `QRunnable::create` | Qt 5.14 不提供 `QRunnable::create`，当前实现必须保留 | 保留 |

## 3. 需要优先处理的问题

### IMPL-QML-001 `AppControlBase` 手工内容测量

**原问题**

`AppControlBase` 遍历 `contentHost.children`，手工连接每个子项的 `implicitWidthChanged`、`implicitHeightChanged` 与 `visibleChanged`，再用 `contentRevision` 强制重算尺寸。该实现复杂、容易形成尺寸依赖环，并与 Qt `Control` 的 `contentItem` 隐式尺寸机制重复。

**修正后的解决方案**

不能直接把根对象从 `Control` 改成 `Pane`。Qt 5.14 的 `Pane` 对单一内容项最有效，多直接子项仍需要明确的组合尺寸；现有 `AppSurface` 又允许多子项和锚定子项，因此直接替换不能完整覆盖当前行为。

应分三步处理：

1. 将 `sizeToContent: true` 的正式契约收敛为“一个具有有效 `implicitWidth/implicitHeight` 的直接内容根”，多内容使用 `Row`、`Column` 或 Layout 聚合。
2. 对锚定填充或固定尺寸场景继续使用 `sizeToContent: false`，并在调用处明确尺寸。
3. 完成调用点迁移后，删除子项枚举、信号手工连接、`try/catch` 和 `contentRevision`；根类型可继续使用 `Control`，只有确实符合单内容语义的容器再评估 `Pane`。

迁移期间保留 `sizeToContent`、`constrainContentWidth` 和 `constrainContentHeight`，不一次性改变公共调用方式。

**验收**

- Standalone 所有 Surface、Panel、Section、Shell 和 Task 场景尺寸与迁移前一致。
- QML 启动日志中不再出现 `implicitWidth` binding loop 或递归 Layout 警告。
- 子项显示、隐藏和内容文字变化后隐式尺寸仍能自动更新。
- 锚定填充、多个视觉叠层和 `sizeToContent: false` 场景不被压缩为零。

### IMPL-QML-002 `AppSelect` 使用 Qt `ComboBox` 状态机

**现状**

`AppSelect` 自行实现当前项查找、键盘导航、焦点、触发区域、弹层开关、防重复点击计时、选项高亮、滚动定位和关闭状态。Qt 5.14 的 `ComboBox` 已提供 `currentIndex`、`highlightedIndex`、`activated`、`valueRole`、`currentValue`、`indexOfValue()` 与 `valueAt()`。

**完成结果**

`AppSelect` 已直接使用 `ComboBox` 承担点击、触摸、焦点、键盘、选项高亮和弹层状态机，并继续使用自定义 `background`、`contentItem`、`indicator`、`popup` 和 `ItemDelegate` 保持当前风格。公共数据与视觉 API 不变。

保留的兼容逻辑：

- 保留 `options`、`value`、`textRole`、`valueRole` 和 `valueSelected(var)`。
- 保留 `AppOptionData.valuesEqual()` 的字符串等价语义；Qt 原生值查找不能被假定与当前规则完全相同。
- 保留 `readOnly`、`appearance`、`emphasized`、leading/trailing 插槽和弹层宽高限制。
- 保留窗口边界内的左右修正、上方/下方展开判断，以及与展开方向一致的动画原点。
- 按组件指南的受控数据流，用户激活只发送 `valueSelected(nextValue)`，`value` 由调用方提交；不得由内部赋值破坏外部 binding。

已删除手写按键分支、点击区域、弹层高亮状态、关闭来源状态和防重复点击 Timer。键盘操作采用 Qt 5.14 `ComboBox` 原生语义。

Qt 5.14 会预创建当前 delegate；自定义 popup 的可见 `ListView` 直接消费同一个 `delegateModel` 时，已有选中值会导致后续选项排到当前项上方。当前实现使用一个不可见、零尺寸的 `ItemDelegate` 保持原生 `count` 和键盘状态机，可见列表直接消费 `options`；选项点击只向原生 `currentIndex`、`activated()` 和 popup 关闭流程转发。

**完成验证**

- Qt 5.14.0 Release 构建及针对性 `qmllint` 通过。
- Standalone 启动为 0 条 QML error、0 条递归布局警告；仍有本次修改前已登记的 4 条 `AppControlBase.implicitWidth` binding loop。
- 无障碍调用覆盖弹层展开、选项激活、只读和禁用拒绝操作。
- 键盘覆盖方向键、`Home`、`End`、空格、回车和 Escape。
- 调用方接受选择时更新为新值，拒绝选择时恢复为外部值；弹层均可靠关闭。

### IMPL-SHELL-001 Drawer 对象被复制为 Map（已解决）

`AppDrawer`、注册表、`QVariantMap` 镜像和 Drawer 属性刷新连接已经删除。应用直接向 `AppShell.navigationItems` 提供导航数据；`AppShellController` 只保留 `activeNavigationKey`、`leftPaneOpen` 等稳定状态。

导航点击现在只发送 `navigationRequested(key)`，不再隐式打开 Pane；Pane 使用独立的 `leftPaneOpen` 状态。

## 4. 交互组件的原生能力替换

### IMPL-QML-003 `AppToggleControl`

`AppToggleControl` 直接以 Qt `Switch` 为根对象，使用原生 `checked`、`hovered`、`pressed`、`visualPosition`、无参数 `toggled()`、焦点和可访问状态机。仓库内调用点改为在 `onToggled` 中读取 `checked`，上层迁移方式记录在 `CHANGELIST.md`。

外观继续通过自定义 `indicator` 和 `background` 读取 UICore 主题；滑块使用 `visualPosition`，拖动时直接跟手，释放和程序改变状态时使用主题标准动画。Qt 5.14 未覆盖现有回车约定，因此只保留 Return/Enter 的最小键盘适配。

**验收**

- 仓库和已知上层调用不再读取 `nextChecked`，统一读取原生 `checked`。
- 鼠标单击、触摸、空格、回车和无障碍 ToggleAction 每次只产生一次预期切换。
- 外部 `checked` binding 与 Qt 原生 `Switch` 行为一致。
- 鼠标点击后显示焦点与键盘焦点策略符合当前组件规范。

### IMPL-QML-004 `AppTapRegion`

复核后不替换内部 `MouseArea`。该组件没有重写点击状态机，只封装了 `enabled`、按下聚焦、悬停、单击和双击；改用 `TapHandler` 会改变被动抓取、重叠控件事件传递和双击信号顺序，不能视为等价的机械替换。

实际问题是 `preventStealing: true` 会阻止父级 `Flickable` 接管拖动。当前实现已移除该设置，保留其余接口和行为；Qt Quick Test 已验证普通点击仍触发一次 `tapped()`，拖动超过阈值时由父级 `Flickable` 滚动且不误触发点击。

### IMPL-QML-005 `AppDropdownOption`

根对象已改为 `ItemDelegate`，直接使用原生 `text`、`highlighted`、`hovered`、`enabled` 和 `clicked()`，只保留 `selected`、`optionHeight` 与主题视觉。内部调用点已从 `triggered()` 改为 `clicked()`。

Qt 5.14 的 `ItemDelegate` 不会自动把无障碍 PressAction 转成 `clicked()`，因此保留一行必要的无障碍信号转发。

`AppSelect` 的可见列表不直接消费 `ComboBox.delegateModel`，以避开 Qt 5.14 当前 delegate 预创建导致的顺序错误；可见 `ItemDelegate.clicked()` 通过最小适配提交给 `ComboBox.activated()` 并关闭弹层。

### IMPL-QML-006 `AppSliderControl`

当前同步逻辑并非全部冗余：根 `value` 由外部持有，拖动时只发送 `valueEdited`；调用方拒绝提交时，滑块需要在释放后回到根值。

**完成结果**

- `Slider.stepSize` 已按原生范围起点量化 `value`，`moved()` 直接发送该值，删除了以零为起点再次量化的 `snap()`。
- 使用仅在 `!pressed` 时生效的 `Binding` 代替 `shouldSyncSlider()`、手工浮点比较、完成回调和根值 `Connections`。
- 保持默认 `snapMode`，不使用会改变拖动吸附语义的 `Slider.SnapAlways`。
- 保留两个随字体和端点文本自动更新的 `TextMetrics`，不为少量行数引入额外的字体依赖适配。

**完成验证**

- Qt 5.14.0 针对性 `qmllint` 与 Release 构建通过。
- Standalone 正常退出且无 QML 加载错误、递归布局错误或新增 binding loop；仍为已登记的 4 条 `AppControlBase.implicitWidth` 基线警告。
- 公共属性、`valueEdited` 协议、主题视觉和动画保持不变。

### IMPL-QML-007 `AppScrollPane`

**完成结果**

- `contentY > 0.5` 改为 `!flickable.atYBeginning`；
- `contentY + height < contentHeight - 0.5` 改为 `!flickable.atYEnd`。

保留当前直接持有 `Flickable` 与 ScrollBar 的结构。它需要公开 `flickableItem`、布局和滚动条 alias，并提供边缘提示；整体替换成 `ScrollView` 会重新依赖其内容管理规则，不能证明更简单或更稳定。

**完成验证**

- Qt 5.14.0 针对性 `qmllint` 与 Release 构建通过。
- Standalone 正常退出且无 QML 加载错误、递归布局错误或新增 binding loop；仍为已登记的 4 条 `AppControlBase.implicitWidth` 基线警告。
- 公共属性、滚动条、横向滚动和边缘提示视觉保持不变。

## 5. Shell 与动态模型

### IMPL-SHELL-002 Inspector 双入口

`inspectorObject` 是正式对象入口，`inspectorData` 是 Map/Variant 兼容入口；当前 controller 需要维护二者同步和对象销毁处理。正式上层仍同时传入两项，因此现在删除任何一项都不能完整覆盖调用。

处理顺序：

1. 明确新代码只写 `inspectorObject`。
2. 上层停止同时传入两项，`AppInspectorPane` 继续保留 Map fallback。
3. 经过弃用周期后再删除 controller 中的镜像状态；如仍需单入口兼容对象和 Map，可改为一个 `QVariant inspectorSource` 并在内部用 `QPointer` 观察 QObject。

### IMPL-MODEL-001 QObject/Map 双形态

`AppFormContent`、`AppMenuPane` 和 Shell 当前接受 QObject 与 JS Map，导致属性探测和 `try/catch`。但动态 Map 仍是兼容协议，不能在视图中直接删掉。

建议：

- `AppForm`、`AppFormSection` 和 `AppMenuModel` 作为正式 QObject 路径。
- 需要时将这些类型注册为不可创建的 QML 类型，以便正式入口可以声明更清晰的类型。
- Map 兼容读取继续集中在 `AppBridgeUtils.js` 或单一边界适配处，不向基础控件扩散。
- 只有上层动态数据完成迁移后，才收窄公共 `var` 属性。

### IMPL-SHELL-003 自定义 pane 属性同步

`customLeftPaneHost.applyBindings()` 与多个 root signal handler 可以换成 `Binding { target; property; value; when }`。每个 Binding 的 `when` 必须确认 Loader 已创建对象且目标属性存在，避免自定义 delegate 缺少某个可选属性时产生警告。

### IMPL-SHELL-004 Shell 按钮复用

- `AppRailButton` 已是 `Button`，并与 `AppButton` 的 Nav 变体重复。可保留 `AppRailButton` 文件和公共属性，只把内部实现收敛到 `AppButton`，保持方形尺寸、active 指示条和 icon-only 无障碍名称。
- Shell 的全局坐标 hover 跟踪覆盖 rail、bridge 和浮动 panel 三个不连续区域。逐项 HoverHandler 可能产生跨 gap 闪断，没有行为测试前保留当前实现。

## 6. 可直接处理的小项

### IMPL-QML-008 无行为价值的重复

以下修改不改变公共行为：

- 删除 `AppFormContent.resolvedLayoutMode` 字符串属性；保留实际被消费的 `resolvedLayoutModeValue`。
- 将 `AppPopup` 的 `from: root.showModalOverlay ? 0 : 0` 简化为 `from: 0`。
- 删除 `AppShell.leftPanelSwapAnimation` 外只有一个子动画的 `ParallelAnimation` 包装。
- 将 `AppTaskPanel.taskItemCount` 与 `finishedTaskCount` 改为 `readonly property`；实施前再确认没有外部写入。

## 7. 不建议处理或需要独立决策的项

### IMPL-FIELD-001 `AppFieldControl` Component 包装

空 `Component` 包装确实占用行数，但能让 renderer 由 QML 静态解析并由 `qmllint` 检查。改用动态 `Loader.source` 会把错误推迟到运行时，并依赖字符串 URL。

结论：除非 renderer 数量继续增长并能补充逐 renderer 加载测试，否则保留当前写法。

### IMPL-RENDER-001 Canvas 与图标染色

- `AppIcon` 的 `ColorOverlay` 在 Qt 5.14 中用于运行时主题染色；普通 `Image` 没有等价的公共 tint 属性。
- 窗口控制 glyph 的 Canvas 尺寸小，只在 glyph 或颜色变化时重绘。替换成 SVG 后仍可能经过 `ColorOverlay`，不保证更省 GPU。
- 大画布占位图是响应尺寸和主题的低频绘制，也不是当前高频交互开销的优先来源。

结论：先以 profiler 证明热点，再决定预着色 SVG、图标缓存或资源分色，不做无证据替换。

### IMPL-TASK-001 `TaskFlow`

`TaskFlow` 是 461 行 header-only 公共类，当前仓库和正式上层抽样没有调用，也未在组件指南中形成使用契约。可选方向只能二选一：

1. 保留：将非模板实现移到 `.cpp`，补充状态流转、取消、失败和线程派发测试，并在指南中说明用途。
2. 删除：先标记弃用并检查所有实际接入项目，再在破坏性版本中移除。

不能仅依据仓库内无调用直接删除。Task 面板的裸枚举与状态字符串问题继续由 `STYLE-ENUM-006` 跟踪。

### `BaseField` 公共冗余

`defaultValue` 的决策继续由 `FOUNDATION_ISSUES.md` 中的 `FIELD-001` 跟踪。

`intValue()`、`doubleValue()`、`floatValue()`、`boolValue()`、`stringValue()`、`colorValue()` 与 `sizeValue()` 等便捷 getter 在已检查范围内没有调用，其中 `colorValue()` 是 `UICore::Core` 当前唯一直接需要 QtGui 的字段接口。若要删除，应先弃用并检查全部消费者；删除后再评估把 `UICore::Core` 收窄为仅依赖 QtCore。

### IMPL-BUILD-001 CMake

可安全精简的方向：

- 删除没有 `.ui` 文件对应的 `CMAKE_AUTOUIC ON`。
- 当前 qrc 全部由 `qt5_add_resources()` 显式处理，`CMAKE_AUTORCC ON` 没有额外作用，可以删除。
- 先计算 `UICORE_BUILD_STANDALONE`，基础库只查找 Core/Gui/Qml/Quick/QuickControls2；仅在 standalone 开启时查找 Widgets。

验收为 standalone 开关 ON/OFF 两种配置均成功，生成的 `UICore::Core`、`UICore::Quick` 和 standalone 产物名称不变。

### IMPL-KEEP-001 必须保留的实现

- `Task.cpp` 的 `ThreadRunnable`：Qt 5.14 的 `QRunnable` 没有 `create()`，不能使用较新 Qt 的写法。
- `AppPopup` 的自定义 reveal 状态：同一进度驱动 opacity、scale、shadow 与方向位移，Qt `Popup` 的 enter/exit 仍需要这层视觉状态。
- `AppThemeContext`：Popup 关闭期间视觉项可能暂时脱离窗口，它负责保留最后一个有效主题。
- `AppField` 到 `BaseField` 的代理：这是字段状态唯一来源，不是重复副本。

## 8. 推荐实施顺序

1. IMPL-QML-007 已完成；继续落地 IMPL-QML-008 与 IMPL-BUILD-001，并保持回归基线。
2. IMPL-QML-002 与 IMPL-QML-005 已作为一个变更完成，并验证弹层关闭、焦点和受控值回退。
3. IMPL-QML-003、IMPL-QML-004 与 IMPL-QML-006 已完成。
4. 单独处理 IMPL-QML-001，先迁移尺寸契约，再删除手工测量。
5. 通过新增入口完成 IMPL-SHELL-001 与 IMPL-SHELL-002 的兼容迁移，不与基础控件重构混在同一批。
6. `TaskFlow`、`BaseField` 公共 API 和 Map 兼容入口在消费者确认后另行决策。

## 9. 每批修改的统一验收

- 完成 Qt 5.14 Release 构建。
- 对受影响 QML 执行针对性 `qmllint`。
- 启动 Standalone，确认无新增 QML warning、binding loop 或递归 Layout；视觉调试继续在屏幕 2 进行且不显示 exe 控制台。
- 覆盖鼠标、触摸、键盘、焦点、无障碍和只读/禁用状态。
- 弹层覆盖点击外部收起、焦点转移、Escape、上下展开和关闭后滚轮恢复。
- 受控组件覆盖调用方接受与拒绝用户意图两种路径。
- 动画覆盖快速连续输入，确认没有无限排队、交互延迟持续累积或异常 GPU 占用。
- 公共用法变化同步 `COMPONENT_GUIDE.md`；上层必须修改时同步 `CHANGELIST.md`。

## 10. 性能占用专项复核

本节记录 2026-07-26 对“哪些组件可能造成较高性能占用”的逐项复核结果。本次只做静态检查和启动验证，没有修改实现。

### 10.1 验证结果

- 2026-07-27 复核确认当前 `build` 目录使用 Qt 5.14.0 和 Visual Studio 2019，并已分别生成 Debug、Release。
- `tools/verify-standalone.ps1` 统一构建、环境记录和启动检查；程序以 `--smoke-test` 运行 5 秒后自行退出，日志保存到 `build/verification`。
- Debug、Release 均连续执行两次，每次都是正常退出、**4 条 QML binding loop**、0 条递归布局警告和 0 条 QML 加载错误；4 条循环均指向 `AppControlBase.qml:355` 的 `implicitWidth`。
- 本机没有 Qt 5.14.2 安装，无法复现此前记录的 5.14.2 Release 结果。此前另外 12 条警告保留为历史结果，不能作为当前验收基数。
- 仓库中未发现 `Animation.Infinite`、持续 `running: true` 或重复计时器。现有动画和 Timer 均为有限时长或单次触发。
- 因此，持续空闲高 GPU 不属于基础控件动画的正常结果；应先消除反复失效的尺寸绑定，再使用 Qt Quick Profiler 定位剩余渲染热点。

当前可重复确认的尺寸警告：

| 位置 | 数量 | 警告属性 |
| --- | ---: | --- |
| `AppControlBase.qml:355` | 4 | `implicitWidth` |

### 10.2 IMPL-PERF-001 尺寸依赖环

**结论：尺寸依赖环已确认；当前运行时只确认 `AppControlBase` 的 4 条警告，其余链路待针对性复现。**

- `AppControlBase` 会枚举内容子项，手工连接尺寸和可见性信号，再通过 `contentRevision` 触发重新测量；运行时已确认形成 `implicitWidth` 依赖环。
- `AppFieldControl` 从填满父项的 renderer 反向读取 `implicitWidth`，父子之间存在相互决定宽度的风险，但当前启动日志没有独立确认警告。
- `AppPaneHeader` 的填充宽度、文本换行高度与根隐式高度相互参与计算，需用换行和窗口缩放场景针对性验证。
- `AppPaneBase` 同时使用自然高度、折叠高度和填充高度，并在动画过程中改变参与 Layout 的尺寸，需用展开折叠场景针对性验证。
- `AppScrollPane.availableContentHeight` 绑定内容隐式高度；当前仓库未找到该公共属性的读取点，移除前仍需检查外部调用。

**完整解决方向**

1. 把 `sizeToContent: true` 收敛为单一直接内容根，且该内容根的隐式尺寸不能依赖宿主尺寸。
2. 调用点迁移完成后，删除 `AppControlBase` 的子项枚举、手工信号连接和 `contentRevision`。
3. `AppFieldControl` 不再从 `anchors.fill: parent` 的 renderer 反推父项隐式宽度；填充布局使用明确的中性宽度契约。
4. `AppPaneHeader` 将“宽度驱动的换行高度”与“隐式宽度协商”拆开，保持单向尺寸依赖。
5. 检查外部兼容性后，删除或改写未使用的 `availableContentHeight`。
6. `AppPaneBase` 分离填充高度与内容高度路径，避免同一属性同时参与 Layout、折叠计算和动画反馈。

**验收**

- 当前 Qt 5.14.0 Debug、Release 启动日志中的 4 条 binding loop 全部归零。
- 在独立的 Qt 5.14.2 Release 环境重新执行同一检查；若复现其他循环，先记录稳定场景和数量再纳入本项。
- 窗口缩放、文字换行、Panel/Section 展开折叠后没有递归 Layout 或尺寸抖动。
- 修复后再测空闲、连续点击和连续滚动 GPU；不能用降低动画帧率掩盖尺寸循环。

### 10.3 IMPL-PERF-002 全量实例化的数据容器

**结论：问题成立，影响随数据量增长。**

| 组件 | 复核结果 | 推荐优化 |
| --- | --- | --- |
| `AppTaskPanel` | `AppScrollPane + ColumnLayout + Repeater` 会创建全部任务卡；折叠卡片仍创建详情内容 | 改用 `ListView` 虚拟化；详情使用 `Loader`，关闭动画结束后再卸载 |
| `AppTextField` 选项弹层 | 使用 `Repeater` 创建全部选项，弹层关闭时内容仍存在 | 改用 `ListView`；选项很多时再增加弹层内容惰性加载 |
| `AppLeftPane` | 菜单行通过 `Repeater` 全量创建 | 改用 `ListView`，保持现有选择、键盘和焦点协议 |
| `AppFormContent` | 折叠区已经支持 `lazyCollapsedSections`，此前风险被高估；展开的大型表单仍线性创建 | 仅在真实表单规模证明有必要时虚拟化，并优先保证焦点和 Tab 顺序 |
| `AppMenuPane` | 表单 Loader 已按展开状态加载；自定义内容仍可能提前创建 | 仅对确认较重的自定义块增加惰性加载 |

优化时不得改变现有意图信号、受控值回退、焦点恢复和关闭动画。小数据列表不为虚拟化额外增加状态机。

### 10.4 IMPL-PERF-003 离屏染色与大面积叠层

**结论：成本存在，但此前严重度偏高，应先测量再改。**

- `AppIcon` 默认使用 `layer.enabled + ColorOverlay` 做运行时主题染色，每个可见图标可能产生离屏纹理；静止图层本身不会持续调度新帧，不能单独解释空闲 GPU 长期满载。
- 静态或已经预着色的图标应显式使用 `tintSource: false`、`animateColor: false`；需要动态主题色的图标继续保留当前实现。
- 只有在大量图标被 profiler 确认为热点后，才评估预着色资源或统一图像缓存；不要直接改用私有 `ColorImage`、Canvas 或无证据开启 effect cache。
- `AppBackdrop` 只有渐变和两个大面积半透明圆角矩形，没有模糊或持续动画。低功耗场景可关闭主、次 glow；预合成背景应以 profiler 结果为前提。
- `AppPopup` 的阴影是短时可见的矩形叠层，通常比 `DropShadow` 或实时模糊更轻；可按实际热点减少一层阴影，不建议改为模糊特效。

### 10.5 动画与高频交互复核

| 组件 | 复核结论 |
| --- | --- |
| `AppPaneBase` | 展开动画会逐帧改变参与 Layout 的高度、透明度和位移，重内容下存在瞬时开销；优先惰性卸载详情，超大内容可关闭动画 |
| `AppShell` | 正常开关主要动画 `x` 和 opacity；width 动画只在宽度实际变化时触发，并非每次开关都同时运行，原风险描述应下调 |
| `AppShell` 指针自动隐藏 | 启用后每次指针移动会进行多次坐标映射；属于条件性热点，需 profiler 证明后再节流或改 Handler |
| `AppSelect` | 最长选项宽度测量会遍历 options，但只随相关依赖重算；列表本身已虚拟化，属于大数据下的低优先级问题 |
| Slider、Button、Toggle | 使用有限时长的短动画，没有无限循环；单个组件不是持续高占用来源 |
| `AppScrollPane` | 使用 Qt `Flickable` 原生滚动，不存在持续平滑滚动动画队列 |
| 小型 Canvas glyph | 仅在颜色、尺寸或 glyph 改变时重绘，当前属于低风险 |

### 10.6 Standalone Gallery 的定位

`UICoreGallery.qml` 会在同一长页面中创建大量组件示例和多个 `Repeater`，它适合作为综合压力场景，但不能代表普通应用的空闲基线。

如需准确比较单个组件的 CPU/GPU 成本，应按类别用 Tab、分页或 `Loader` 分批加载示例，并分别记录：

- 无交互空闲基线；
- 单组件 hover、press、focus 和展开动画；
- 连续点击与连续滚动；
- 10、100、1000 条数据量下的创建、滚动和内存变化。

### 10.7 修正后的处理顺序

1. 先处理 IMPL-BUILD-002，建立明确的 Qt 版本、构建类型和启动日志基线。
2. 再处理 IMPL-PERF-001，确保各验证配置启动零 binding loop。
3. 再处理 TaskPanel、TextField 选项和 LeftPane 的全量实例化。
4. 为静态 `AppIcon` 调用点建立关闭染色和颜色动画的推荐用法。
5. 使用 Qt Quick Profiler 复测后，再决定是否调整 Backdrop、Popup 和 Shell。
6. 将 Gallery 拆成可按需加载的独立性能场景，避免综合页干扰单组件结论。

任何性能改动均需同时保存优化前后的相同场景数据；只有日志、帧时间、渲染批次或 GPU/CPU 采样证明改善，才记录为已完成。

## 11. 执行 TODO

本节是当前六项优先问题的唯一执行队列。只有代码、文档和对应验证全部完成后才能勾选；实施中发现的新问题继续使用现有编号记录，不在同一变更中顺带扩大范围。

- [x] **TODO-01 / IMPL-BUILD-002：建立可重复的构建和日志基线**
  - 分开记录 Qt 5.14.0 Debug、Qt 5.14.0 Release，以及实际可用时的 Qt 5.14.2 Release。
  - 每次记录 Qt 路径、版本、编译器、构建类型、源码状态、执行命令和完整启动日志。
  - 启动检查固定启用 `QT_FORCE_STDERR_LOGGING=1`，将 binding loop 和 QML error 作为失败。
  - 验收：同一源码和配置可以重复得到一致结果，不再以构建目录名称推断 Qt 版本或构建类型。
  - 完成记录：Qt 5.14.0 Debug、Release 各连续验证两次，结果均为 4 条同位置 binding loop、0 条递归布局警告、0 条 QML 加载错误；本机未安装 Qt 5.14.2。

- [ ] **TODO-02 / IMPL-TASK-002、IMPL-TASK-001：消除 Task 生命周期和线程亲和性风险**
  - `Task::start()`、`cancel()` 只在 Task 所在线程调用，不把裸 `Task *` 生命周期方法投递到线程池。
  - 后台工作使用独立操作状态和取消标记，完成结果安全投递回 Task 所在线程。
  - 明确运行中注销、Task 销毁和 Manager 销毁的行为。
  - 审计 `TaskFlow` 外部消费者后，决定保留并移出 header-only 实现，或进入弃用流程。
  - 验收：覆盖排队后销毁、运行中注销、取消竞态、Manager 销毁和 TaskFlow 成败路径。

- [x] **TODO-03 / IMPL-QML-002～007：收口交互控件状态机**
  - [x] `AppSelect` 与 `AppDropdownOption` 同批改为 `ComboBox + ItemDelegate`，保留公共数据 API、外观和受控值协议。
  - [x] `AppToggleControl` 直接使用原生 `Switch` 属性、信号和状态机，并完成仓库内调用迁移。
  - [x] `AppTapRegion` 保留原生 `MouseArea`，移除阻塞父级滚动的 `preventStealing`。
  - [x] `AppSliderControl` 直接发送原生步进值，并以条件 `Binding` 保留受控值回退。
  - [x] `AppScrollPane` 使用原生边界状态。
  - 验收：鼠标、触摸、键盘、焦点、无障碍、弹层关闭，以及调用方接受/拒绝意图全部通过。

- [ ] **TODO-04 / IMPL-QML-001、IMPL-PERF-001：消除尺寸依赖环**
  - 先把 `sizeToContent` 收敛为单一、具有独立隐式尺寸的直接内容根。
  - 调用点迁移后删除 `AppControlBase` 的子项扫描、手工信号连接和 `contentRevision`。
  - 分别验证 Field、PaneHeader、PaneBase 和 ScrollPane 的潜在尺寸反馈链。
  - 验收：所有明确验证配置启动零 binding loop，窗口缩放、换行和展开折叠无尺寸抖动。

- [x] **TODO-05 / IMPL-SHELL-001：删除 Drawer 对象列表**
  - 已删除 `AppDrawer`、注册表、Map 镜像和 `toVariantMap()`。
  - `AppShell.navigationItems` 直接消费应用提供的导航数据。
  - 导航选择与 Pane 显隐已经解耦。

- [ ] **TODO-06 / IMPL-THEME-001：清理组件样式字面值**
  - 先区分可见主题值、数据默认值、比例/哨兵和 Canvas 计算常量。
  - 可见颜色、字号、圆角、动画和重复尺寸优先复用现有 Token；只为确实随主题变化的组件几何新增 spec。
  - 增加带明确白名单的静态检查，避免重新引入组件级主题字面值。
  - 验收：替换测试主题即可改变组件 chrome，组件内部没有字面值回退，数据颜色和计算常量不被误改。
