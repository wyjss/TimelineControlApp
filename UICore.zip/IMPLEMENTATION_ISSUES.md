# UICore 实现问题复核

本文档记录对现有 QML、C++ 与构建实现的只读复核结果，重点判断哪些自维护逻辑可以由 Qt 5.14 原生能力替代，哪些只是表面重复但承担了兼容职责。

本文所称“完整覆盖”至少同时满足：

- 保持 Qt 5.14、C++17、现有主题 Token 和公共资源路径兼容。
- 保持鼠标、触摸、键盘、焦点、无障碍和弹层关闭行为。
- 保持 `...Requested`、`...Edited`、`...Selected`、`...Toggled` 等现有意图信号及调用方持有状态的数据流。
- 不引入新的 binding loop、递归 Layout、重复状态或动画队列。
- 公共 API 发生变化时先提供迁移路径，并同步 `COMPONENT_GUIDE.md` 与 `CHANGELIST.md`。

只有无需迁移且行为等价的问题标记为“可直接处理”；其余问题即使方向正确，也必须满足列出的前置条件和验收项后才能落地。

## 1. 复核范围与依据

- 当前仓库的公共文档、QML、C++、资源清单和 CMake。
- 本机 Qt 5.14.2 的 `ComboBox`、`Switch`、`ItemDelegate`、`TapHandler`、`HoverHandler`、`Flickable`、`Popup`、`Binding`、`QRunnable` 和 `QThreadPool` 接口。
- 当前仓库内调用点，以及正式 EarthUI 调用层的兼容性抽样。
- 已有 [STYLE_ISSUES.md](STYLE_ISSUES.md) 与 [FOUNDATION_ISSUES.md](FOUNDATION_ISSUES.md)；本文件不重复维护其状态。

兼容性抽样确认：

- `AppToggleControl.toggled(bool)` 的 `nextChecked` 参数已有实际调用，不能直接改成 Qt `Switch.toggled()`。
- `AppShellController.drawers` 已由上层直接绑定给 `AppShell`，不能直接改变属性名或元素协议。
- `inspectorObject` 与 `inspectorData` 仍被同时传入，兼容入口尚不能直接删除。
- `BaseField::defaultValue`、`BaseField` 便捷类型 getter 和 `TaskFlow` 在当前仓库及正式 EarthUI 调用层未找到使用；由于它们仍是公共 C++ API，这个结果不足以授权直接删除。

## 2. 结论总表

| 编号 | 问题 | 复核结论 | 优先级 |
| --- | --- | --- | --- |
| IMPL-QML-001 | `AppControlBase` 手工扫描子项尺寸 | 问题成立；不能只把根类型改成 `Pane`，需先收敛内容尺寸契约 | P0 |
| IMPL-QML-002 | `AppSelect` 自维护选择、键盘和弹层状态机 | 问题成立；可用 `ComboBox` 承担交互状态机，但必须保留公共适配层 | P0 |
| IMPL-SHELL-001 | `AppDrawer` 反复转换、复制为 `QVariantMap` | 问题成立；采用对象列表的分阶段迁移，不能原位破坏 `drawers` 协议 | P0 |
| IMPL-QML-003 | `AppToggleControl` 重写 `Switch` 交互 | 问题成立；保留公共外壳，在内部使用 `Switch`，不能直接继承并改信号 | P1 |
| IMPL-QML-004 | `AppTapRegion` 使用 `MouseArea` 重写点击/悬停 | 问题成立；可在不改内部 API 的前提下换成 Pointer Handler | P1 |
| IMPL-QML-005 | `AppDropdownOption` 手工实现选项代理 | 问题成立；与 `AppSelect` 一起改为 `ItemDelegate` | P1 |
| IMPL-QML-006 | `AppSliderControl` 手工量化和同步 | 部分成立；保留受控值回退，用 `Slider.snapMode` 与条件 `Binding` 简化 | P1 |
| IMPL-SHELL-002 | Drawer/Inspector 同时维护对象与动态数据 | 问题成立但承担兼容职责；只允许分阶段收口 | P1 |
| IMPL-MODEL-001 | Form/Menu 同时接受 QObject 与 JS Map | 不是可直接删除的冗余；正式类型优先，Map 兼容只在边界集中处理 | P1 |
| IMPL-QML-007 | `AppScrollPane` 手算滚动边界 | 边界判断可直接用 `atYBeginning/atYEnd`；直管 `Flickable` 的结构保留 | P2 |
| IMPL-SHELL-003 | 自定义 pane 通过函数反复赋值 | 可用带 `when` 的 `Binding` 替代，需覆盖缺少可选属性的 delegate | P2 |
| IMPL-SHELL-004 | Shell 按钮与 `AppButton` 有重复视觉实现 | `AppRailButton` 可保留外壳并复用 Nav 变体；Topbar 暂不强行合并 | P2 |
| IMPL-FIELD-001 | `AppFieldControl` 的空 `Component` 包装较多 | 不建议仅为减少行数改成动态 URL；当前写法有静态解析价值 | 保留 |
| IMPL-RENDER-001 | `Canvas` 与 `ColorOverlay` 看似可替换 | Qt 5.14 下承担动态绘制/主题染色；没有性能证据前保留 | 保留 |
| IMPL-PERF-001 | 多个容器存在尺寸依赖环 | Release 启动实测出现 16 条 binding loop；属于同一类尺寸契约问题 | P0 |
| IMPL-PERF-002 | 数据列表使用 `Repeater` 全量实例化 | 问题成立但随数据量放大；优先处理 Task、TextField 选项和 LeftPane | P1 |
| IMPL-PERF-003 | 图标离屏染色及大面积叠层 | 实现成本存在但严重度取决于数量和可见面积；不能单独解释持续空闲高 GPU | P2 |
| IMPL-PERF-004 | Standalone Gallery 一次创建大量示例 | 问题成立；它是压力场景，不应作为普通应用的性能基线 | Demo |
| IMPL-TASK-001 | `TaskFlow` 为 461 行 header-only 公共类型 | 先补契约与测试或走弃用流程；不因仓库内无调用直接删除 | 待决策 |
| IMPL-BUILD-001 | CMake 启用未使用自动化和全局 Widgets 查找 | 问题成立，可在不改产物的前提下精简 | P2 |
| IMPL-QML-008 | 数个无行为价值的小型重复 | 可直接处理 | P2 |
| IMPL-KEEP-001 | `ThreadRunnable` 可否换 `QRunnable::create` | Qt 5.14 不提供 `QRunnable::create`，当前实现必须保留 | 保留 |

## 3. 需要优先处理的问题

### IMPL-QML-001 `AppControlBase` 手工内容测量

**现状**

`AppControlBase` 遍历 `contentHost.children`，手工连接每个子项的 `implicitWidthChanged`、`implicitHeightChanged` 与 `visibleChanged`，再用 `contentRevision` 强制重算尺寸。该实现复杂、容易形成尺寸依赖环，并与 Qt `Control` 的 `contentItem` 隐式尺寸机制重复。

**修正后的解决方案**

不能直接把根对象从 `Control` 改成 `Pane`。Qt 5.14 的 `Pane` 对单一内容项最有效，多直接子项仍需要明确的组合尺寸；现有 `AppSurface` 又允许多子项和锚定子项，因此直接替换不能完整覆盖当前行为。

应分三步处理：

1. 将 `sizeToContent: true` 的正式契约收敛为“一个具有有效 `implicitWidth/implicitHeight` 的直接内容根”，多内容使用 `Row`、`Column` 或 Layout 聚合。
2. 对锚定填充或固定尺寸场景继续使用 `sizeToContent: false`，并在调用处明确尺寸。
3. 完成调用点迁移后，删除子项枚举、信号手工连接、`try/catch` 和 `contentRevision`；根类型可继续使用 `Control`，只有确实符合单内容语义的容器再评估 `Pane`。

迁移期间保留 `sizeToContent`、`constrainContentWidth` 和 `constrainContentHeight`，不一次性改变公共调用方式。

**验收**

- Standalone 所有 Surface、Panel、Section、Shell 和 Task 场景尺寸与迁移前一致。
- QML 启动日志中不再出现 `implicitWidth` binding loop 或递归 Layout 警告。
- 子项显示、隐藏和内容文字变化后隐式尺寸仍能自动更新。
- 锚定填充、多个视觉叠层和 `sizeToContent: false` 场景不被压缩为零。

### IMPL-QML-002 `AppSelect` 使用 Qt `ComboBox` 状态机

**现状**

`AppSelect` 自行实现当前项查找、键盘导航、焦点、触发区域、弹层开关、防重复点击计时、选项高亮、滚动定位和关闭状态。Qt 5.14 的 `ComboBox` 已提供 `currentIndex`、`highlightedIndex`、`activated`、`valueRole`、`currentValue`、`indexOfValue()` 与 `valueAt()`。

**修正后的解决方案**

以 `ComboBox` 承担交互状态机，并继续使用自定义 `background`、`contentItem`、`indicator`、`popup` 和 `ItemDelegate` 保持当前风格。公共 `AppSelect` API 不变。

不能直接删除的兼容逻辑：

- 保留 `options`、`value`、`textRole`、`valueRole` 和 `valueSelected(var)`。
- 保留 `AppOptionData.valuesEqual()` 的字符串等价语义；Qt 原生值查找不能被假定与当前规则完全相同。
- 保留 `readOnly`、`appearance`、`emphasized`、leading/trailing 插槽和弹层宽高限制。
- 保留窗口边界内的左右修正、上方/下方展开判断，以及与展开方向一致的动画原点。
- 按组件指南的受控数据流，用户激活只发送 `valueSelected(nextValue)`，`value` 由调用方提交；不得由内部赋值破坏外部 binding。

**验收**

- 鼠标、触摸、方向键、`Home`、`End`、空格、回车和 Escape 行为完整。
- 选择一次只发送一次 `valueSelected`；程序设置 `value` 不发送用户意图信号。
- 点击选项、点击控件外部、切换焦点和按 Escape 均能可靠收起弹层。
- 弹层关闭后滚轮立即恢复给页面；滚轮和拖动列表不会触发误选。
- 上方空间更大时向上展开，边界内不截断，动画方向与展开方向一致。
- 调用方接受或拒绝一次选择时，组件最终显示值都与调用方状态一致。

### IMPL-SHELL-001 Drawer 对象被复制为 Map

**现状**

`AppShellController` 同时保存 `QList<QPointer<AppDrawer>>` 与 `QVariantList m_drawers`。每个 Drawer 的多个属性变化都会触发 `toVariantMap()` 和整个列表重建，失去 QObject 自带的属性通知能力。

**解决方案**

采用两阶段迁移：

1. 新增只读对象列表入口，列表元素直接保存 `AppDrawer *`，由 `QPointer` 注册表继续负责失效保护；`AppShell` 先兼容消费对象属性。现有 `drawers` Map 列表暂时保留。
2. 上层完成迁移后，再移除 Map 镜像、`toVariantMap()` 和除 key/销毁之外的列表刷新连接，并在 `CHANGELIST.md` 记录。

不应直接把现有 `drawers` 元素从 Map 原位改成 QObject，因为外部 JS 可能依赖 Map 的枚举、复制或修改行为。

**验收**

- 注册、注销、销毁、重复 key 和 active key 变化行为不变。
- Drawer 的 label、icon、detail、pane 数据和 controller 变化通过各自 `NOTIFY` 更新视图，不重建整个列表。
- 现有 `AppShellHost` 和 Standalone 在兼容期无需同步修改。
- Map 入口最终删除前，仓库和正式上层调用点均已迁移。

## 4. 交互组件的原生能力替换

### IMPL-QML-003 `AppToggleControl`

Qt `Switch` 已覆盖点击、触摸、主要键盘操作、焦点、可访问状态和 checked 状态机，但不能直接把 `AppToggleControl` 根对象改成 `Switch`：现有公共信号是 `toggled(bool nextChecked)`，Qt 内置信号是无参数 `toggled()`，正式调用点使用了 `nextChecked`。

完整方案是保留 `AppToggleControl` 公共外壳和信号，在内部使用 `Switch`，自定义其 indicator/background，并转发一次状态变化。外部设置在根对象上的 `Accessible.name` 也必须传递到实际可访问控件；Qt 5.14 原生行为未覆盖现有回车键约定时，只保留这一项最小键盘适配。

同时删除根 `Item` 上重复声明的 `property bool enabled`，使用继承属性；不再为双击单独增加一次切换处理。

**验收**

- 现有 `onToggled: ... nextChecked` 调用无需修改。
- 鼠标单击、触摸、空格、回车和无障碍 ToggleAction 每次只产生一次预期切换。
- 外部 binding 接受或拒绝切换时，最终 checked 状态正确。
- 鼠标点击后显示焦点与键盘焦点策略符合当前组件规范。

### IMPL-QML-004 `AppTapRegion`

保留 `enabled`、`takeFocusOnPress`、`focusTarget`、`hovered`、`tapped()` 与 `doubleTapped()`，只将内部 `MouseArea` 换成 Qt 5.14 的 `TapHandler` 与 `HoverHandler`。

`TapHandler` 必须在 pressed 阶段把焦点交给 `focusTarget`，只接受左键，并使用允许 `Flickable` 在超过拖动阈值后接管的 gesture policy。不能机械复制 `preventStealing: true`，否则会继续阻塞滚动手势。

### IMPL-QML-005 `AppDropdownOption`

将根对象改为 `ItemDelegate`，保留 `selected`、现有 `highlighted` 语义、`optionHeight` 与 `triggered()` 兼容接口。视觉继续使用主题组件绘制。

该项与 `AppSelect` 同批处理，使 `ComboBox` 能识别 delegate 激活并负责关闭弹层。单独替换而不接入 ComboBox，收益有限。

### IMPL-QML-006 `AppSliderControl`

当前同步逻辑并非全部冗余：根 `value` 由外部持有，拖动时只发送 `valueEdited`；调用方拒绝提交时，滑块需要在释放后回到根值。

可替换部分：

- 使用 `Slider.stepSize` 配合 `snapMode: Slider.SnapAlways` 代替 `snap()`。
- 使用仅在 `!pressed` 时生效的 `Binding` 代替 `shouldSyncSlider()` 与手工浮点比较。
- 使用一个 `FontMetrics.advanceWidth()` 计算 from/to 标签最大宽度。

**验收**

- 整数、小数 step、反向范围边界和键盘增减均按 step 对齐。
- 拖动期间无回跳；调用方接受时停留在新值，拒绝时释放后回到原值。
- `valueEdited` 不因外部同步而递归触发。

### IMPL-QML-007 `AppScrollPane`

只把：

- `contentY > 0.5` 改为 `!flickable.atYBeginning`；
- `contentY + height < contentHeight - 0.5` 改为 `!flickable.atYEnd`。

保留当前直接持有 `Flickable` 与 ScrollBar 的结构。它需要公开 `flickableItem`、布局和滚动条 alias，并提供边缘提示；整体替换成 `ScrollView` 会重新依赖其内容管理规则，不能证明更简单或更稳定。

## 5. Shell 与动态模型

### IMPL-SHELL-002 Inspector 双入口

`inspectorObject` 是正式对象入口，`inspectorData` 是 Map/Variant 兼容入口；当前 controller 需要维护二者同步和对象销毁处理。正式上层仍同时传入两项，因此现在删除任何一项都不能完整覆盖调用。

处理顺序：

1. 明确新代码只写 `inspectorObject`。
2. 上层停止同时传入两项，`AppInspectorPane` 继续保留 Map fallback。
3. 经过弃用周期后再删除 controller 中的镜像状态；如仍需单入口兼容对象和 Map，可改为一个 `QVariant inspectorSource` 并在内部用 `QPointer` 观察 QObject。

### IMPL-MODEL-001 QObject/Map 双形态

`AppFormContent`、`AppMenuPane` 和 Shell 当前接受 QObject 与 JS Map，导致属性探测和 `try/catch`。但动态 Map 仍是兼容协议，不能在视图中直接删掉。

建议：

- `AppForm`、`AppFormSection`、`AppMenuModel` 和 `AppDrawer` 作为正式 QObject 路径。
- 需要时将这些类型注册为不可创建的 QML 类型，以便正式入口可以声明更清晰的类型。
- Map 兼容读取继续集中在 `AppBridgeUtils.js` 或单一边界适配处，不向基础控件扩散。
- 只有上层动态数据完成迁移后，才收窄公共 `var` 属性。

### IMPL-SHELL-003 自定义 pane 属性同步

`customLeftPaneHost.applyBindings()` 与多个 root signal handler 可以换成 `Binding { target; property; value; when }`。每个 Binding 的 `when` 必须确认 Loader 已创建对象且目标属性存在，避免自定义 delegate 缺少某个可选属性时产生警告。

### IMPL-SHELL-004 Shell 按钮复用

- `AppRailButton` 已是 `Button`，并与 `AppButton` 的 Nav 变体重复。可保留 `AppRailButton` 文件和公共属性，只把内部实现收敛到 `AppButton`，保持方形尺寸、active 指示条和 icon-only 无障碍名称。
- `AppTopbarIconButton` 还承担系统窗口 glyph、危险悬停色和固定尺寸；`AppButton` 当前没有完整对应协议，暂不为了统一而扩大基础按钮 API。
- Shell 的全局坐标 hover 跟踪覆盖 rail、bridge 和浮动 panel 三个不连续区域。逐项 HoverHandler 可能产生跨 gap 闪断，没有行为测试前保留当前实现。

## 6. 可直接处理的小项

### IMPL-QML-008 无行为价值的重复

以下修改不改变公共行为：

- 删除 `AppFormContent.resolvedLayoutMode` 字符串属性；保留实际被消费的 `resolvedLayoutModeValue`。
- 将 `AppPopup` 的 `from: root.showModalOverlay ? 0 : 0` 简化为 `from: 0`。
- 删除 `AppShell.leftPanelSwapAnimation` 外只有一个子动画的 `ParallelAnimation` 包装。
- 将 `AppTaskPanel.taskItemCount` 与 `finishedTaskCount` 改为 `readonly property`；实施前再确认没有外部写入。

## 7. 不建议处理或需要独立决策的项

### IMPL-FIELD-001 `AppFieldControl` Component 包装

空 `Component` 包装确实占用行数，但能让 renderer 由 QML 静态解析并由 `qmllint` 检查。改用动态 `Loader.source` 会把错误推迟到运行时，并依赖字符串 URL。

结论：除非 renderer 数量继续增长并能补充逐 renderer 加载测试，否则保留当前写法。

### IMPL-RENDER-001 Canvas 与图标染色

- `AppIcon` 的 `ColorOverlay` 在 Qt 5.14 中用于运行时主题染色；普通 `Image` 没有等价的公共 tint 属性。
- 窗口控制 glyph 的 Canvas 尺寸小，只在 glyph 或颜色变化时重绘。替换成 SVG 后仍可能经过 `ColorOverlay`，不保证更省 GPU。
- 大画布占位图是响应尺寸和主题的低频绘制，也不是当前高频交互开销的优先来源。

结论：先以 profiler 证明热点，再决定预着色 SVG、图标缓存或资源分色，不做无证据替换。

### IMPL-TASK-001 `TaskFlow`

`TaskFlow` 是 461 行 header-only 公共类，当前仓库和正式上层抽样没有调用，也未在组件指南中形成使用契约。可选方向只能二选一：

1. 保留：将非模板实现移到 `.cpp`，补充状态流转、取消、失败和线程派发测试，并在指南中说明用途。
2. 删除：先标记弃用并检查所有实际接入项目，再在破坏性版本中移除。

不能仅依据仓库内无调用直接删除。Task 面板的裸枚举与状态字符串问题继续由 `STYLE-ENUM-006` 跟踪。

### `BaseField` 公共冗余

`defaultValue` 的决策继续由 `FOUNDATION_ISSUES.md` 中的 `FIELD-001` 跟踪。

`intValue()`、`doubleValue()`、`floatValue()`、`boolValue()`、`stringValue()`、`colorValue()` 与 `sizeValue()` 等便捷 getter 在已检查范围内没有调用，其中 `colorValue()` 是 `UICore::Core` 当前唯一直接需要 QtGui 的字段接口。若要删除，应先弃用并检查全部消费者；删除后再评估把 `UICore::Core` 收窄为仅依赖 QtCore。

### IMPL-BUILD-001 CMake

可安全精简的方向：

- 删除没有 `.ui` 文件对应的 `CMAKE_AUTOUIC ON`。
- 当前 qrc 全部由 `qt5_add_resources()` 显式处理，`CMAKE_AUTORCC ON` 没有额外作用，可以删除。
- 先计算 `UICORE_BUILD_STANDALONE`，基础库只查找 Core/Gui/Qml/Quick/QuickControls2；仅在 standalone 开启时查找 Widgets。

验收为 standalone 开关 ON/OFF 两种配置均成功，生成的 `UICore::Core`、`UICore::Quick` 和 standalone 产物名称不变。

### IMPL-KEEP-001 必须保留的实现

- `Task.cpp` 的 `ThreadRunnable`：Qt 5.14 的 `QRunnable` 没有 `create()`，不能使用较新 Qt 的写法。
- `AppPopup` 的自定义 reveal 状态：同一进度驱动 opacity、scale、shadow 与方向位移，Qt `Popup` 的 enter/exit 仍需要这层视觉状态。
- `AppThemeContext`：Popup 关闭期间视觉项可能暂时脱离窗口，它负责保留最后一个有效主题。
- `AppField` 到 `BaseField` 的代理：这是字段状态唯一来源，不是重复副本。

## 8. 推荐实施顺序

1. 先落地 IMPL-QML-008、IMPL-QML-007 与 IMPL-BUILD-001，并建立回归基线。
2. 将 IMPL-QML-002 与 IMPL-QML-005 作为一个变更处理，重点验证弹层关闭、焦点和滚轮。
3. 依次处理 IMPL-QML-004、IMPL-QML-003、IMPL-QML-006，保持各公共信号不变。
4. 单独处理 IMPL-QML-001，先迁移尺寸契约，再删除手工测量。
5. 通过新增入口完成 IMPL-SHELL-001 与 IMPL-SHELL-002 的兼容迁移，不与基础控件重构混在同一批。
6. `TaskFlow`、`BaseField` 公共 API 和 Map 兼容入口在消费者确认后另行决策。

## 9. 每批修改的统一验收

- 完成 Qt 5.14 Release 构建。
- 对受影响 QML 执行针对性 `qmllint`。
- 启动 Standalone，确认无新增 QML warning、binding loop 或递归 Layout；视觉调试继续在屏幕 2 进行且不显示 exe 控制台。
- 覆盖鼠标、触摸、键盘、焦点、无障碍和只读/禁用状态。
- 弹层覆盖点击外部收起、焦点转移、Escape、上下展开和关闭后滚轮恢复。
- 受控组件覆盖调用方接受与拒绝用户意图两种路径。
- 动画覆盖快速连续输入，确认没有无限排队、交互延迟持续累积或异常 GPU 占用。
- 公共用法变化同步 `COMPONENT_GUIDE.md`；上层必须修改时同步 `CHANGELIST.md`。

## 10. 性能占用专项复核

本节记录 2026-07-26 对“哪些组件可能造成较高性能占用”的逐项复核结果。本次只做静态检查和启动验证，没有修改实现。

### 10.1 验证结果

- 使用当前 `build` 目录中的 Qt 5.14 Release 程序隐藏控制台启动，并采集 5 秒启动日志。
- 程序保持运行且可响应；日志确认 **16 条 QML binding loop**，未出现递归 Layout 警告。
- 仓库中未发现 `Animation.Infinite`、持续 `running: true` 或重复计时器。现有动画和 Timer 均为有限时长或单次触发。
- 因此，持续空闲高 GPU 不属于基础控件动画的正常结果；应先消除反复失效的尺寸绑定，再使用 Qt Quick Profiler 定位剩余渲染热点。

已确认的 16 条尺寸警告：

| 位置 | 数量 | 警告属性 |
| --- | ---: | --- |
| `AppFieldControl.qml` 经 `AppFormContent.qml:270` 创建 | 3 | `implicitWidth` |
| `AppControlBase.qml:355` | 4 | `implicitWidth` |
| `UICoreGallery.qml:212`、`:1467` 的 `AppScrollPane` | 2 | `availableContentHeight` |
| `AppPaneHeader.qml:56` | 5 | `implicitHeight` |
| Gallery 中的 `AppSection` | 1 | `naturalBodyHeight` |
| Gallery 中的 `AppPanel` | 1 | `naturalBodyHeight` |

### 10.2 IMPL-PERF-001 尺寸依赖环

**结论：已确认，P0。**

- `AppControlBase` 会枚举内容子项，手工连接尺寸和可见性信号，再通过 `contentRevision` 触发重新测量；运行时已确认形成 `implicitWidth` 依赖环。
- `AppFieldControl` 从填满父项的 renderer 反向读取 `implicitWidth`，父子之间可能相互决定宽度。
- `AppPaneHeader` 的填充宽度、文本换行高度与根隐式高度相互参与计算。
- `AppPaneBase` 同时使用自然高度、折叠高度和填充高度，并在动画过程中持续改变参与 Layout 的尺寸。
- `AppScrollPane.availableContentHeight` 绑定内容隐式高度；当前仓库未找到该公共属性的读取点，但移除前仍需检查外部调用。

**完整解决方向**

1. 把 `sizeToContent: true` 收敛为单一直接内容根，且该内容根的隐式尺寸不能依赖宿主尺寸。
2. 调用点迁移完成后，删除 `AppControlBase` 的子项枚举、手工信号连接和 `contentRevision`。
3. `AppFieldControl` 不再从 `anchors.fill: parent` 的 renderer 反推父项隐式宽度；填充布局使用明确的中性宽度契约。
4. `AppPaneHeader` 将“宽度驱动的换行高度”与“隐式宽度协商”拆开，保持单向尺寸依赖。
5. 检查外部兼容性后，删除或改写未使用的 `availableContentHeight`。
6. `AppPaneBase` 分离填充高度与内容高度路径，避免同一属性同时参与 Layout、折叠计算和动画反馈。

**验收**

- Qt 5.14 Release 启动日志中的 16 条 binding loop 全部归零。
- 窗口缩放、文字换行、Panel/Section 展开折叠后没有递归 Layout 或尺寸抖动。
- 修复后再测空闲、连续点击和连续滚动 GPU；不能用降低动画帧率掩盖尺寸循环。

### 10.3 IMPL-PERF-002 全量实例化的数据容器

**结论：问题成立，影响随数据量增长。**

| 组件 | 复核结果 | 推荐优化 |
| --- | --- | --- |
| `AppTaskPanel` | `AppScrollPane + ColumnLayout + Repeater` 会创建全部任务卡；折叠卡片仍创建详情内容 | 改用 `ListView` 虚拟化；详情使用 `Loader`，关闭动画结束后再卸载 |
| `AppTextField` 选项弹层 | 使用 `Repeater` 创建全部选项，弹层关闭时内容仍存在 | 改用 `ListView`；选项很多时再增加弹层内容惰性加载 |
| `AppLeftPane` | 菜单行通过 `Repeater` 全量创建 | 改用 `ListView`，保持现有选择、键盘和焦点协议 |
| `AppFormContent` | 折叠区已经支持 `lazyCollapsedSections`，此前风险被高估；展开的大型表单仍线性创建 | 仅在真实表单规模证明有必要时虚拟化，并优先保证焦点和 Tab 顺序 |
| `AppMenuPane` | 表单 Loader 已按展开状态加载；自定义内容仍可能提前创建 | 仅对确认较重的自定义块增加惰性加载 |

优化时不得改变现有意图信号、受控值回退、焦点恢复和关闭动画。小数据列表不为虚拟化额外增加状态机。

### 10.4 IMPL-PERF-003 离屏染色与大面积叠层

**结论：成本存在，但此前严重度偏高，应先测量再改。**

- `AppIcon` 默认使用 `layer.enabled + ColorOverlay` 做运行时主题染色，每个可见图标可能产生离屏纹理；静止图层本身不会持续调度新帧，不能单独解释空闲 GPU 长期满载。
- 静态或已经预着色的图标应显式使用 `tintSource: false`、`animateColor: false`；需要动态主题色的图标继续保留当前实现。
- 只有在大量图标被 profiler 确认为热点后，才评估预着色资源或统一图像缓存；不要直接改用私有 `ColorImage`、Canvas 或无证据开启 effect cache。
- `AppBackdrop` 只有渐变和两个大面积半透明圆角矩形，没有模糊或持续动画。低功耗场景可关闭主、次 glow；预合成背景应以 profiler 结果为前提。
- `AppPopup` 的阴影是短时可见的矩形叠层，通常比 `DropShadow` 或实时模糊更轻；可按实际热点减少一层阴影，不建议改为模糊特效。

### 10.5 动画与高频交互复核

| 组件 | 复核结论 |
| --- | --- |
| `AppPaneBase` | 展开动画会逐帧改变参与 Layout 的高度、透明度和位移，重内容下存在瞬时开销；优先惰性卸载详情，超大内容可关闭动画 |
| `AppShell` | 正常开关主要动画 `x` 和 opacity；width 动画只在宽度实际变化时触发，并非每次开关都同时运行，原风险描述应下调 |
| `AppShell` 指针自动隐藏 | 启用后每次指针移动会进行多次坐标映射；属于条件性热点，需 profiler 证明后再节流或改 Handler |
| `AppSelect` | 最长选项宽度测量会遍历 options，但只随相关依赖重算；列表本身已虚拟化，属于大数据下的低优先级问题 |
| Slider、Button、Toggle | 使用有限时长的短动画，没有无限循环；单个组件不是持续高占用来源 |
| `AppScrollPane` | 使用 Qt `Flickable` 原生滚动，不存在持续平滑滚动动画队列 |
| 小型 Canvas glyph | 仅在颜色、尺寸或 glyph 改变时重绘，当前属于低风险 |

### 10.6 Standalone Gallery 的定位

`UICoreGallery.qml` 会在同一长页面中创建大量组件示例和多个 `Repeater`，它适合作为综合压力场景，但不能代表普通应用的空闲基线。

如需准确比较单个组件的 CPU/GPU 成本，应按类别用 Tab、分页或 `Loader` 分批加载示例，并分别记录：

- 无交互空闲基线；
- 单组件 hover、press、focus 和展开动画；
- 连续点击与连续滚动；
- 10、100、1000 条数据量下的创建、滚动和内存变化。

### 10.7 修正后的处理顺序

1. 先处理 IMPL-PERF-001，确保 Release 启动零 binding loop。
2. 再处理 TaskPanel、TextField 选项和 LeftPane 的全量实例化。
3. 为静态 `AppIcon` 调用点建立关闭染色和颜色动画的推荐用法。
4. 使用 Qt Quick Profiler 复测后，再决定是否调整 Backdrop、Popup 和 Shell。
5. 将 Gallery 拆成可按需加载的独立性能场景，避免综合页干扰单组件结论。

任何性能改动均需同时保存优化前后的相同场景数据；只有日志、帧时间、渲染批次或 GPU/CPU 采样证明改善，才记录为已完成。
