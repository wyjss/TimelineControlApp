# UICore Style 问题跟踪

本文档记录 UICore Style 层已确认的问题和处理状态，后续按编号逐项处理。

处理时遵循以下约束：

- 封闭选项只使用枚举，不使用对应字符串或无语义裸数字。
- C++ 与 QML 之间共享的枚举必须具有稳定、明确的数值契约。
- Style 层只保留通用视觉语义，不反向依赖 Forms、Shell、Task 等上层领域。
- 每次只处理当前问题需要的最小范围，不顺带重构无关代码。

## 第一轮：枚举定义与使用

### STYLE-ENUM-001 通用 Style 枚举在 C++ 与 QML 重复定义

**状态：** 已处理

`LayoutMode`、`ControlAppearance`、`ButtonVariant`、`ButtonSize` 和 `ShapeRole` 原本分别在 C++ 与 QML 中定义，成员依赖声明顺序对齐。

**处理结果：**

- `include/UICore/Style/UiStyleEnums.h` 是通用 Style 枚举的唯一来源。
- C++ 使用 `UICore::UiStyle::<Enum>::<Value>`。
- QML 通过 `import UICore.Style 1.0` 使用 `UiStyle.<Enum>.<Value>`，不再保留第二套定义。
- 枚举使用 `enum class` 和显式数值；AppForm、Forms schema 与 Task 等领域枚举不进入 `UiStyle`。

### STYLE-ENUM-002 QML 属性没有形成封闭枚举边界

**状态：** 已处理

`AppButton.variant`、`AppButton.size`、输入控件 `appearance`、表单 `layoutMode` 和基础控件 `shapeRole` 等属性原来使用 `var`，归一化函数同时接受枚举、数字和字符串。

**处理结果：**

- 上述纯 QML 属性已改用 `int`，基础控件不再直接接受字符串或任意对象。
- `ShapeRole.Auto` 取代 `undefined`，明确表达按 surface tone 自动选择形状的语义。
- 通用 Style 归一化函数已移除名称字符串解析。
- Forms schema、Shell 数据和其他上层输入必须提供对应的枚举整数。

**影响：** 拼写错误和非法值只能在运行时静默回退；枚举只是推荐写法，与 `CONVENTIONS.md` 中“不直接使用对应字符串”的约定不一致。

**验收标准：**

- 明确哪些属性是严格枚举，哪些输入确实需要兼容旧字符串数据。
- 严格枚举属性不再接受对应字符串。
- 兼容入口集中在数据边界，不扩散到基础控件内部。

### STYLE-ENUM-003 通用 Style 枚举归一化规则不一致

**状态：** 已处理

`Enums.qml` 中通用 Style 的 `normalize...()` 函数输入规则和非法值回退方式不一致，并在部分调用链中重复执行。

**处理结果：**

- 删除 `normalizeLayoutMode()`、`normalizeAppearance()`、`normalizeButtonVariant()`、`normalizeButtonSize()` 和 `normalizeShapeRole()`。
- 主题、皮肤和布局在实际消费枚举的位置直接判断。
- `ButtonVariant`、`ButtonSize` 等通过 `switch/default` 返回默认样式。
- `LayoutMode.Auto` 和 `ShapeRole.Auto` 由布局与形状计算的 `default` 路径处理。
- 删除仅被调用一次的 C++ 枚举归一化辅助函数。
- Forms schema 等领域枚举的归一化问题不属于通用 Style，随模块边界问题单独处理。

### STYLE-ENUM-004 C++ 与 QML 枚举命名不一致

**状态：** 已处理

C++ `AppFormField::Variant` 原来使用 `GhostVariant`，QML 使用 `ButtonVariant.Ghost`。根因是 C++ `Appearance` 与 `Variant` 都是非作用域枚举，两个枚举成员不能同时命名为 `Ghost`。

**处理结果：**

- `ControlAppearance` 与 `ButtonVariant` 改用 `enum class`。
- C++ 与 QML 统一使用 `ButtonVariant::Ghost` / `ButtonVariant.Ghost`。

### STYLE-ENUM-005 Foundation 枚举混入上层领域类型

**状态：** 已处理

`qml/foundation/Enums.qml` 随 `UICoreQuick` 打包，但同时定义了字段渲染类型和 Forms 领域类型。

**处理结果：**

- 字段渲染类型定义为 `AppField::Kind`，C++ 使用 `UICore::AppField::Kind::<Value>`。
- QML 通过 `import UICore.Fields 1.0` 使用 `AppField.Kind.<Value>`。
- Menu block 和 Form node 等结构枚举继续定义在 `UICore::UiForm`。
- `menuBlockKind` 和 `formNodeKind` 的 C++ 接口由裸 `int` 改为 `UiForm::MenuBlockKind` 和 `UiForm::NodeKind`。
- 删除 `qml/foundation/Enums.qml`、对应 `qmldir` 和 qrc 入口；不保留旧路径兼容，迁移方式记录在 `CHANGELIST.md`。

### STYLE-ENUM-006 Task 样式使用裸数字和状态字符串

**状态：** 暂缓

`AppTaskPanel.qml` 使用 `0` 至 `4` 解析 C++ `Task::Phase`，再转换成 `"ready"`、`"running"` 等字符串传给 Style；执行模式和派发方式也直接比较数值 `1`。

**影响：** Task 枚举顺序变化后，QML 样式和标签会静默映射错误；同一状态在 C++、QML 和 Style 中存在三套表达。

**验收标准：**

- Task 状态、执行模式和派发方式不再通过裸数字判断。
- Style 查找不再依赖重复的状态字符串转换。
- C++ 状态与 QML 呈现之间具有明确、稳定的契约。

### STYLE-ENUM-007 通用视觉语义角色使用字符串

**状态：** 已处理

`surfaceTone`、`textTone` 和 `styleRole` 原来使用 `"section"`、`"primary"`、`"bodyM"` 等字符串。当前实现只识别固定集合，任意新名称会静默回退，因此这些属性实际是封闭角色而不是扩展 Token。

**处理结果：**

- 在 `UiStyleEnums.h` 中新增 `SurfaceTone`、`TextTone` 和 `TypographyRole`。
- QML 公共视觉角色属性改为 `int`，统一使用 `UiStyle.<Enum>.<Value>`。
- `AppField.textTone/surfaceTone` 使用对应的 C++ 强类型枚举。
- 删除重复的字符串兼容属性和只读中间属性。
- 皮肤通过替换固定角色对应的颜色、字体等 Token 值实现；内部 Token 名称仍使用字符串。

## 建议处理顺序

1. `STYLE-ENUM-006`：暂缓。
