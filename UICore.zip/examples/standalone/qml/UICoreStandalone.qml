import QtQuick 2.14
import QtQuick.Controls 2.14
import "../theme" as Theme
import ".." as Ui

ApplicationWindow {
    id: window

    property QtObject appTheme: Theme.AppTheme {}

    x: -2000
    y: 0
    width: appTheme.metrics.windowWidth
    height: appTheme.metrics.windowHeight
    minimumWidth: appTheme.metrics.windowMinWidth
    minimumHeight: appTheme.metrics.windowMinHeight
    visible: true
    title: qsTr("UICore")
    color: appTheme.colors.window
    Component.onCompleted: {
        showMaximized()
    }

    Ui.AppShell {
        anchors.fill: parent
        hostWindow: window
        applicationTitle: qsTr("UICore")
        showWindowControls: false
        drawers: []
        activeDrawerKey: ""
        drawerOpen: false
        rightPanelOpen: false
        canvasDelegateSource: "qrc:/UICore/qml/standalone/UICoreGallery.qml"
        selectionData: ({})
    }
}
