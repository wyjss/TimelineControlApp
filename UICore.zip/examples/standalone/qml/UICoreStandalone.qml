import QtQuick 2.14
import QtQuick.Controls 2.14
import "../theme" as Theme
import ".." as Ui

ApplicationWindow {
    id: window

    property QtObject appTheme: Theme.AppTheme {}

    width: appTheme.metrics.windowWidth
    height: appTheme.metrics.windowHeight
    minimumWidth: appTheme.metrics.windowMinWidth
    minimumHeight: appTheme.metrics.windowMinHeight
    visible: true
    title: qsTr("UICore")
    color: appTheme.colors.window

    Ui.AppShell {
        anchors.fill: parent
        hostWindow: window
        applicationTitle: qsTr("UICore")
        showWindowControls: false
        drawers: []
        activeDrawerKey: ""
        drawerOpen: false
        rightPanelOpen: false
        selectionData: ({})
    }
}
