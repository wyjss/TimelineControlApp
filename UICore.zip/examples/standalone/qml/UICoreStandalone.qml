import QtQuick 2.14
import ".." as Ui
import "qrc:/UICore/qml/menus" as Menus

Ui.AppWindow {
    id: window

    x: -2000
    y: 0
    visible: true
    Component.onCompleted: {
        showMaximized()
    }

    shell.applicationTitle: qsTr("UICore")
    shell.topMenuItems: [{
        "key": "overview",
        "label": qsTr("概览"),
        "iconName": "scene"
    }, {
        "key": "resources",
        "label": qsTr("资源"),
        "iconName": "resources"
    }]
    shell.activeTopMenuKey: "overview"
    shell.bottomMenuItems: [{
        "key": "tasks",
        "label": qsTr("任务"),
        "iconName": "background-task"
    }, {
        "key": "status",
        "label": qsTr("状态"),
        "iconName": "workflow"
    }]
    shell.activeBottomMenuKey: "status"
    shell.navigationItems: [{
        "key": "components",
        "label": qsTr("组件"),
        "iconName": "workflow",
        "detail": qsTr("AppMenuModel 示例")
    }]
    shell.activeNavigationKey: "components"
    shell.leftPaneOpen: true
    shell.leftPanelWidth: demoMenuModel.paneWidth
    shell.leftPaneContent: Component {
        Menus.AppMenuPane {
            menuKey: "components"
            paneController: demoMenuModel
        }
    }
    shell.rightPanelOpen: false
    shell.canvasDelegateSource: "qrc:/UICore/qml/standalone/UICoreGallery.qml"

    Connections {
        target: window.shell

        function onNavigationRequested(key) {
            window.shell.activeNavigationKey = key
        }

        function onLeftPaneOpenRequested(open) {
            window.shell.leftPaneOpen = open
        }

        function onSidebarOpenRequested(open) {
            window.shell.sidebarOpen = open
        }

        function onTopMenuItemRequested(key) {
            window.shell.activeTopMenuKey = key
        }

        function onBottomMenuItemRequested(key) {
            window.shell.activeBottomMenuKey = key
        }
    }
}
