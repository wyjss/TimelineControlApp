import QtQuick 2.14
import QtQuick.Controls 2.14
import QtQuick.Layouts 1.14
import UICore.Fields 1.0
import UICore.Style 1.0
import "qrc:/UICore/qml/components/base" as Base
import "qrc:/UICore/qml/components/field" as Field
import "qrc:/UICore/qml/components/form" as Form

Item {
    id: root

    readonly property QtObject density: ApplicationWindow.window.appTheme.density
    readonly property QtObject metrics: ApplicationWindow.window.appTheme.metrics

    property string lastEvent: qsTr("等待交互")
    property string selectedMode: "balanced"
    property string selectedRegion: "east"
    property bool featureEnabled: true
    property real intensityValue: 42

    property var demoFormData: ({
        "layoutMode": UiStyle.LayoutMode.Horizontal,
        "horizontalBreakpoint": root.metrics.layoutBreakpointMd,
        "labelWidth": 140,
        "fieldSpacing": root.density.paneSpacing,
        "sectionSpacing": root.density.panePadding,
        "showFieldUnderline": true,
        "sections": [
            {
                "key": "general",
                "title": qsTr("常规字段"),
                "collapsible": true,
                "expanded": true,
                "controls": [
                    nameField,
                    refreshField,
                    regionField,
                    enabledField,
                    intensityField
                ]
            },
            {
                "key": "renderers",
                "title": qsTr("其它 Renderer"),
                "collapsible": true,
                "expanded": true,
                "controls": [
                    summaryField,
                    segmentedField,
                    choiceField,
                    colorField,
                    chipsField,
                    customField,
                    actionField
                ]
            }
        ]
    })

    AppField {
        id: nameField

        kind: AppField.Kind.TextField
        valueType: BaseField.StringType
        key: "name"
        label: qsTr("名称")
        subtitle: qsTr("普通文本字段")
        value: qsTr("UICore 示例")
        placeholderText: qsTr("请输入名称")
    }

    AppField {
        id: refreshField

        kind: AppField.Kind.TextField
        valueType: BaseField.IntType
        key: "refreshRate"
        label: qsTr("刷新频率")
        subtitle: qsTr("候选值可选，也可以继续输入")
        value: 60
        options: [30, 60, 90, 120]
        allowCustomValue: true
        suffix: " Hz"
    }

    AppField {
        id: regionField

        kind: AppField.Kind.Select
        valueType: BaseField.EnumType
        key: "region"
        label: qsTr("区域")
        value: "east"
        options: [
            { "label": qsTr("东区"), "value": "east" },
            { "label": qsTr("西区"), "value": "west" },
            { "label": qsTr("中心区"), "value": "central" }
        ]
    }

    AppField {
        id: enabledField

        kind: AppField.Kind.Toggle
        valueType: BaseField.BoolType
        key: "enabled"
        label: qsTr("启用功能")
        subtitle: qsTr("布尔值 Toggle")
        value: true
    }

    AppField {
        id: intensityField

        kind: AppField.Kind.Slider
        valueType: BaseField.DoubleType
        key: "intensity"
        label: qsTr("强度")
        value: 42
        minimum: 0
        maximum: 100
        stepSize: 1
        suffix: "%"
    }

    AppField {
        id: summaryField

        kind: AppField.Kind.Summary
        key: "summary"
        label: qsTr("只读摘要")
        value: qsTr("适合显示状态、标识和较长的只读内容")
        readOnly: true
    }

    AppField {
        id: segmentedField

        kind: AppField.Kind.Segmented
        key: "quality"
        label: qsTr("质量")
        value: "balanced"
        options: [
            { "label": qsTr("性能"), "value": "fast" },
            { "label": qsTr("均衡"), "value": "balanced" },
            { "label": qsTr("质量"), "value": "quality" }
        ]
    }

    AppField {
        id: choiceField

        kind: AppField.Kind.Choice
        key: "accent"
        label: qsTr("强调色")
        value: "blue"
        options: [
            { "label": qsTr("蓝色"), "value": "blue", "color": "#60a5fa" },
            { "label": qsTr("绿色"), "value": "green", "color": "#34d399" },
            { "label": qsTr("橙色"), "value": "orange", "color": "#fb923c" }
        ]
    }

    AppField {
        id: colorField

        kind: AppField.Kind.Color
        key: "color"
        label: qsTr("颜色")
        value: "#7cb4ff"
    }

    AppField {
        id: chipsField

        kind: AppField.Kind.Chips
        key: "capabilities"
        label: qsTr("能力标签")
        items: [
            { "label": "QML", "active": true },
            { "label": "C++", "active": true },
            { "label": "Theme", "active": false }
        ]
        readOnly: true
    }

    AppField {
        id: customField

        kind: AppField.Kind.Custom
        key: "custom"
        label: qsTr("自定义字段")
        value: 0
        delegateSource: "qrc:/UICore/qml/standalone/UICoreGalleryCustomField.qml"
        customData: ({
            "note": qsTr("应用可以提供自己的字段 delegate")
        })
    }

    AppField {
        id: actionField

        kind: AppField.Kind.Button
        key: "action"
        value: qsTr("执行示例操作")
        actionId: "gallery.runAction"
        variant: UiStyle.ButtonVariant.Primary
        payload: ({ "source": "form" })
    }

    Base.AppScrollPane {
        id: galleryScrollPane

        anchors.fill: parent
        anchors.margins: root.density.panePadding
        contentSpacing: root.density.sectionSpacing

        Base.AppText {
            Layout.fillWidth: true
            text: qsTr("UICore 组件陈列")
            styleRole: UiStyle.TypographyRole.TitleL
            textTone: UiStyle.TextTone.Primary
        }

        Base.AppText {
            Layout.fillWidth: true
            text: qsTr("一个页面集中展示主题角色、基础控件、组合容器和字段渲染。所有组件都从窗口自动读取 appTheme。")
            styleRole: UiStyle.TypographyRole.BodyM
            textTone: UiStyle.TextTone.Secondary
            wrapMode: Text.WordWrap
        }

        Base.AppSurface {
            Layout.fillWidth: true
            Layout.preferredHeight: 56
            surfaceTone: UiStyle.SurfaceTone.Info
            shapeRole: UiStyle.ShapeRole.Section
            strokeWidth: 0
            padding: root.density.panePaddingCompact

            RowLayout {
                anchors.fill: parent
                spacing: root.density.controlGap

                Base.AppIcon {
                    name: "workflow"
                    size: 18
                }

                Base.AppText {
                    Layout.fillWidth: true
                    text: root.lastEvent
                    styleRole: UiStyle.TypographyRole.BodyM
                    textTone: UiStyle.TextTone.Info
                    elide: Text.ElideRight
                }

                Base.AppButton {
                    text: qsTr("打开弹层")
                    size: UiStyle.ButtonSize.Small
                    variant: UiStyle.ButtonVariant.Tonal
                    onClicked: galleryPopup.open()
                }
            }
        }

        Base.AppSection {
            Layout.fillWidth: true
            title: qsTr("排版与图标")
            subtitle: qsTr("TypographyRole、TextTone 与内置资源图标")
            showHeaderDivider: true
            clearFocusOnTap: true
            padding: 0
            contentSpacing: root.density.paneContentSpacing

            ColumnLayout {
                Layout.fillWidth: true
                spacing: 4

                Base.AppText {
                    text: qsTr("Title XL / 页面主标题")
                    styleRole: UiStyle.TypographyRole.TitleXL
                }

                Base.AppText {
                    text: qsTr("Title L / 内容标题")
                    styleRole: UiStyle.TypographyRole.TitleL
                }

                Base.AppText {
                    text: qsTr("Title M / 小标题")
                    styleRole: UiStyle.TypographyRole.TitleM
                }

                Base.AppText {
                    text: qsTr("Section Title / 分区标题")
                    styleRole: UiStyle.TypographyRole.SectionTitle
                }

                Base.AppText {
                    text: qsTr("Body L / 大号正文")
                    styleRole: UiStyle.TypographyRole.BodyL
                }

                Base.AppText {
                    text: qsTr("Body M / 正文文本")
                    styleRole: UiStyle.TypographyRole.BodyM
                    textTone: UiStyle.TextTone.Secondary
                }

                Base.AppText {
                    text: qsTr("Success · Warning · Danger · Info")
                    styleRole: UiStyle.TypographyRole.BodyS
                    textTone: UiStyle.TextTone.Success
                }

                Base.AppText {
                    text: qsTr("Label / 标签文本")
                    styleRole: UiStyle.TypographyRole.Label
                }
            }

            Flow {
                Layout.fillWidth: true
                Layout.preferredHeight: childrenRect.height
                spacing: root.density.paneSpacing

                Repeater {
                    model: [
                        { "label": qsTr("Primary"), "tone": UiStyle.TextTone.Primary },
                        { "label": qsTr("Secondary"), "tone": UiStyle.TextTone.Secondary },
                        { "label": qsTr("Accent"), "tone": UiStyle.TextTone.Accent },
                        { "label": qsTr("Success"), "tone": UiStyle.TextTone.Success },
                        { "label": qsTr("Warning"), "tone": UiStyle.TextTone.Warning },
                        { "label": qsTr("Info"), "tone": UiStyle.TextTone.Info },
                        { "label": qsTr("Neutral"), "tone": UiStyle.TextTone.Neutral },
                        { "label": qsTr("Danger"), "tone": UiStyle.TextTone.Danger },
                        { "label": qsTr("Inverse"), "tone": UiStyle.TextTone.Inverse }
                    ]

                    delegate: Base.AppText {
                        text: modelData.label
                        styleRole: UiStyle.TypographyRole.BodyM
                        textTone: modelData.tone
                    }
                }
            }

            Flow {
                Layout.fillWidth: true
                Layout.preferredHeight: childrenRect.height
                spacing: root.density.panePadding

                Repeater {
                    model: ["workflow", "layers", "resources", "weather", "play", "pause", "stop", "background-task"]

                    delegate: Column {
                        spacing: 5

                        Base.AppSurface {
                            width: 44
                            height: 44
                            sizeToContent: false
                            surfaceTone: UiStyle.SurfaceTone.Section
                            shapeRole: UiStyle.ShapeRole.Control

                            Base.AppIcon {
                                anchors.centerIn: parent
                                name: modelData
                                size: 20
                            }
                        }

                        Base.AppText {
                            anchors.horizontalCenter: parent.horizontalCenter
                            text: modelData
                            styleRole: UiStyle.TypographyRole.BodyS
                            textTone: UiStyle.TextTone.Secondary
                        }
                    }
                }
            }

            RowLayout {
                Layout.fillWidth: true
                spacing: root.density.panePadding

                Base.AppText {
                    text: qsTr("Source")
                    styleRole: UiStyle.TypographyRole.BodyS
                    textTone: UiStyle.TextTone.Secondary
                }

                Base.AppIcon {
                    source: "qrc:/UICore/assets/icons/play.svg"
                    size: 20
                }

                Base.AppText {
                    text: qsTr("Symbol")
                    styleRole: UiStyle.TypographyRole.BodyS
                    textTone: UiStyle.TextTone.Secondary
                }

                Base.AppIcon {
                    symbol: "★"
                    size: 20
                }

                Base.AppText {
                    text: qsTr("Missing/Fallback")
                    styleRole: UiStyle.TypographyRole.BodyS
                    textTone: UiStyle.TextTone.Secondary
                }

                Base.AppIcon {
                    symbol: "?"
                    size: 20
                }

                Base.AppText {
                    text: qsTr("No Tint")
                    styleRole: UiStyle.TypographyRole.BodyS
                    textTone: UiStyle.TextTone.Secondary
                }

                Base.AppIcon {
                    source: "qrc:/UICore/assets/icons/weather.svg"
                    tintSource: false
                    size: 20
                }

                Item {
                    Layout.fillWidth: true
                }
            }
        }

        Base.AppSection {
            Layout.fillWidth: true
            title: qsTr("表面与按钮")
            subtitle: qsTr("语义表面、按钮 Variant、尺寸、选中和禁用状态")
            showHeaderDivider: true
            clearFocusOnTap: true
            padding: 0
            contentSpacing: root.density.paneContentSpacing

            GridLayout {
                Layout.fillWidth: true
                columns: root.width >= root.metrics.layoutBreakpointLg
                    ? 4
                    : (root.width >= root.metrics.layoutBreakpointSm ? 2 : 1)
                columnSpacing: root.density.paneSpacing
                rowSpacing: root.density.paneSpacing

                Repeater {
                    model: [
                        { "label": qsTr("Surface"), "tone": UiStyle.SurfaceTone.Surface },
                        { "label": qsTr("Window"), "tone": UiStyle.SurfaceTone.Window },
                        { "label": qsTr("Surface Overlay"), "tone": UiStyle.SurfaceTone.SurfaceOverlay },
                        { "label": qsTr("Section"), "tone": UiStyle.SurfaceTone.Section },
                        { "label": qsTr("Section Overlay"), "tone": UiStyle.SurfaceTone.SectionOverlay },
                        { "label": qsTr("Canvas"), "tone": UiStyle.SurfaceTone.Canvas },
                        { "label": qsTr("Highlight"), "tone": UiStyle.SurfaceTone.Highlight },
                        { "label": qsTr("Success"), "tone": UiStyle.SurfaceTone.Success },
                        { "label": qsTr("Warning"), "tone": UiStyle.SurfaceTone.Warning },
                        { "label": qsTr("Info"), "tone": UiStyle.SurfaceTone.Info },
                        { "label": qsTr("Neutral"), "tone": UiStyle.SurfaceTone.Neutral },
                        { "label": qsTr("Danger"), "tone": UiStyle.SurfaceTone.Danger },
                        { "label": qsTr("Ghost"), "tone": UiStyle.SurfaceTone.Ghost }
                    ]

                    delegate: Base.AppSurface {
                        Layout.fillWidth: true
                        Layout.preferredHeight: 64
                        sizeToContent: false
                        surfaceTone: modelData.tone
                        shapeRole: UiStyle.ShapeRole.Section
                        padding: root.density.panePaddingCompact

                        Base.AppText {
                            anchors.centerIn: parent
                            text: modelData.label
                            styleRole: UiStyle.TypographyRole.Label
                        }
                    }
                }
            }

            Flow {
                Layout.fillWidth: true
                Layout.preferredHeight: childrenRect.height
                spacing: root.density.controlGap

                Base.AppButton {
                    text: qsTr("Primary")
                    variant: UiStyle.ButtonVariant.Primary
                    onClicked: root.lastEvent = qsTr("点击 Primary")
                }

                Base.AppButton {
                    text: qsTr("Secondary")
                    variant: UiStyle.ButtonVariant.Secondary
                    onClicked: root.lastEvent = qsTr("点击 Secondary")
                }

                Base.AppButton {
                    text: qsTr("Tonal")
                    variant: UiStyle.ButtonVariant.Tonal
                    onClicked: root.lastEvent = qsTr("点击 Tonal")
                }

                Base.AppButton {
                    text: qsTr("Ghost")
                    variant: UiStyle.ButtonVariant.Ghost
                    onClicked: root.lastEvent = qsTr("点击 Ghost")
                }

                Base.AppButton {
                    text: qsTr("Nav / Active")
                    variant: UiStyle.ButtonVariant.Nav
                    checkable: true
                    checked: true
                }

                Base.AppButton {
                    text: qsTr("Small")
                    size: UiStyle.ButtonSize.Small
                    iconName: "play"
                }

                Base.AppButton {
                    text: qsTr("Large")
                    size: UiStyle.ButtonSize.Large
                    iconName: "workflow"
                }

                Base.AppButton {
                    text: qsTr("Disabled")
                    enabled: false
                }

                Base.AppButton {
                    text: qsTr("Checkable")
                    checkable: true
                }

                Base.AppButton {
                    iconName: "weather"
                    Accessible.name: qsTr("纯图标按钮")
                }

                Base.AppButton {
                    text: qsTr("Start Aligned")
                    iconName: "layers"
                    minWidth: 170
                    contentAlignment: "start"
                }

                Base.AppButton {
                    text: qsTr("Highlighted")
                    highlighted: true
                }
            }

            Base.AppText {
                Layout.fillWidth: true
                text: qsTr("Hover、Pressed 与键盘 Focus 请直接在上方按钮上交互验证。")
                styleRole: UiStyle.TypographyRole.BodyS
                textTone: UiStyle.TextTone.Secondary
            }
        }

        Base.AppSection {
            Layout.fillWidth: true
            title: qsTr("输入与选择")
            subtitle: qsTr("普通、Ghost、候选输入、只读、禁用和不同选择形态")
            showHeaderDivider: true
            clearFocusOnTap: true
            padding: 0
            contentSpacing: root.density.paneContentSpacing

            GridLayout {
                Layout.fillWidth: true
                columns: root.width >= root.metrics.layoutBreakpointMd ? 2 : 1
                columnSpacing: root.density.panePadding
                rowSpacing: root.density.paneSpacing

                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: root.density.controlGap

                    Base.AppText {
                        text: qsTr("文本输入")
                        styleRole: UiStyle.TypographyRole.Label
                    }

                    Base.AppTextField {
                        Layout.fillWidth: true
                        placeholderText: qsTr("普通输入")
                        onTextChanged: root.lastEvent = qsTr("文本：%1").arg(text)
                    }

                    Base.AppTextField {
                        Layout.fillWidth: true
                        text: "60"
                        options: [30, 60, 90, 120]
                        placeholderText: qsTr("候选值仍可编辑")
                    }

                    Base.AppTextField {
                        Layout.fillWidth: true
                        text: qsTr("Ghost 外观")
                        appearance: UiStyle.ControlAppearance.Ghost
                    }

                    RowLayout {
                        Layout.fillWidth: true

                        Base.AppTextField {
                            Layout.fillWidth: true
                            text: qsTr("只读")
                            readOnly: true
                        }

                        Base.AppTextField {
                            Layout.fillWidth: true
                            text: qsTr("禁用")
                            enabled: false
                        }
                    }
                }

                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: root.density.controlGap

                    Base.AppText {
                        text: qsTr("Select 与开关")
                        styleRole: UiStyle.TypographyRole.Label
                    }

                    Base.AppSelect {
                        Layout.fillWidth: true
                        value: root.selectedRegion
                        placeholderText: qsTr("选择区域")
                        options: [
                            { "label": qsTr("东区"), "value": "east" },
                            { "label": qsTr("西区"), "value": "west" },
                            { "label": qsTr("中心区"), "value": "central" }
                        ]
                        onValueSelected: {
                            root.selectedRegion = nextValue
                            root.lastEvent = qsTr("区域：%1").arg(nextValue)
                        }
                    }

                    Base.AppSegmentedControl {
                        Layout.fillWidth: true
                        value: root.selectedMode
                        options: [
                            { "label": qsTr("性能"), "value": "fast" },
                            { "label": qsTr("均衡"), "value": "balanced" },
                            { "label": qsTr("质量"), "value": "quality" }
                        ]
                        onValueSelected: {
                            root.selectedMode = nextValue
                            root.lastEvent = qsTr("模式：%1").arg(nextValue)
                        }
                    }

                    Base.AppChoiceControl {
                        Layout.fillWidth: true
                        value: "green"
                        options: [
                            { "label": qsTr("蓝色"), "value": "blue", "color": "#60a5fa" },
                            { "label": qsTr("绿色"), "value": "green", "color": "#34d399" },
                            { "label": qsTr("橙色"), "value": "orange", "color": "#fb923c" }
                        ]
                        onValueSelected: root.lastEvent = qsTr("选项：%1").arg(nextValue)
                    }

                    RowLayout {
                        spacing: root.density.controlGap

                        Base.AppToggleControl {
                            checked: root.featureEnabled
                            onToggled: {
                                root.featureEnabled = nextChecked
                                root.lastEvent = nextChecked ? qsTr("功能已启用") : qsTr("功能已关闭")
                            }
                        }

                        Base.AppText {
                            text: root.featureEnabled ? qsTr("已启用") : qsTr("已关闭")
                            styleRole: UiStyle.TypographyRole.BodyM
                            textTone: root.featureEnabled
                                ? UiStyle.TextTone.Success
                                : UiStyle.TextTone.Secondary
                        }

                        Base.AppToggleControl {
                            checked: true
                            enabled: false
                        }
                    }
                }
            }

            GridLayout {
                Layout.fillWidth: true
                columns: root.width >= root.metrics.layoutBreakpointMd ? 2 : 1
                columnSpacing: root.density.panePadding
                rowSpacing: root.density.paneSpacing

                Base.AppSliderControl {
                    Layout.fillWidth: true
                    value: root.intensityValue
                    from: 0
                    to: 100
                    stepSize: 1
                    suffix: "%"
                    onValueEdited: {
                        root.intensityValue = nextValue
                        root.lastEvent = qsTr("强度：%1%").arg(Math.round(nextValue))
                    }
                }

                Base.AppColorControl {
                    Layout.fillWidth: true
                    value: "#7cb4ff"
                    onValueEdited: root.lastEvent = qsTr("颜色：%1").arg(String(nextValue))
                }
            }
        }

        Base.AppSection {
            Layout.fillWidth: true
            title: qsTr("输入组件状态矩阵")
            subtitle: qsTr("空值、强调、插槽、禁用、无选中、长内容和边界值")
            showHeaderDivider: true
            clearFocusOnTap: true
            padding: 0
            contentSpacing: root.density.paneContentSpacing

            Base.AppText {
                text: qsTr("TextField")
                styleRole: UiStyle.TypographyRole.Label
            }

            GridLayout {
                Layout.fillWidth: true
                columns: root.width >= root.metrics.layoutBreakpointLg
                    ? 3
                    : (root.width >= root.metrics.layoutBreakpointSm ? 2 : 1)
                columnSpacing: root.density.paneSpacing
                rowSpacing: root.density.paneSpacing

                Base.AppTextField {
                    Layout.fillWidth: true
                    placeholderText: qsTr("空值 / Placeholder")
                }

                Base.AppTextField {
                    Layout.fillWidth: true
                    text: qsTr("强调状态")
                    emphasized: true
                }

                Base.AppTextField {
                    Layout.fillWidth: true
                    text: qsTr("带前后插槽")
                    leadingContent: [
                        Base.AppIcon {
                            anchors.verticalCenter: parent.verticalCenter
                            name: "resources"
                            size: 16
                        }
                    ]
                    trailingContent: [
                        Base.AppText {
                            anchors.verticalCenter: parent.verticalCenter
                            text: qsTr("Ctrl E")
                            styleRole: UiStyle.TypographyRole.BodyS
                            textTone: UiStyle.TextTone.Secondary
                        }
                    ]
                }

                Base.AppTextField {
                    Layout.fillWidth: true
                    text: qsTr("只读状态")
                    readOnly: true
                }

                Base.AppTextField {
                    Layout.fillWidth: true
                    text: qsTr("禁用状态")
                    enabled: false
                }

                Base.AppTextField {
                    Layout.fillWidth: true
                    placeholderText: qsTr("点击并输入以验证 Focus")
                    options: [qsTr("候选一"), qsTr("候选二"), qsTr("候选三")]
                }
            }

            Base.AppText {
                text: qsTr("Select")
                styleRole: UiStyle.TypographyRole.Label
            }

            GridLayout {
                Layout.fillWidth: true
                columns: root.width >= root.metrics.layoutBreakpointLg
                    ? 3
                    : (root.width >= root.metrics.layoutBreakpointSm ? 2 : 1)
                columnSpacing: root.density.paneSpacing
                rowSpacing: root.density.paneSpacing

                Base.AppSelect {
                    Layout.fillWidth: true
                    placeholderText: qsTr("空值 / Placeholder")
                    options: [
                        { "label": qsTr("选项 A"), "value": "a" },
                        { "label": qsTr("选项 B"), "value": "b" }
                    ]
                }

                Base.AppSelect {
                    Layout.fillWidth: true
                    value: "a"
                    appearance: UiStyle.ControlAppearance.Ghost
                    options: [
                        { "label": qsTr("Ghost A"), "value": "a" },
                        { "label": qsTr("Ghost B"), "value": "b" }
                    ]
                }

                Base.AppSelect {
                    Layout.fillWidth: true
                    value: "b"
                    readOnly: true
                    options: [
                        { "label": qsTr("只读 A"), "value": "a" },
                        { "label": qsTr("只读 B"), "value": "b" }
                    ]
                }

                Base.AppSelect {
                    Layout.fillWidth: true
                    value: "b"
                    enabled: false
                    options: [
                        { "label": qsTr("禁用 A"), "value": "a" },
                        { "label": qsTr("禁用 B"), "value": "b" }
                    ]
                }

                Base.AppSelect {
                    Layout.fillWidth: true
                    value: "item-1"
                    maxPopupHeight: 120
                    options: [
                        { "label": qsTr("长列表项目 01"), "value": "item-1" },
                        { "label": qsTr("长列表项目 02"), "value": "item-2" },
                        { "label": qsTr("长列表项目 03"), "value": "item-3" },
                        { "label": qsTr("长列表项目 04"), "value": "item-4" },
                        { "label": qsTr("长列表项目 05"), "value": "item-5" },
                        { "label": qsTr("长列表项目 06"), "value": "item-6" },
                        { "label": qsTr("长列表项目 07"), "value": "item-7" },
                        { "label": qsTr("长列表项目 08"), "value": "item-8" }
                    ]
                }

                Base.AppSelect {
                    Layout.fillWidth: true
                    value: "earth"
                    emphasized: true
                    options: [
                        { "label": qsTr("地球"), "value": "earth" },
                        { "label": qsTr("资源"), "value": "resource" }
                    ]
                    leadingContent: [
                        Base.AppIcon {
                            anchors.verticalCenter: parent.verticalCenter
                            name: "scene"
                            size: 16
                        }
                    ]
                    trailingContent: [
                        Base.AppText {
                            anchors.verticalCenter: parent.verticalCenter
                            text: qsTr("推荐")
                            styleRole: UiStyle.TypographyRole.BodyS
                            textTone: UiStyle.TextTone.Success
                        }
                    ]
                }
            }

            Base.AppText {
                text: qsTr("Segmented 与 Choice")
                styleRole: UiStyle.TypographyRole.Label
            }

            GridLayout {
                Layout.fillWidth: true
                columns: root.width >= root.metrics.layoutBreakpointMd ? 2 : 1
                columnSpacing: root.density.paneSpacing
                rowSpacing: root.density.paneSpacing

                Base.AppSegmentedControl {
                    Layout.fillWidth: true
                    value: ""
                    options: [
                        { "label": qsTr("无选中 A"), "value": "a" },
                        { "label": qsTr("无选中 B"), "value": "b" }
                    ]
                }

                Base.AppSegmentedControl {
                    Layout.fillWidth: true
                    value: "a"
                    enabled: false
                    options: [
                        { "label": qsTr("禁用 A"), "value": "a" },
                        { "label": qsTr("禁用 B"), "value": "b" }
                    ]
                }

                Base.AppSegmentedControl {
                    Layout.fillWidth: true
                    value: "balanced"
                    options: [
                        { "label": qsTr("较长的性能优先"), "value": "fast" },
                        { "label": qsTr("较长的均衡模式"), "value": "balanced" },
                        { "label": qsTr("较长的质量优先"), "value": "quality" }
                    ]
                }

                Base.AppChoiceControl {
                    Layout.fillWidth: true
                    value: ""
                    options: [
                        { "label": qsTr("无选中"), "value": "none" },
                        { "label": qsTr("纯文字"), "value": "text" }
                    ]
                }

                Base.AppChoiceControl {
                    Layout.fillWidth: true
                    value: "play"
                    options: [
                        { "label": qsTr("播放"), "value": "play", "iconName": "play" },
                        { "label": qsTr("暂停"), "value": "pause", "iconName": "pause" },
                        { "label": qsTr("停止"), "value": "stop", "iconName": "stop" }
                    ]
                }

                Base.AppChoiceControl {
                    Layout.fillWidth: true
                    value: "a"
                    enabled: false
                    options: [
                        { "label": qsTr("禁用 A"), "value": "a", "color": "#60a5fa" },
                        { "label": qsTr("禁用 B"), "value": "b", "color": "#34d399" }
                    ]
                }
            }

            Base.AppText {
                text: qsTr("Toggle")
                styleRole: UiStyle.TypographyRole.Label
            }

            Flow {
                Layout.fillWidth: true
                Layout.preferredHeight: childrenRect.height
                spacing: root.density.panePadding

                Row {
                    spacing: root.density.controlGap

                    Base.AppToggleControl {
                        checked: false
                    }

                    Base.AppText {
                        anchors.verticalCenter: parent.verticalCenter
                        text: qsTr("关闭")
                        styleRole: UiStyle.TypographyRole.BodyS
                    }
                }

                Row {
                    spacing: root.density.controlGap

                    Base.AppToggleControl {
                        checked: true
                    }

                    Base.AppText {
                        anchors.verticalCenter: parent.verticalCenter
                        text: qsTr("开启")
                        styleRole: UiStyle.TypographyRole.BodyS
                    }
                }

                Row {
                    spacing: root.density.controlGap

                    Base.AppToggleControl {
                        checked: false
                        enabled: false
                    }

                    Base.AppText {
                        anchors.verticalCenter: parent.verticalCenter
                        text: qsTr("禁用关闭")
                        styleRole: UiStyle.TypographyRole.BodyS
                        textTone: UiStyle.TextTone.Secondary
                    }
                }

                Row {
                    spacing: root.density.controlGap

                    Base.AppToggleControl {
                        checked: true
                        enabled: false
                    }

                    Base.AppText {
                        anchors.verticalCenter: parent.verticalCenter
                        text: qsTr("禁用开启")
                        styleRole: UiStyle.TypographyRole.BodyS
                        textTone: UiStyle.TextTone.Secondary
                    }
                }
            }

            Base.AppText {
                text: qsTr("Slider")
                styleRole: UiStyle.TypographyRole.Label
            }

            GridLayout {
                Layout.fillWidth: true
                columns: root.width >= root.metrics.layoutBreakpointLg
                    ? 3
                    : (root.width >= root.metrics.layoutBreakpointSm ? 2 : 1)
                columnSpacing: root.density.panePadding
                rowSpacing: root.density.paneSpacing

                Repeater {
                    model: [
                        { "value": 0, "from": 0, "to": 100, "step": 1, "suffix": "%", "enabled": true, "showLabel": true },
                        { "value": 50, "from": 0, "to": 100, "step": 1, "suffix": "%", "enabled": true, "showLabel": true },
                        { "value": 100, "from": 0, "to": 100, "step": 1, "suffix": "%", "enabled": true, "showLabel": true },
                        { "value": 70, "from": 0, "to": 100, "step": 1, "suffix": "%", "enabled": false, "showLabel": true },
                        { "value": 0.35, "from": 0, "to": 1, "step": 0.05, "suffix": "", "enabled": true, "showLabel": true },
                        { "value": 40, "from": 0, "to": 100, "step": 1, "suffix": "", "enabled": true, "showLabel": false }
                    ]

                    delegate: Item {
                        Layout.fillWidth: true
                        Layout.preferredHeight: stateSlider.implicitHeight
                        property real currentValue: Number(modelData.value)

                        Base.AppSliderControl {
                            id: stateSlider

                            anchors.fill: parent
                            value: parent.currentValue
                            from: Number(modelData.from)
                            to: Number(modelData.to)
                            stepSize: Number(modelData.step)
                            suffix: String(modelData.suffix)
                            enabled: !!modelData.enabled
                            showValueLabel: !!modelData.showLabel
                            onValueEdited: parent.currentValue = nextValue
                        }
                    }
                }
            }

            Base.AppText {
                text: qsTr("Color")
                styleRole: UiStyle.TypographyRole.Label
            }

            GridLayout {
                Layout.fillWidth: true
                columns: root.width >= root.metrics.layoutBreakpointLg
                    ? 4
                    : (root.width >= root.metrics.layoutBreakpointSm ? 2 : 1)
                columnSpacing: root.density.paneSpacing
                rowSpacing: root.density.paneSpacing

                Item {
                    Layout.fillWidth: true
                    Layout.preferredHeight: emptyColorControl.implicitHeight

                    Base.AppColorControl {
                        id: emptyColorControl

                        anchors.fill: parent
                        value: ""
                        placeholderText: qsTr("空值")
                    }
                }

                Item {
                    Layout.fillWidth: true
                    Layout.preferredHeight: invalidColorControl.implicitHeight

                    Base.AppColorControl {
                        id: invalidColorControl

                        anchors.fill: parent
                        value: "NOT-A-COLOR"
                    }
                }

                Item {
                    Layout.fillWidth: true
                    Layout.preferredHeight: opaqueColorControl.implicitHeight

                    Base.AppColorControl {
                        id: opaqueColorControl

                        anchors.fill: parent
                        value: "#807CB4FF"
                        showAlphaChannel: false
                    }
                }

                Item {
                    Layout.fillWidth: true
                    Layout.preferredHeight: disabledColorControl.implicitHeight

                    Base.AppColorControl {
                        id: disabledColorControl

                        anchors.fill: parent
                        value: "#7CB4FF"
                        enabled: false
                    }
                }
            }
        }

        Base.AppSection {
            Layout.fillWidth: true
            title: qsTr("容器与折叠")
            subtitle: qsTr("Panel、Section、header actions 和折叠动画")
            showHeaderDivider: true
            clearFocusOnTap: true
            padding: 0
            contentSpacing: root.density.paneContentSpacing

            Base.AppPanel {
                Layout.fillWidth: true
                title: qsTr("可折叠 Panel")
                subtitle: qsTr("标题、描述、Header Action 和正文内容")
                collapsible: true
                expanded: true
                bodyFillHeight: false
                surfaceTone: UiStyle.SurfaceTone.SurfaceOverlay
                padding: root.density.panePaddingCompact
                contentSpacing: root.density.paneContentSpacing
                headerActions: [
                    Base.AppButton {
                        text: qsTr("操作")
                        size: UiStyle.ButtonSize.Small
                        variant: UiStyle.ButtonVariant.Ghost
                        onClicked: root.lastEvent = qsTr("点击 Panel Header Action")
                    }
                ]

                Base.AppText {
                    Layout.fillWidth: true
                    text: qsTr("Panel 适合承载独立工具、详情块或浮层内容。点击标题右侧的折叠按钮可以查看展开动画。")
                    styleRole: UiStyle.TypographyRole.BodyM
                    textTone: UiStyle.TextTone.Secondary
                    wrapMode: Text.WordWrap
                }
            }

            Base.AppSection {
                Layout.fillWidth: true
                title: qsTr("嵌套 Section")
                subtitle: qsTr("Flat 内容也可以按需切换 surfaced")
                surfaced: false
                compact: true
                padding: 0

                Base.AppText {
                    Layout.fillWidth: true
                    text: qsTr("这个 Section 不创建额外表面，适合页面内部的轻量分组。")
                    styleRole: UiStyle.TypographyRole.BodyS
                    textTone: UiStyle.TextTone.Secondary
                    wrapMode: Text.WordWrap
                }
            }

            Base.AppPanel {
                Layout.fillWidth: true
                title: qsTr("初始收起 Panel")
                subtitle: qsTr("用于检查收起高度和再次展开")
                collapsible: true
                expanded: false
                bodyFillHeight: false
                surfaceTone: UiStyle.SurfaceTone.SectionOverlay
                padding: root.density.panePaddingCompact

                Base.AppText {
                    Layout.fillWidth: true
                    text: qsTr("展开后显示的正文内容。")
                    styleRole: UiStyle.TypographyRole.BodyM
                }
            }

            Base.AppSection {
                Layout.fillWidth: true
                surfaced: true
                padding: root.density.panePaddingCompact

                Base.AppText {
                    Layout.fillWidth: true
                    text: qsTr("无标题 Section：只有正文，不创建空标题栏。")
                    styleRole: UiStyle.TypographyRole.BodyS
                    textTone: UiStyle.TextTone.Secondary
                }
            }

            Base.AppSection {
                Layout.fillWidth: true
                title: qsTr("多 Header Action")
                surfaced: false
                compact: true
                padding: 0
                headerActions: [
                    Base.AppButton {
                        iconName: "play"
                        size: UiStyle.ButtonSize.Small
                        variant: UiStyle.ButtonVariant.Ghost
                        Accessible.name: qsTr("播放")
                    },
                    Base.AppButton {
                        iconName: "stop"
                        size: UiStyle.ButtonSize.Small
                        variant: UiStyle.ButtonVariant.Ghost
                        Accessible.name: qsTr("停止")
                    }
                ]

                Base.AppText {
                    Layout.fillWidth: true
                    text: qsTr("用于检查多个标题操作与正文的布局。")
                    styleRole: UiStyle.TypographyRole.BodyS
                    textTone: UiStyle.TextTone.Secondary
                }
            }
        }

        Base.AppSection {
            Layout.fillWidth: true
            title: qsTr("字段块、背景、滚动与弹层")
            subtitle: qsTr("独立 AppFieldBlock、Backdrop、滚动边界和模态/非模态 Popup")
            showHeaderDivider: true
            clearFocusOnTap: true
            padding: 0
            contentSpacing: root.density.paneContentSpacing

            Base.AppText {
                text: qsTr("AppFieldBlock")
                styleRole: UiStyle.TypographyRole.Label
            }

            GridLayout {
                Layout.fillWidth: true
                columns: root.width >= root.metrics.layoutBreakpointMd ? 2 : 1
                columnSpacing: root.density.panePadding
                rowSpacing: root.density.paneSpacing

                Item {
                    Layout.fillWidth: true
                    Layout.preferredHeight: horizontalFieldBlock.implicitHeight

                    Base.AppFieldBlock {
                        id: horizontalFieldBlock

                        width: parent.width
                        height: implicitHeight
                        inheritFormDefaults: false
                        label: qsTr("水平字段")
                        subtitle: qsTr("字段范围下划线")
                        layoutMode: UiStyle.LayoutMode.Horizontal
                        labelWidth: 120
                        showUnderline: true
                        underlineScope: "field"
                        fieldControl: standaloneHorizontalField
                        fieldContentFillWidth: true

                        Base.AppTextField {
                            id: standaloneHorizontalField

                            Layout.fillWidth: true
                            text: qsTr("Horizontal")
                        }
                    }
                }

                Item {
                    Layout.fillWidth: true
                    Layout.preferredHeight: verticalFieldBlock.implicitHeight

                    Base.AppFieldBlock {
                        id: verticalFieldBlock

                        width: parent.width
                        height: implicitHeight
                        inheritFormDefaults: false
                        label: qsTr("垂直字段")
                        subtitle: qsTr("整行 Divider")
                        layoutMode: UiStyle.LayoutMode.Vertical
                        showDivider: true
                        fieldControl: standaloneVerticalField

                        Base.AppSelect {
                            id: standaloneVerticalField

                            Layout.fillWidth: true
                            value: "a"
                            options: [
                                { "label": qsTr("选项 A"), "value": "a" },
                                { "label": qsTr("选项 B"), "value": "b" }
                            ]
                        }
                    }
                }

                Item {
                    Layout.fillWidth: true
                    Layout.preferredHeight: disabledFieldBlock.implicitHeight

                    Base.AppFieldBlock {
                        id: disabledFieldBlock

                        width: parent.width
                        height: implicitHeight
                        inheritFormDefaults: false
                        label: qsTr("禁用字段")
                        subtitle: qsTr("禁用状态下划线")
                        layoutMode: UiStyle.LayoutMode.Horizontal
                        labelWidth: 120
                        showUnderline: true
                        fieldControl: standaloneDisabledField
                        fieldContentFillWidth: true

                        Base.AppTextField {
                            id: standaloneDisabledField

                            Layout.fillWidth: true
                            text: qsTr("Disabled")
                            enabled: false
                        }
                    }
                }

                Item {
                    Layout.fillWidth: true
                    Layout.preferredHeight: labelFreeFieldBlock.implicitHeight

                    Base.AppFieldBlock {
                        id: labelFreeFieldBlock

                        width: parent.width
                        height: implicitHeight
                        inheritFormDefaults: false
                        showLabel: false
                        showSubtitle: false
                        layoutMode: UiStyle.LayoutMode.Vertical
                        fieldControl: standaloneLabelFreeField

                        Base.AppTextField {
                            id: standaloneLabelFreeField

                            Layout.fillWidth: true
                            placeholderText: qsTr("无 Label 字段")
                        }
                    }
                }
            }

            Base.AppText {
                text: qsTr("AppBackdrop")
                styleRole: UiStyle.TypographyRole.Label
            }

            GridLayout {
                Layout.fillWidth: true
                columns: root.width >= root.metrics.layoutBreakpointMd ? 2 : 1
                columnSpacing: root.density.paneSpacing
                rowSpacing: root.density.paneSpacing

                Base.AppBackdrop {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 120
                    sizeToContent: false
                    clipContent: true

                    Base.AppText {
                        anchors.centerIn: parent
                        text: qsTr("Gradient + Primary/Secondary Glow")
                        styleRole: UiStyle.TypographyRole.Label
                    }
                }

                Base.AppBackdrop {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 120
                    sizeToContent: false
                    clipContent: true
                    showGradient: false
                    showPrimaryGlow: false
                    showSecondaryGlow: false

                    Base.AppSurface {
                        anchors.fill: parent
                        surfaceTone: UiStyle.SurfaceTone.Window
                        shapeRole: UiStyle.ShapeRole.Section

                        Base.AppText {
                            anchors.centerIn: parent
                            text: qsTr("Decorations Off")
                            styleRole: UiStyle.TypographyRole.Label
                            textTone: UiStyle.TextTone.Secondary
                        }
                    }
                }
            }

            Base.AppText {
                text: qsTr("AppScrollPane")
                styleRole: UiStyle.TypographyRole.Label
            }

            GridLayout {
                Layout.fillWidth: true
                columns: root.width >= root.metrics.layoutBreakpointLg ? 3 : 1
                columnSpacing: root.density.paneSpacing
                rowSpacing: root.density.paneSpacing

                Base.AppSurface {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 110
                    sizeToContent: false
                    surfaceTone: UiStyle.SurfaceTone.Surface
                    shapeRole: UiStyle.ShapeRole.Section
                    padding: root.density.panePaddingCompact

                    Base.AppScrollPane {
                        anchors.fill: parent
                        showEdgeHints: true

                        Base.AppText {
                            Layout.fillWidth: true
                            text: qsTr("无溢出：不显示滚动条和边缘提示。")
                            styleRole: UiStyle.TypographyRole.BodyS
                            textTone: UiStyle.TextTone.Secondary
                            wrapMode: Text.WordWrap
                        }
                    }
                }

                Base.AppSurface {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 110
                    sizeToContent: false
                    surfaceTone: UiStyle.SurfaceTone.Surface
                    shapeRole: UiStyle.ShapeRole.Section
                    padding: root.density.panePaddingCompact

                    Base.AppScrollPane {
                        anchors.fill: parent
                        contentSpacing: root.density.paneHeaderSpacing
                        showEdgeHints: true

                        Repeater {
                            model: 8

                            delegate: Base.AppText {
                                Layout.fillWidth: true
                                text: qsTr("纵向滚动项目 %1").arg(index + 1)
                                styleRole: UiStyle.TypographyRole.BodyS
                            }
                        }
                    }
                }

                Base.AppSurface {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 110
                    sizeToContent: false
                    surfaceTone: UiStyle.SurfaceTone.Surface
                    shapeRole: UiStyle.ShapeRole.Section
                    padding: root.density.panePaddingCompact

                    Base.AppScrollPane {
                        anchors.fill: parent
                        fillContentWidth: false
                        allowHorizontalScroll: true
                        showEdgeHints: false

                        Base.AppSurface {
                            Layout.preferredWidth: 720
                            Layout.preferredHeight: 54
                            sizeToContent: false
                            surfaceTone: UiStyle.SurfaceTone.Highlight
                            shapeRole: UiStyle.ShapeRole.Control

                            Base.AppText {
                                anchors.centerIn: parent
                                text: qsTr("横向内容宽度 720px，可左右拖动")
                                styleRole: UiStyle.TypographyRole.BodyS
                                textTone: UiStyle.TextTone.Accent
                            }
                        }
                    }
                }
            }

            Flow {
                Layout.fillWidth: true
                Layout.preferredHeight: childrenRect.height
                spacing: root.density.controlGap

                Base.AppButton {
                    text: qsTr("打开模态 Popup")
                    variant: UiStyle.ButtonVariant.Primary
                    onClicked: galleryPopup.open()
                }

                Base.AppButton {
                    text: qsTr("打开非模态 Popup")
                    variant: UiStyle.ButtonVariant.Secondary
                    onClicked: nonModalPopup.open()
                }
            }
        }

        Base.AppSection {
            Layout.fillWidth: true
            title: qsTr("AppField 与 AppFormContent")
            subtitle: qsTr("覆盖 Text、Int 候选输入、Select、Toggle、Slider、Summary、Segmented、Choice、Color、Chips、Custom 和 Button")
            showHeaderDivider: true
            clearFocusOnTap: true
            padding: 0
            contentSpacing: root.density.paneContentSpacing

            Form.AppFormContent {
                Layout.fillWidth: true
                Layout.preferredHeight: implicitHeight
                formData: root.demoFormData

                onFieldEdited: {
                    switch (fieldKey) {
                    case "name":
                        nameField.value = value
                        break
                    case "refreshRate":
                        refreshField.value = value
                        break
                    case "region":
                        regionField.value = value
                        break
                    case "enabled":
                        enabledField.value = value
                        break
                    case "intensity":
                        intensityField.value = value
                        break
                    case "quality":
                        segmentedField.value = value
                        break
                    case "accent":
                        choiceField.value = value
                        break
                    case "color":
                        colorField.value = value
                        break
                    case "custom":
                        customField.value = value
                        break
                    default:
                        break
                    }

                    root.lastEvent = qsTr("字段 %1：%2").arg(fieldKey).arg(String(value))
                }

                onActionTriggered: {
                    root.lastEvent = qsTr("Action：%1").arg(actionId)
                    if (actionId === "gallery.runAction")
                        galleryPopup.open()
                }
            }
        }

        Item {
            Layout.fillWidth: true
            Layout.preferredHeight: 12
        }
    }

    MouseArea {
        parent: galleryScrollPane.flickableItem.contentItem
        anchors.fill: parent
        z: -1
        acceptedButtons: Qt.LeftButton
        onClicked: root.forceActiveFocus(Qt.MouseFocusReason)
    }

    Base.AppPopup {
        id: galleryPopup

        parent: root
        x: Math.max(16, (root.width - width) / 2)
        y: Math.max(16, (root.height - height) / 2)
        width: Math.min(380, root.width - 32)
        modal: true
        showModalOverlay: true
        surfaceTone: UiStyle.SurfaceTone.SurfaceOverlay
        draggable: true
        dragHandle: popupTitle

        Base.AppText {
            id: popupTitle

            Layout.fillWidth: true
            text: qsTr("通用反馈弹层")
            styleRole: UiStyle.TypographyRole.SectionTitle
        }

        Base.AppText {
            Layout.fillWidth: true
            text: qsTr("AppPopup 可以承载确认、说明或轻量编辑内容，并自动使用主题的表面、圆角和动效。")
            styleRole: UiStyle.TypographyRole.BodyM
            textTone: UiStyle.TextTone.Secondary
            wrapMode: Text.WordWrap
        }

        RowLayout {
            Layout.fillWidth: true
            Layout.alignment: Qt.AlignRight

            Base.AppButton {
                text: qsTr("取消")
                variant: UiStyle.ButtonVariant.Ghost
                onClicked: galleryPopup.close()
            }

            Base.AppButton {
                text: qsTr("确认")
                variant: UiStyle.ButtonVariant.Primary
                onClicked: {
                    root.lastEvent = qsTr("弹层操作已确认")
                    galleryPopup.close()
                }
            }
        }
    }

    Base.AppPopup {
        id: nonModalPopup

        parent: root
        x: Math.max(16, root.width - width - 24)
        y: 72
        width: Math.min(320, root.width - 32)
        modal: false
        showModalOverlay: false
        closePolicy: Popup.CloseOnEscape | Popup.CloseOnPressOutside
        surfaceTone: UiStyle.SurfaceTone.SectionOverlay

        Base.AppText {
            Layout.fillWidth: true
            text: qsTr("非模态弹层")
            styleRole: UiStyle.TypographyRole.SectionTitle
        }

        Base.AppText {
            Layout.fillWidth: true
            text: qsTr("不创建遮罩，可以继续操作页面中的其他控件。")
            styleRole: UiStyle.TypographyRole.BodyM
            textTone: UiStyle.TextTone.Secondary
            wrapMode: Text.WordWrap
        }

        Base.AppButton {
            Layout.alignment: Qt.AlignRight
            text: qsTr("关闭")
            variant: UiStyle.ButtonVariant.Ghost
            onClicked: nonModalPopup.close()
        }
    }
}
