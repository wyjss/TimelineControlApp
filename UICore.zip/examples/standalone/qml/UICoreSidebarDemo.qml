import QtQuick 2.14
import QtQuick.Controls 2.14
import QtQuick.Layouts 1.14
import UICore.Style 1.0
import "qrc:/UICore/qml/components/base" as Base
import "qrc:/UICore/qml/components/shell" as Shell

ColumnLayout {
    id: root

    readonly property QtObject density: ApplicationWindow.window.appTheme.density
    readonly property QtObject motion: ApplicationWindow.window.appTheme.motion
    readonly property QtObject colors: ApplicationWindow.window.appTheme.colors
    readonly property var shell: ApplicationWindow.window ? ApplicationWindow.window.shell : null
    readonly property var sidebar: shell ? shell.sidebar : null
    readonly property var sidebarPane: shell ? shell.sidebarPane : null

    property bool initialized: false
    property Component defaultFooterContent: null
    property string contentMode: "menu"
    property string activeItemKey: "components"
    property bool showHeader: false
    property bool showFooter: true
    property bool sidebarOpened: true
    property bool sidebarAutoHideEnabled: false
    property bool paneOpened: true
    property bool paneAutoHideEnabled: false
    property bool paneAutoHideSuspended: false
    property bool paneExternalTriggerActive: false
    property bool animated: true
    property int revealDelay: motion.shellPanelRevealDelay
    property int hideDelay: motion.shellPanelHideDelay
    property var toggleOptions: [
        { "label": qsTr("Header 插槽"), "propertyName": "showHeader" },
        { "label": qsTr("Footer 插槽"), "propertyName": "showFooter" },
        { "label": qsTr("侧栏显示"), "propertyName": "sidebarOpened" },
        { "label": qsTr("侧栏自动隐藏"), "propertyName": "sidebarAutoHideEnabled" },
        { "label": qsTr("面板打开"), "propertyName": "paneOpened" },
        { "label": qsTr("面板自动隐藏"), "propertyName": "paneAutoHideEnabled" },
        { "label": qsTr("暂停面板隐藏"), "propertyName": "paneAutoHideSuspended" },
        { "label": qsTr("面板外部触发"), "propertyName": "paneExternalTriggerActive" },
        { "label": qsTr("动画"), "propertyName": "animated" }
    ]

    signal eventTriggered(string message)

    spacing: density.paneContentSpacing

    Component.onCompleted: {
        defaultFooterContent = sidebar.footerContent
        activeItemKey = sidebar.activeItemKey
        sidebarOpened = shell.sidebarOpen
        sidebarAutoHideEnabled = sidebar.autoHideEnabled
        paneOpened = shell.leftPaneOpen
        paneAutoHideEnabled = shell.leftPanelAutoHide
        paneAutoHideSuspended = shell.leftPanelAutoHideSuspended
        paneExternalTriggerActive = shell.leftPanelAutoHideTriggerActive
        animated = sidebarPane.animated
        revealDelay = sidebarPane.revealDelay
        hideDelay = sidebarPane.hideDelay
        initialized = true
    }

    Binding {
        target: root.sidebar
        property: "headerContent"
        value: root.showHeader ? sidebarHeaderComponent : null
        when: root.initialized
    }

    Binding {
        target: root.sidebar
        property: "content"
        value: root.contentMode === "custom" ? sidebarCustomContentComponent : null
        when: root.initialized
    }

    Binding {
        target: root.sidebar
        property: "footerContent"
        value: root.showFooter ? root.defaultFooterContent : null
        when: root.initialized
    }

    Binding {
        target: root.sidebar
        property: "menuItems"
        value: root.contentMode === "blank" ? [] : root.shell.navigationItems
        when: root.initialized
    }

    Binding {
        target: root.sidebar
        property: "activeItemKey"
        value: root.activeItemKey
        when: root.initialized
    }

    Binding {
        target: root.sidebar
        property: "animated"
        value: root.animated
        when: root.initialized
    }

    Binding {
        target: root.sidebarPane
        property: "animated"
        value: root.animated
        when: root.initialized
    }

    Binding {
        target: root.sidebarPane
        property: "revealDelay"
        value: root.revealDelay
        when: root.initialized
    }

    Binding {
        target: root.sidebarPane
        property: "hideDelay"
        value: root.hideDelay
        when: root.initialized
    }

    Binding {
        target: root.shell
        property: "leftPanelAutoHideSuspended"
        value: root.paneAutoHideSuspended
        when: root.initialized
    }

    Binding {
        target: root.shell
        property: "leftPanelAutoHideTriggerActive"
        value: root.paneExternalTriggerActive
        when: root.initialized
    }

    Connections {
        target: root.sidebar

        function onItemTriggered(key) {
            root.activeItemKey = key
            root.eventTriggered(qsTr("AppSidebar 触发：%1").arg(key))
        }

        function onAutoHideEnabledChanged() {
            root.sidebarAutoHideEnabled = root.sidebar.autoHideEnabled
        }
    }

    Connections {
        target: root.shell

        function onLeftPaneOpenChanged() {
            root.paneOpened = root.shell.leftPaneOpen
        }

        function onSidebarOpenChanged() {
            root.sidebarOpened = root.shell.sidebarOpen
        }

        function onLeftPanelAutoHideChanged() {
            root.paneAutoHideEnabled = root.shell.leftPanelAutoHide
        }

        function onActiveNavigationKeyChanged() {
            if (root.contentMode === "menu")
                root.activeItemKey = root.shell.activeNavigationKey
        }
    }

    Base.AppSurface {
        Layout.fillWidth: true
        Layout.preferredHeight: 72
        sizeToContent: false
        surfaceTone: UiStyle.SurfaceTone.Info
        shapeRole: UiStyle.ShapeRole.Section
        strokeWidth: 0
        padding: root.density.panePaddingCompact

        RowLayout {
            anchors.fill: parent
            spacing: root.density.controlGap

            Base.AppIcon {
                name: "layers"
                size: 18
            }

            Base.AppText {
                Layout.fillWidth: true
                text: qsTr("AppSidebar 独立控制自身显隐和自动隐藏；AppSidebarPane 独立控制展开面板。leftContentInset 只读取 Sidebar 实际占用的宽度。")
                styleRole: UiStyle.TypographyRole.BodyM
                textTone: UiStyle.TextTone.Info
                wrapMode: Text.WordWrap
            }
        }
    }

    Base.AppText {
        text: qsTr("主体内容")
        styleRole: UiStyle.TypographyRole.Label
    }

    Base.AppSegmentedControl {
        Layout.fillWidth: true
        value: root.contentMode
        options: [
            { "label": qsTr("默认菜单"), "value": "menu" },
            { "label": qsTr("自定义"), "value": "custom" },
            { "label": qsTr("空白"), "value": "blank" }
        ]
        onValueSelected: {
            root.contentMode = nextValue
            root.eventTriggered(qsTr("AppSidebar 内容：%1").arg(nextValue))
        }
    }

    Base.AppText {
        text: qsTr("默认菜单选中项")
        styleRole: UiStyle.TypographyRole.Label
    }

    Base.AppSegmentedControl {
        Layout.fillWidth: true
        value: root.activeItemKey
        options: [
            { "label": qsTr("无"), "value": "" },
            { "label": qsTr("组件"), "value": "components" }
        ]
        onValueSelected: root.activeItemKey = nextValue
    }

    GridLayout {
        id: toggleGrid

        Layout.fillWidth: true
        columns: width >= 700 ? 2 : 1
        columnSpacing: root.density.panePadding
        rowSpacing: root.density.controlGap

        Repeater {
            model: root.toggleOptions

            delegate: RowLayout {
                Layout.fillWidth: true
                spacing: root.density.controlGap

                Base.AppText {
                    Layout.fillWidth: true
                    text: modelData.label
                    styleRole: UiStyle.TypographyRole.BodyS
                    textTone: UiStyle.TextTone.Secondary
                }

                Base.AppToggleControl {
                    checked: !!root[modelData.propertyName]
                    onToggled: {
                        root[modelData.propertyName] = checked

                        if (modelData.propertyName === "sidebarOpened")
                            root.shell.sidebarOpen = checked
                        else if (modelData.propertyName === "sidebarAutoHideEnabled")
                            root.sidebar.autoHideEnabled = checked
                        else if (modelData.propertyName === "paneOpened")
                            root.shell.leftPaneOpen = checked
                        else if (modelData.propertyName === "paneAutoHideEnabled")
                            root.shell.leftPanelAutoHide = checked

                        root.eventTriggered(qsTr("%1：%2").arg(modelData.label).arg(
                            checked ? qsTr("开启") : qsTr("关闭")))
                    }
                }
            }
        }
    }

    Base.AppText {
        text: qsTr("面板展开延迟：%1 ms").arg(root.revealDelay)
        styleRole: UiStyle.TypographyRole.BodyS
        textTone: UiStyle.TextTone.Secondary
    }

    Base.AppSliderControl {
        Layout.fillWidth: true
        value: root.revealDelay
        from: 0
        to: 1000
        stepSize: 20
        suffix: " ms"
        onValueEdited: root.revealDelay = Math.round(nextValue)
    }

    Base.AppText {
        text: qsTr("面板收起延迟：%1 ms").arg(root.hideDelay)
        styleRole: UiStyle.TypographyRole.BodyS
        textTone: UiStyle.TextTone.Secondary
    }

    Base.AppSliderControl {
        Layout.fillWidth: true
        value: root.hideDelay
        from: 0
        to: 1000
        stepSize: 20
        suffix: " ms"
        onValueEdited: root.hideDelay = Math.round(nextValue)
    }

    Component {
        id: sidebarHeaderComponent

        Item {
            implicitHeight: root.density.controlHeightLg + root.density.dividerThickness

            Base.AppSurface {
                anchors.top: parent.top
                anchors.left: parent.left
                anchors.right: parent.right
                height: root.density.controlHeightLg
                sizeToContent: false
                surfaceTone: UiStyle.SurfaceTone.Highlight
                shapeRole: UiStyle.ShapeRole.Control
                strokeWidth: 0

                Base.AppIcon {
                    anchors.centerIn: parent
                    name: "workflow"
                    size: 16
                    color: root.colors.inverseText
                }
            }

            Rectangle {
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.bottom: parent.bottom
                height: root.density.dividerThickness
                color: root.colors.border
            }
        }
    }

    Component {
        id: sidebarCustomContentComponent

        ColumnLayout {
            spacing: root.density.controlGap

            Shell.AppRailButton {
                Layout.alignment: Qt.AlignHCenter
                iconName: "weather"
                text: qsTr("自定义天气动作")
                animated: root.animated
                onClicked: root.eventTriggered(qsTr("点击自定义内容"))

                ToolTip.visible: hovered
                ToolTip.text: text
            }

            Shell.AppRailButton {
                Layout.alignment: Qt.AlignHCenter
                iconName: "resources"
                text: qsTr("自定义资源动作")
                animated: root.animated
                onClicked: root.eventTriggered(qsTr("点击自定义资源内容"))

                ToolTip.visible: hovered
                ToolTip.text: text
            }

            Item {
                Layout.fillHeight: true
            }
        }
    }
}
