#include <QApplication>
#include <QCoreApplication>
#include <QQmlApplicationEngine>
#include <QQuickStyle>
#include <QUrl>

#include <UICore/UICore.h>

int main(int argc, char *argv[])
{
    QQuickStyle::setStyle(QStringLiteral("Basic"));
    UICore::initialize();

    QApplication application(argc, argv);
    application.setOrganizationName(QStringLiteral("UICore"));
    application.setOrganizationDomain(QStringLiteral("uicore.local"));
    application.setApplicationName(QStringLiteral("UICore Standalone"));

    QQmlApplicationEngine engine;
    const QUrl mainUrl(QStringLiteral("qrc:/UICore/qml/standalone/UICoreStandalone.qml"));
    QObject::connect(&engine,
                     &QQmlApplicationEngine::objectCreated,
                     &application,
                     [mainUrl](QObject *object, const QUrl &url) {
                         if (!object && url == mainUrl)
                             QCoreApplication::exit(-1);
                     },
                     Qt::QueuedConnection);
    engine.load(mainUrl);

    return application.exec();
}
