#include <QApplication>
#include <QCoreApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QQuickStyle>
#include <QTimer>
#include <QUrl>

#include <UICore/Fields/AppField.h>
#include <UICore/Forms/AppForm.h>
#include <UICore/Forms/AppMenuModel.h>
#include <UICore/UICore.h>

int main(int argc, char *argv[])
{
    QQuickStyle::setStyle(QStringLiteral("Basic"));
    UICore::initialize();

    QApplication application(argc, argv);
    application.setOrganizationName(QStringLiteral("UICore"));
    application.setOrganizationDomain(QStringLiteral("uicore.local"));
    application.setApplicationName(QStringLiteral("UICore Standalone"));

    QQmlApplicationEngine engine;
    auto *menuModel = new UICore::AppMenuModel(&engine);
    menuModel->setTitle(QStringLiteral("组件设置"));
    menuModel->setSubtitle(QStringLiteral("AppMenuModel 示例"));
    menuModel->setPaneWidth(360);

    auto *menuForm = new UICore::AppForm;
    menuForm->setTitle(QStringLiteral("显示选项"));

    auto *nameField = new UICore::AppField;
    nameField->setKey(QStringLiteral("name"));
    nameField->setLabel(QStringLiteral("名称"));
    nameField->setValue(QStringLiteral("UICore 示例"));
    menuForm->appendField(nameField);

    auto *enabledField = new UICore::AppField;
    enabledField->setKind(UICore::AppField::Kind::Toggle);
    enabledField->setKey(QStringLiteral("enabled"));
    enabledField->setLabel(QStringLiteral("启用功能"));
    enabledField->setValue(true);
    menuForm->appendField(enabledField);

    menuModel->appendBlock(menuForm);
    engine.rootContext()->setContextProperty(QStringLiteral("demoMenuModel"), menuModel);

    const QUrl mainUrl(QStringLiteral("qrc:/UICore/qml/standalone/UICoreStandalone.qml"));
    QObject::connect(&engine,
                     &QQmlApplicationEngine::objectCreated,
                     &application,
                     [mainUrl](QObject *object, const QUrl &url) {
                         if (!object && url == mainUrl)
                             QCoreApplication::exit(-1);
                      },
                      Qt::QueuedConnection);
    engine.load(mainUrl);

    if (application.arguments().contains(QStringLiteral("--smoke-test")))
        QTimer::singleShot(5000, &application, &QCoreApplication::quit);

    return application.exec();
}
