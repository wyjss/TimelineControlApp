# UICore

UICore 是面向多个 Qt Quick 项目的通用 UI 基础模块。

代码风格、主题和接入约定见 [CONVENTIONS.md](CONVENTIONS.md)。

## 分层

- `UICore::Foundation`：字段等基础 C++ 模型，只依赖 Qt Core/Gui。
- `UICore::Quick`：主题、基础控件和图标资源。
- `UICore::Forms`：表单、菜单模型及 QML renderer。
- `UICore::Shell`：通用应用壳层、Drawer 和 Inspector。
- `UICore::Task`：独立任务模型及任务面板。
- `UICore::UICore`：聚合上述模块并负责资源初始化。

依赖方向为 `Foundation/Quick -> Forms -> Shell`，Task 保持独立。业务项目位于最上层，不允许反向进入 UICore。

## 目录

- `include/UICore`：对外公开头文件。
- `src`：按领域组织的 C++ 实现。
- `qml`：主题、基础组件及上层组件。
- `assets`：图标等静态资源。
- `resources`：Qt 资源清单。

## 接入

```cmake
add_subdirectory(path/to/UICore)
target_link_libraries(MyApp PRIVATE UICore::UICore)
```

创建 `QQmlEngine` 前注册静态资源：

```cpp
#include <UICore/UICore.h>

UICore::initialize();
```

当前 QML 资源路径保持兼容：

```qml
import "qrc:/UICore/qml/components/base" as Base
import "qrc:/UICore/qml/theme" as Theme
import "qrc:/UICore/qml" as Ui
```

应用窗口持有唯一主题上下文，UICore 组件会从所属窗口自动读取，不需要逐层传递：

```qml
ApplicationWindow {
    property QtObject appTheme: Theme.AppTheme {}

    Ui.AppShell {
        anchors.fill: parent
    }
}
```

`AppShell` 仅保留通用壳层能力。业务工具栏通过 `topBarContent`、`topBarActions` 注入，时间线、方案文件等业务内容不属于 UICore。
