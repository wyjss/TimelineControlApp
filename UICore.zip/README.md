# UICore

UICore 是面向多个 Qt Quick 项目的通用 UI 基础模块。

代码风格、主题和接入约定见 [CONVENTIONS.md](CONVENTIONS.md)。
Style 层问题及处理状态见 [STYLE_ISSUES.md](STYLE_ISSUES.md)。
Foundation 层问题见 [FOUNDATION_ISSUES.md](FOUNDATION_ISSUES.md)。
上层应用需要同步的公共用法变化见 [CHANGELIST.md](CHANGELIST.md)。

## 编译库

- `UICore::Core`：全部公共 C++ 类型，只依赖 Qt Core/Gui。
- `UICore::Quick`：全部 QML、主题、图标和资源初始化，公开依赖 `UICore::Core`。

Qt Quick 应用只需链接 `UICore::Quick`；仅使用 C++ 模型时可以单独链接 `UICore::Core`。

## Standalone 组件陈列

UICore 作为顶层项目编译时默认生成 `UICoreStandalone`。示例在一个可滚动页面中展示主题角色、基础控件、容器、弹层以及全部 `AppField` renderer：

```powershell
cmake -S . -B build
cmake --build build --config Release
.\build\Release\UICoreStandalone.exe
```

作为其它项目的子目录时，standalone 默认不参与构建；也可以通过 `-DUICORE_BUILD_STANDALONE=OFF` 显式关闭。

## 源码分层

- `Fields`：基础字段模型、通用 UI 字段 schema 和单字段渲染。
- `Style`：通用视觉、皮肤和布局语义。
- `Forms`：表单结构、布局和菜单模型。
- `Shell`：通用应用壳层、Drawer 和 Inspector。
- `Task`：独立任务模型及任务面板。

这些是源码逻辑层，不分别建立编译库。依赖方向为 `Fields/Style -> Forms -> Shell`，Task 不依赖 Forms 或 Shell；C++ 层不依赖 QML 或 Qt Quick 类型。

## 目录

- `include/UICore`：对外公开头文件。
- `src`：按领域组织的 C++ 实现。
- `qml`：主题、基础组件及上层组件。
- `assets`：图标等静态资源。
- `resources`：Qt 资源清单。

## 接入

```cmake
add_subdirectory(path/to/UICore)
target_link_libraries(MyApp PRIVATE UICore::Quick)
```

创建 `QQmlEngine` 前注册静态资源：

```cpp
#include <UICore/UICore.h>

UICore::initialize();
```

通用 Style 枚举以 `UiStyleEnums.h` 为唯一来源：

```cpp
#include <UICore/Style/UiStyleEnums.h>

auto mode = UICore::UiStyle::LayoutMode::Horizontal;
auto tone = UICore::UiStyle::SurfaceTone::Section;
```

```qml
import UICore.Style 1.0

property int layoutMode: UiStyle.LayoutMode.Horizontal
property int surfaceTone: UiStyle.SurfaceTone.Section
property int textTone: UiStyle.TextTone.Primary
property int styleRole: UiStyle.TypographyRole.BodyM
```

通用 UI 字段可在 C++ 或 QML 中创建，字段类型由 `AppField::Kind` 定义：

```cpp
#include <UICore/Fields/AppField.h>

auto kind = UICore::AppField::Kind::TextField;
```

```qml
import UICore.Fields 1.0
import "qrc:/UICore/qml/components/field" as Field

AppField {
    id: nameField
    kind: AppField.Kind.TextField
    label: "名称"
}

Field.AppFieldControl {
    fieldData: nameField
}
```

`AppField` 默认使用内部 `BaseField` 保存字段数据，也可以通过 `sourceField` 直接代理已有的 `BaseField`；代理模式不复制字段值。

Text、Int 和 Double 字段可以把 `options` 作为可编辑候选值：

```cpp
auto *field = new UICore::BaseField(parent);
field->setValueType(UICore::BaseField::IntType);
field->setEditorHint(UICore::BaseField::SelectEditor);
field->setOptions({30, 60, 90});
field->setAllowCustomValue(true);
```

`allowCustomValue` 默认为 `false`。`EnumType` 和封闭选择使用 `AppSelect`；允许自定义值时使用带候选下拉的 `AppTextField`。

当前 QML 资源路径保持兼容：

```qml
import "qrc:/UICore/qml/components/base" as Base
import "qrc:/UICore/qml/components/field" as Field
import "qrc:/UICore/qml/theme" as Theme
import "qrc:/UICore/qml" as Ui
```

应用窗口必须持有唯一且完整的主题上下文。当前 `Theme.AppTheme` 同时是标准主题和默认主题，UICore 组件会从所属窗口自动读取，不需要逐层传递：

```qml
ApplicationWindow {
    property QtObject appTheme: Theme.AppTheme {}

    Ui.AppShell {
        anchors.fill: parent
    }
}
```

组件不会为缺失的颜色、尺寸、字体、圆角或动画 Token 提供本地回退值。未设置 `appTheme` 或主题 Token 不完整时会直接产生 QML 错误，便于在接入阶段发现问题。

`AppShell` 仅保留通用壳层能力。业务工具栏通过 `topBarContent`、`topBarActions` 注入，时间线、方案文件等业务内容不属于 UICore。
