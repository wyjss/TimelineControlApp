# UICore

UICore 是面向多个 Qt Quick 项目的通用 UI 基础模块。

## 分层

- `UICore::Foundation`：字段等基础 C++ 模型，只依赖 Qt Core/Gui。
- `UICore::Quick`：主题、基础控件和图标资源。
- `UICore::Forms`：表单、菜单模型及 QML renderer。
- `UICore::Shell`：通用应用壳层、Drawer 和 Inspector。
- `UICore::Task`：独立任务模型及任务面板。
- `UICore::UICore`：聚合上述模块并负责资源初始化。

依赖方向为 `Foundation/Quick -> Forms -> Shell`，Task 保持独立。业务项目位于最上层，不允许反向进入 UICore。

## 接入

```cmake
add_subdirectory(path/to/UICore)
target_link_libraries(MyApp PRIVATE UICore::UICore)
```

创建 `QQmlEngine` 前注册静态资源：

```cpp
#include <UICore/UICore.h>

UICore::initialize();
```

当前 QML 资源路径保持兼容：

```qml
import "qrc:/UICore/qml/components/base" as Base
import "qrc:/UICore/qml/theme" as Theme
```

`AppShell` 仅保留通用壳层能力。业务工具栏通过 `topBarContent`、`topBarActions` 注入，时间线、方案文件等业务内容不属于 UICore。
