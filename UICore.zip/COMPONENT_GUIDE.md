# UICore 组件使用指南

本文档用于选择公共组件和确认调用边界。属性的完整定义以源码和公共头文件为准，迁移信息见 [CHANGELIST.md](CHANGELIST.md)。

## 1. 使用前提

Qt Quick 应用链接 `UICore::Quick`，并在创建 `QQmlEngine` 前调用 `UICore::initialize()`。应用窗口持有唯一主题：

```qml
import QtQuick.Controls 2.14
import "qrc:/UICore/qml/theme" as Theme

ApplicationWindow {
    property QtObject appTheme: Theme.AppTheme {}
}
```

常用导入：

```qml
import UICore.Fields 1.0
import UICore.Forms 1.0
import UICore.Style 1.0

import "qrc:/UICore/qml" as Ui
import "qrc:/UICore/qml/components/base" as Base
import "qrc:/UICore/qml/components/field" as Field
import "qrc:/UICore/qml/components/form" as Form
import "qrc:/UICore/qml/components/shell" as Shell
import "qrc:/UICore/qml/components/task" as TaskView
import "qrc:/UICore/qml/menus" as Menus
```

调用方不得导入 `internal` 或 `foundation` 路径。它们不是公共接口。

## 2. 先选择层级

| 需求 | 使用 |
| --- | --- |
| 普通静态页面或少量控件 | Base 组件 |
| 带标签、说明和输入控件的手工字段行 | `AppFieldBlock` |
| 手工组织多个字段并共享布局 | `AppFieldForm` / `AppFieldFormPane` |
| 渲染单个 `AppField` | `AppFieldControl` |
| 渲染 `AppForm` / `AppFormSection` | `AppFormContent` |
| 标准导航、左右面板和画布壳层 | `AppShell` |
| 表单式菜单面板 | `AppMenuPane` |
| 任务列表与进度 | `TaskManager` + `AppTaskPanel` |

没有字段 schema 的静态 UI 不创建 `AppField`。渲染组件只呈现状态和发送用户意图，业务状态继续由调用方或 C++ controller 持有。

## 3. Base 组件

| 组件 | 用途 |
| --- | --- |
| `AppText` / `AppIcon` | 使用主题排版和图标语义显示内容 |
| `AppButton` | 普通、主操作、危险或图标按钮 |
| `AppTextField` | 自由输入，或允许输入候选项之外的值 |
| `AppSelect` | 只能从候选项中选择的封闭选择 |
| `AppToggleControl` | 单个布尔开关 |
| `AppChoiceControl` | 少量互斥或多选项 |
| `AppSegmentedControl` | 少量并列模式切换 |
| `AppSliderControl` | 连续或步进数值 |
| `AppColorControl` | 颜色值选择 |
| `AppSurface` | 无标题的基础语义表面 |
| `AppBackdrop` | 页面或画布背景 |
| `AppPanel` | 带标题、操作和可折叠内容的面板 |
| `AppSection` | 页面内部较轻量的内容分组 |
| `AppScrollPane` | 统一滚动与边缘反馈 |
| `AppPopup` | 独立自定义弹层；下拉控件已经自行管理弹层 |
| `AppFieldBlock` | 标签、说明和控件组成的字段行 |

封闭选择：

```qml
property string region: "east"

Base.AppSelect {
    options: [
        { "label": "东区", "value": "east" },
        { "label": "西区", "value": "west" }
    ]
    value: region
    onValueSelected: region = nextValue
}
```

允许继续输入的候选值：

```qml
Base.AppTextField {
    text: "60"
    options: [30, 60, 90]
}
```

`readOnly` 表示内容可读但不可编辑；`enabled: false` 表示整个控件禁用。不要用禁用态替代只读态。

## 4. Field 与 Form

`BaseField` 保存值和约束，`AppField` 增加 UI 描述。`AppField.sourceField` 绑定外部 `BaseField` 后直接代理它，不复制状态。

单字段：

```qml
AppField {
    id: nameField
    key: "name"
    kind: AppField.Kind.TextField
    label: "名称"
}

Field.AppFieldControl {
    fieldData: nameField
    onValueEdited: nameField.value = value
}
```

完整表单：

```qml
Form.AppFormContent {
    formData: appForm
    onFieldEdited: appForm.setFieldValue(fieldKey, value)
}
```

选择 renderer 的规则：

- `EnumType` 或 `allowCustomValue == false` 的 `SelectEditor` 使用 `AppSelect`。
- Text、Int、Double 且 `allowCustomValue == true` 时使用带候选项的 `AppTextField`。
- 不直接调用 `components/field/internal` 中的 renderer。

## 5. Shell、菜单与任务

优先整体使用 `AppShell`。`AppRailButton`、`AppTopbarIconButton`、`AppLeftPane`、`AppInspectorPane` 和 `AppSelectionOverlay` 是壳层组成件，只在自定义壳层时单独使用。

标准壳层状态由 `AppShellController` 持有，`AppDrawer` 注册到 controller，`AppShell` 绑定 controller 状态并把 `...Requested` 信号回传。

`AppShell.drawers` 接收 `AppDrawer` 转换的数据，核心字段为：

| 字段 | 含义 |
| --- | --- |
| `key` / `label` / `iconName` | 稳定标识、标题和图标 |
| `leftPaneData` | 标准左侧列表面板数据 |
| `paneDelegateSource` | 自定义左侧面板地址 |
| `paneController` | 菜单或自定义面板 controller |

标准表单菜单使用 `AppMenuModel` + `AppMenuPane`。`AppMenuPane` 会把字段编辑交给 `paneController.handleFieldEdited()`，把操作交给 `paneController.handleAction()`；调用方不要在 QML 中再建立一份同步状态。

任务面板直接消费 `TaskManager`：

```qml
TaskView.AppTaskPanel {
    taskItems: taskManager.tasks
    activeTaskCount: taskManager.activeTaskCount
}
```

业务工具栏、时间线、地图、图层和业务对话框不放入 UICore；通过 `AppShell` 的内容插槽或上层应用组件注入。

## 6. 交互与兼容

- 交互信号使用 `...Requested`、`...Edited`、`...Triggered`；调用方负责把意图提交到状态所有者。
- Select、Segmented 和 Choice 支持方向键、`Home`、`End`、空格和回车。
- 弹层由所属控件负责打开、定位和收起，不在外部重复维护可见状态。
- 需要点击面板空白处清除焦点时，设置 `AppPanel.clearFocusOnBackgroundTap`。
- `AppIcon.animateColor` 和 `AppTextField.animateTextColor` 默认开启；颜色表达数据值时关闭对应动画。
- Style 属性使用 `UiStyle` 枚举，不传名称字符串或无语义裸数字。
- 公共 QML alias、C++ include 和枚举数值属于兼容接口；变更前先检查 `CHANGELIST.md`。
