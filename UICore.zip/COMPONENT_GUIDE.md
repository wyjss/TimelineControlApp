# UICore 组件使用指南

本文档用于选择公共组件和确认调用边界。属性的完整定义以源码和公共头文件为准，迁移信息见 [CHANGELIST.md](CHANGELIST.md)。

## 1. 使用前提

Qt Quick 应用链接 `UICore::Quick`，并在创建 `QQmlEngine` 前调用 `UICore::initialize()`。独立应用优先使用自带默认主题和 `AppShell` 的 `AppWindow`：

```qml
import "qrc:/UICore/qml" as Ui

Ui.AppWindow {
    visible: true
    shell.applicationTitle: qsTr("应用")
}
```

自定义应用窗口需要自行持有唯一主题：

```qml
import QtQuick.Controls 2.14
import "qrc:/UICore/qml/theme" as Theme

ApplicationWindow {
    property QtObject appTheme: Theme.AppTheme {}
}
```

常用导入：

```qml
import UICore.Fields 1.0
import UICore.Forms 1.0
import UICore.Style 1.0

import "qrc:/UICore/qml" as Ui
import "qrc:/UICore/qml/components/base" as Base
import "qrc:/UICore/qml/components/field" as Field
import "qrc:/UICore/qml/components/form" as Form
import "qrc:/UICore/qml/components/shell" as Shell
import "qrc:/UICore/qml/components/task" as TaskView
import "qrc:/UICore/qml/menus" as Menus
```

调用方不得导入 `internal` 或 `foundation` 路径。它们不是公共接口。

## 2. 先选择层级

| 需求 | 使用 |
| --- | --- |
| 普通静态页面或少量控件 | Base 组件 |
| 带标签、说明和输入控件的手工字段行 | `AppFieldBlock` |
| 手工组织多个字段并共享布局 | `AppFieldForm` / `AppFieldFormPane` |
| 渲染单个 `AppField` | `AppFieldControl` |
| 渲染 `AppForm` / `AppFormSection` | `AppFormContent` |
| 标准应用窗口与壳层 | `AppWindow` |
| 标准导航、左右面板和画布壳层 | `AppShell` |
| 横向、纵向导航条的公共容器 | `AppNavigationBar` |
| 顶部或底部横向菜单栏 | `AppTopNavigationBar` / `AppBottomNavigationBar` |
| 可定制的通用侧边栏 | `AppSidebar` |
| 侧边栏相邻的通用展开面板 | `AppSidebarPane` |
| 表单式菜单面板 | `AppMenuPane` |
| 任务列表与进度 | `TaskManager` + `AppTaskPanel` |

没有字段 schema 的静态 UI 不创建 `AppField`。渲染组件只呈现状态和发送用户意图，业务状态继续由调用方或 C++ controller 持有。

## 3. Base 组件

| 组件 | 用途 |
| --- | --- |
| `AppText` / `AppIcon` | 使用主题排版和图标语义显示内容 |
| `AppButton` | 普通、主操作、危险或图标按钮 |
| `AppTextField` | 自由输入，或允许输入候选项之外的值 |
| `AppSelect` | 只能从候选项中选择的封闭选择 |
| `AppToggleControl` | 单个布尔开关 |
| `AppChoiceControl` | 少量互斥或多选项 |
| `AppSegmentedControl` | 少量并列模式切换 |
| `AppSliderControl` | 连续或步进数值 |
| `AppColorControl` | 颜色值选择 |
| `AppSurface` | 无标题的基础语义表面 |
| `AppBackdrop` | 页面或画布背景 |
| `AppPanel` | 带标题、操作和可折叠内容的面板 |
| `AppSection` | 页面内部较轻量的内容分组 |
| `AppScrollPane` | 统一滚动与边缘反馈 |
| `AppPopup` | 独立自定义弹层；下拉控件已经自行管理弹层 |
| `AppFieldBlock` | 标签、说明和控件组成的字段行 |
| `AppAutoHideController` | 无外观的延迟展开与自动隐藏状态请求 |

封闭选择：

```qml
property string region: "east"

Base.AppSelect {
    options: [
        { "label": "东区", "value": "east" },
        { "label": "西区", "value": "west" }
    ]
    value: region
    onValueSelected: region = nextValue
}
```

`AppSelect.value` 由调用方持有。用户选择时组件只发送 `valueSelected(nextValue)`；调用方接受选择时应在处理器中提交新值，不提交时控件保持原值。

允许继续输入的候选值：

```qml
Base.AppTextField {
    text: "60"
    options: [30, 60, 90]
}
```

布尔开关直接使用原生 `checked` 和 `toggled()`：

```qml
property bool featureEnabled: false

Base.AppToggleControl {
    checked: featureEnabled
    onToggled: featureEnabled = checked
}
```

`readOnly` 表示内容可读但不可编辑；`enabled: false` 表示整个控件禁用。不要用禁用态替代只读态。

## 4. Field 与 Form

`BaseField` 保存值和约束，`AppField` 增加 UI 描述。`AppField.sourceField` 绑定外部 `BaseField` 后直接代理它，不复制状态。

单字段：

```qml
AppField {
    id: nameField
    key: "name"
    kind: AppField.Kind.TextField
    label: "名称"
}

Field.AppFieldControl {
    fieldData: nameField
    onValueEdited: nameField.value = value
}
```

完整表单：

```qml
Form.AppFormContent {
    formData: appForm
    onFieldEdited: appForm.setFieldValue(fieldKey, value)
}
```

选择 renderer 的规则：

- `EnumType` 或 `allowCustomValue == false` 的 `SelectEditor` 使用 `AppSelect`。
- Text、Int、Double 且 `allowCustomValue == true` 时使用带候选项的 `AppTextField`。
- 不直接调用 `components/field/internal` 中的 renderer。

## 5. Shell、菜单与任务

独立窗口优先使用 `AppWindow`，通过 `shell` 配置其中的 `AppShell`；已有宿主窗口或需要嵌入时直接使用 `AppShell`。`AppNavigationBar` 是横向、纵向导航条的公共底层；`AppTopNavigationBar`、`AppBottomNavigationBar` 是横向实现，`AppSidebar` 是纵向 Rail 实现，`AppSidebarPane` 是承载相邻展开内容的通用面板；`AppRailButton`、`AppLeftPane`、`AppInspectorPane` 和 `AppSelectionOverlay` 是更细的壳层组成件，只在自定义壳层时单独使用。

`AppShellController` 可持有 `activeNavigationKey`、`leftPaneOpen`、Inspector 等稳定壳层状态。导航项由应用直接提供给 `AppShell.navigationItems`；Shell 只发送导航和 Pane 状态请求，不注册菜单，也不决定点击导航后应打开 Pane、切换画布还是执行命令。

`AppNavigationBar` 提供 `orientation`、`leadingContent`、`content`、`trailingContent` 和 `itemDelegate`。设置 `content` 时使用调用方内容；未设置时由组件按 `orientation` 排列 `menuItems`，并使用派生组件提供的 `itemDelegate` 创建按钮；没有 delegate 时主体保持空白。`activeItemKey` 和 `itemTriggered(key)` 定义统一的受控菜单契约，具体按钮外观由派生组件实现。

`AppTopNavigationBar` 默认显示 `title` 和横向菜单，`AppBottomNavigationBar` 默认显示横向菜单，两者使用一致的边缘选中指示。`AppShell` 分别通过 `topMenuItems`、`activeTopMenuKey`、`topMenuItemRequested(key)` 与 `bottomMenuItems`、`activeBottomMenuKey`、`bottomMenuItemRequested(key)` 接入它们；底部栏在具有菜单、内容或操作时默认显示。`topBarContent` 或 `bottomBarContent` 会替换对应栏的默认菜单主体，`topBarActions` 和 `bottomBarActions` 设置 trailing 区域；应用需要其它顶部布局时，通过 `topNavigationBar` 覆盖 `leadingContent`、`content` 或 `trailingContent`。

```qml
shell.topMenuItems: [
    { "key": "overview", "label": qsTr("概览"), "iconName": "scene" }
]
shell.activeTopMenuKey: controller.topKey
shell.bottomMenuItems: [
    { "key": "tasks", "label": qsTr("任务"), "iconName": "background-task" }
]
shell.activeBottomMenuKey: controller.bottomKey
```

`AppSidebar` 将 `headerContent`、`footerContent` 分别映射到公共的 leading、trailing 插槽，并提供基于 `AppRailButton` 的纵向默认菜单和自身右侧分隔线。设置 `content` 时完全使用调用方内容；未设置时由 `menuItems` 生成默认图标菜单。默认菜单通过 `activeItemKey` 表达可选的互斥状态，通过 `itemTriggered(key)` 统一发送单击意图，因此也可用于不保持选中状态的动作项。

```qml
Shell.AppSidebar {
    menuItems: [
        { "key": "layers", "label": qsTr("图层"), "iconName": "layers" },
        { "key": "resources", "label": qsTr("资源"), "iconName": "resources" }
    ]
    activeItemKey: controller.activeKey
    onItemTriggered: function(key) {
        controller.triggerSidebarItem(key)
    }
}
```

`AppSidebar` 不绑定或创建展开面板。点击侧栏项目后是打开面板、切换画布还是执行一次命令，由 `itemTriggered(key)` 的处理方决定。Sidebar 自身通过 `opened`、`autoHideEnabled`、`autoHideSuspended`、`autoHideTriggerActive`、`revealDelay` 和 `hideDelay` 独立控制显隐；状态仍由调用方持有，组件通过 `openRequested(bool)` 发送变更请求。`occupiedWidth` 表示 Sidebar 当前应占用的布局宽度，自动隐藏模式下即使已经展开也为 `0`。

`AppSidebarPane` 通过 `content` 承载任意面板内容，并负责相邻面板的位置、显隐动画、悬停桥接和可选自动隐藏；它不限定内容外观，`AppMenuPane` 只是可装入其中的一种内容。`opened` 仍由调用方持有，组件只通过 `openRequested(bool)` 发送状态请求：

```qml
Shell.AppSidebarPane {
    anchors.fill: parent
    anchorItem: sidebar
    gap: theme.shell.shellOverlayMargin
    opened: controller.paneOpened
    autoHideEnabled: controller.paneAutoHide
    autoHideTriggerActive: sidebar.effectiveHovered
    content: Component {
        Menus.AppMenuPane {
            paneController: controller.activePaneController
        }
    }
    onOpenRequested: function(opened) {
        controller.paneOpened = opened
    }
}
```

`anchorItem` 与 `AppSidebarPane` 应处于同一个父级坐标系；面板通过 `gap` 始终贴近该锚点的内侧边缘。`autoHideSuspended` 可在画布拖拽等交互期间暂停自动隐藏，`autoHideTriggerActive` 可合并侧栏或其它外部触发区的悬停状态。面板自身和间隔桥接区的鼠标状态由 `AppSidebarPane` 处理，延迟判断交给 `AppAutoHideController`；方向通过 `edge` 设置，当前支持左、右侧。

`AppShell.sidebar` 暴露窗口左侧实际使用的 `AppSidebar`，`sidebarOpen` 持有其显隐状态，`sidebarOpenRequested(bool)` 回传自动显隐请求。应用通过 `shell.sidebar.autoHideEnabled` 独立启用 Sidebar 自动隐藏；`AppShell.leftContentInset` 只读取 `sidebar.occupiedWidth`，不受 Pane 自动隐藏影响。`sidebarAutoHideTriggerActive` 用于扩展 Sidebar 的触发范围，`sidebarAutoHideSuspended` 用于暂停 Sidebar 自动隐藏；Shell 已提供窗口左边缘鼠标触发区。

`AppShell.sidebarPane` 暴露相邻的 `AppSidebarPane`。`leftPanelAutoHide`、`leftPanelAutoHideSuspended` 和 `leftPanelAutoHideTriggerActive` 只控制 Pane，不改变 Sidebar 是否浮动或占用画布宽度。Sidebar 与 Pane 可以分别固定、手动关闭或自动隐藏；不要用 Gallery 内的重复侧栏代替真实壳层组件。

`AppShell.navigationItems` 只消费 `key`、`label`、`iconName` 等导航显示字段。`activeNavigationKey` 表达当前选中项，点击只发送 `navigationRequested(key)`。应用通过 `leftPaneContent` 注入一个已经配置完整的 Pane `Component`，并通过 `leftPanelWidth` 设置其宽度；`leftPaneOpen` 与 `leftPaneOpenRequested(bool)` 独立控制 Pane：

```qml
shell.navigationItems: [
    { "key": "components", "label": qsTr("组件"), "iconName": "workflow" }
]
shell.activeNavigationKey: controller.activeNavigationKey
shell.leftPaneOpen: controller.leftPaneOpen
shell.leftPanelWidth: menuModel.paneWidth
shell.leftPaneContent: Component {
    Menus.AppMenuPane {
        menuKey: "components"
        paneController: menuModel
    }
}
```

标准表单菜单使用 `AppMenuModel` + `AppMenuPane`。`AppMenuPane` 会把字段编辑交给 `paneController.handleFieldEdited()`，把操作交给 `paneController.handleAction()`；`menuKey` 只用于标识操作来源，调用方不要在 QML 中再建立一份同步状态。

任务面板直接消费 `TaskManager`：

```qml
TaskView.AppTaskPanel {
    taskItems: taskManager.tasks
    activeTaskCount: taskManager.activeTaskCount
}
```

业务工具栏、时间线、地图、图层和业务对话框不放入 UICore；通过 `AppShell` 的内容插槽或上层应用组件注入。

## 6. 交互与兼容

- 交互信号使用 `...Requested`、`...Edited`、`...Triggered`；调用方负责把意图提交到状态所有者。
- `AppToggleControl` 直接使用 Qt `Switch` 的 `checked` 和无参数 `toggled()`；处理信号时读取 `checked`。
- `AppSelect` 使用 Qt `ComboBox` 原生键盘语义：弹层关闭时方向键和 `Home`/`End` 直接选择，空格开关弹层；弹层打开时方向键移动高亮，空格或回车确认，Escape 关闭。
- Segmented 和 Choice 支持方向键、`Home`、`End`、空格和回车。
- 弹层由所属控件负责打开、定位和收起，不在外部重复维护可见状态。
- 需要点击面板空白处清除焦点时，设置 `AppPanel.clearFocusOnBackgroundTap`。
- `AppIcon.animateColor` 和 `AppTextField.animateTextColor` 默认开启；颜色表达数据值时关闭对应动画。
- Style 属性使用 `UiStyle` 枚举，不传名称字符串或无语义裸数字。
- 公共 QML alias、C++ include 和枚举数值属于兼容接口；变更前先检查 `CHANGELIST.md`。
