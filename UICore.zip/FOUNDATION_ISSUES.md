# UICore Foundation 问题跟踪

本文档记录 Foundation 层已确认的问题和处理状态。

## FIELD-001 `BaseField::defaultValue` 缺少实际契约

**状态：** 待处理

`BaseField::defaultValue` 当前只保存一份独立值，不参与字段初始化、重置、修改状态判断、校验、序列化或 Forms 适配。

**影响：** 公共 API 暴露了没有行为语义的状态，调用方无法判断它应由 UICore 使用，还是仅作为业务元数据保存。

**验收标准：**

- 若 UICore 不负责字段重置和修改状态，删除 `defaultValue` property、getter/setter、信号和成员。
- 若决定保留，必须同时定义并实现 `resetToDefault()`、修改状态判断及明确的数据流。
- 不为尚未确定的未来能力保留无调用方的公共状态。
