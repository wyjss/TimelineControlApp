#pragma once

namespace UICore {

//! 注册 UICore 内置 QML 与图标资源，创建 QQmlEngine 前调用一次。
void initialize();

} // namespace UICore
