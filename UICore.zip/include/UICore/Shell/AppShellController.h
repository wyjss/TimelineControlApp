#pragma once

#include <QObject>
#include <QPointer>
#include <QString>
#include <QVariant>
#include <QVariantMap>

namespace UICore {

class AppShellController : public QObject
{
    Q_OBJECT

    //! 当前激活的导航键。
    Q_PROPERTY(QString activeNavigationKey READ activeNavigationKey WRITE setActiveNavigationKey NOTIFY activeNavigationKeyChanged FINAL)
    //! 左侧 detail pane 的显隐状态。
    Q_PROPERTY(bool leftPaneOpen READ leftPaneOpen WRITE setLeftPaneOpen NOTIFY leftPaneOpenChanged FINAL)
    //! 右侧 inspector 的显隐状态。
    Q_PROPERTY(bool rightPanelOpen READ rightPanelOpen WRITE setRightPanelOpen NOTIFY rightPanelOpenChanged FINAL)
    //! 左侧 detail pane 是否允许自动收起。
    Q_PROPERTY(bool leftPanelAutoHide READ leftPanelAutoHide WRITE setLeftPanelAutoHide NOTIFY leftPanelAutoHideChanged FINAL)
    //! 画布交互状态，用于驱动壳层行为。
    Q_PROPERTY(QString canvasInteractionState READ canvasInteractionState WRITE setCanvasInteractionState NOTIFY canvasInteractionStateChanged FINAL)
    //! 右侧 inspector 的正式对象桥接。
    Q_PROPERTY(QObject *inspectorObject READ inspectorObject WRITE setInspectorObject NOTIFY inspectorObjectChanged FINAL)
    //! 右侧 inspector 数据。
    Q_PROPERTY(QVariant inspectorData READ inspectorData WRITE setInspectorData NOTIFY inspectorDataChanged FINAL)
    //! 底部 selection overlay 数据。
    Q_PROPERTY(QVariantMap selectionData READ selectionData WRITE setSelectionData NOTIFY selectionDataChanged FINAL)

public:
    explicit AppShellController(QObject *parent = nullptr);

    QString activeNavigationKey() const;
    void setActiveNavigationKey(const QString &key);

    bool leftPaneOpen() const;
    void setLeftPaneOpen(bool open);

    bool rightPanelOpen() const;
    void setRightPanelOpen(bool open);

    bool leftPanelAutoHide() const;
    void setLeftPanelAutoHide(bool enabled);

    QString canvasInteractionState() const;
    void setCanvasInteractionState(const QString &state);

    QObject *inspectorObject() const;
    void setInspectorObject(QObject *inspectorObject);

    QVariant inspectorData() const;
    void setInspectorData(const QVariant &data);

    QVariantMap selectionData() const;
    void setSelectionData(const QVariantMap &data);

    //! 供 QML 切换右侧 inspector 面板。
    Q_INVOKABLE void toggleRightPanel();
    //! 供 QML 把交互动作回传给 C++。
    Q_INVOKABLE virtual void handleUiAction(const QString &actionId, const QVariantMap &payload);

signals:
    void activeNavigationKeyChanged();
    void leftPaneOpenChanged();
    void rightPanelOpenChanged();
    void leftPanelAutoHideChanged();
    void canvasInteractionStateChanged();
    void inspectorObjectChanged();
    void inspectorDataChanged();
    void selectionDataChanged();

    //! 对外转发壳层动作，便于业务层继续扩展。
    void uiActionTriggered(const QString &actionId, const QVariantMap &payload);

private:
    void syncInspectorObject(QObject *inspectorObject);

    QString m_activeNavigationKey;
    bool m_leftPaneOpen = true;
    bool m_rightPanelOpen = false;
    bool m_leftPanelAutoHide = false;
    QString m_canvasInteractionState = QStringLiteral("idle");
    QPointer<QObject> m_inspectorObject;
    QVariant m_inspectorData;
    QVariantMap m_selectionData;
};

} // namespace UICore

Q_DECLARE_METATYPE(UICore::AppShellController *)
