# UICore 上层同步变更清单

本文档只记录需要上层应用同步修改的代码用法变化。新增破坏性 API 或调整公共 QML/C++ 用法时，必须在同一次修改中追加记录，最新变更放在最前。

## 2026-07-25 交互焦点与只读状态

`AppSelect` 新增 `readOnly`，只读选择字段不再退化为禁用态。只读控件保留内容可读性，但不进入编辑焦点链，也不会打开选项弹层。

Toggle、Segmented、Choice 和 Slider 补齐键盘焦点反馈；Select、Segmented 和 Choice 支持方向键、`Home`、`End`、空格和回车操作。公共调用方式不变。

## 2026-07-25 主题颜色与布局 Token

默认主题拉开了 Window、Canvas、Surface 和 Section 的中性表面层级，并将 Info 调整为青色语义，避免与蓝色 Highlight 混淆。

输入、选择、选项和开关等交互控件改用独立的 `controlBorder`。表单和 Gallery 的响应式断点统一读取 `AppMetrics`。替换默认主题的上层应用需要补充：

```qml
readonly property color controlBorder: "#40566d"

readonly property int layoutBreakpointSm: 700
readonly property int layoutBreakpointMd: 850
readonly property int layoutBreakpointLg: 1050
```

`AppFieldForm`、`AppFieldFormPane` 和 `AppFormContent` 的默认横向布局断点现在使用 `layoutBreakpointMd`。

## 2026-07-24 表单字段默认外观

`AppForm` 和 `AppFormSection` 新增 `fieldAppearance`，用于统一设置 TextField 和 Select 字段的默认输入外观。字段未显式设置 `appearance` 时按 Section、Form、`Filled` 的顺序继承：

```qml
AppForm {
    fieldAppearance: UiStyle.ControlAppearance.Ghost
}
```

单个 `AppField.appearance` 仍具有最高优先级。`surfaceTone`、`textTone` 和按钮 `variant` 不参与该继承链。

## 2026-07-24 主题 Token 改为严格依赖

UICore 不再为颜色、尺寸、字体、圆角、动效和控件样式提供组件级回退值，也不再在 `density` 缺少 Token 时兼容读取 `metrics`。

当前 `Theme.AppTheme` 同时作为标准主题和默认主题，没有新增第二套皮肤。上层应用必须继续在窗口提供：

```qml
ApplicationWindow {
    property QtObject appTheme: Theme.AppTheme {}
}
```

未设置 `appTheme`，或替换主题时缺少 `colors`、`density`、`metrics`、`shell`、`shape`、`motion`、`typography`、`controlStyles`、`icons`、`z` 中的必需 Token，将直接产生 QML 错误，不再静默套用组件内置值。

## 2026-07-24 输入控件禁用主题色

输入类控件不再通过 `AppControlStyles.inputChromeSpec().disabledOpacity` 表达禁用状态，该字段已删除。自定义主题应在 `colors` 中提供以下语义 Token：

```qml
readonly property color disabledFill: "#151b23"
readonly property color disabledBorder: "#273445"
readonly property color disabledText: "#68758a"
```

这些 Token 现在是主题必需项，未提供时会直接产生 QML 错误。组件公共调用方式不变。

## 2026-07-23 可编辑候选值

`BaseField` 和 `AppField` 新增 `allowCustomValue`。默认值为 `false`，现有封闭选择行为不变。

Text、Int 和 Double 字段需要显示候选值并允许继续编辑时，使用：

```cpp
field->setValueType(UICore::BaseField::IntType);
field->setEditorHint(UICore::BaseField::SelectEditor);
field->setOptions({30, 60, 90});
field->setAllowCustomValue(true);
```

`AppField` 同步新增 `valueType` 代理。手动输入会按 `valueType` 写回字符串、整数或浮点数；无效数值不会写回。

`EnumType` 和 `allowCustomValue == false` 的 `SelectEditor` 继续使用 `AppSelect`，只能从 `options` 选择。允许自定义值的字段使用 `AppTextField`，候选项只提供输入建议。

## 2026-07-23 通用字段渲染层

`AppFormField` 已提升为可独立使用的通用字段 `AppField`，不保留旧类型。

### C++

```cpp
#include <UICore/Fields/AppField.h>
```

| 原用法 | 新用法 |
| --- | --- |
| `UICore::AppFormField` | `UICore::AppField` |
| `UICore::UiForm::FieldKind::TextField` | `UICore::AppField::Kind::TextField` |
| `<UICore/Forms/AppFormField.h>` | `<UICore/Fields/AppField.h>` |

`AppField::formNodeKind` 已删除；Form 节点类型只由 `AppForm` 和 `AppFormSection` 提供。`AppForm`、`AppFormSection` 的字段接口相应改为接收 `AppField *`。

`AppField` 不再复制 `BaseField` 的公共字段状态。默认构造时使用内部 `BaseField`；调用 `setSourceField()` 后，`valueType`、`key`、`label`、`subtitle`、`value`、`options`、`allowCustomValue`、`placeholderText`、`readOnly`、`minimum`、`maximum`、`stepSize` 和 `suffix` 直接读写外部字段。

以下接口已删除：

- `autoCommitToSource`
- `syncFromSourceField()`
- `commitToSourceField()`
- `copyFromBaseField()`
- `fromBaseField()`

原 `fromBaseField()` 调用改为：

```cpp
auto *field = new UICore::AppField(parent);
field->setSourceField(baseField);
```

### QML

`AppField` 已注册为可创建类型：

```qml
import UICore.Fields 1.0
import "qrc:/UICore/qml/components/field" as Field

AppField {
    id: nameField
    kind: AppField.Kind.TextField
    label: "名称"
}

Field.AppFieldControl {
    fieldData: nameField
    onValueEdited: nameField.value = value
}
```

| 原用法 | 新用法 |
| --- | --- |
| `UiForm.FieldKind.TextField` | `AppField.Kind.TextField` |
| `qml/components/form/renderers/*` | 由 `AppFieldControl` 内部选择，不再直接使用 |
| `AppFormContent.objectPayload()` | 直接向 `actionTriggered` 提供对象 payload |

`AppFormContent` 已改为复用 `AppFieldControl`，完整表单的 `fieldEdited` 和 `actionTriggered` 对外接口不变。

## 2026-07-23 编译库收敛

编译 target 收敛为两个：

- `UICore::Core`：公共 C++ 类型。
- `UICore::Quick`：QML、主题、图标和资源初始化，并公开依赖 `UICore::Core`。

Qt Quick 应用修改链接目标：

```cmake
target_link_libraries(MyApp PRIVATE UICore::Quick)
```

原 `UICore::Foundation`、`UICore::Forms`、`UICore::Shell`、`UICore::Task` 和 `UICore::UICore` target 已删除。仅使用 C++ 模型且不调用 `UICore::initialize()` 的代码可以链接 `UICore::Core`。

C++ 命名空间、公共头文件、QML 资源路径和 `UICore::initialize()` 用法不变。

## 2026-07-23 无效 normalize 辅助函数清理

### C++

`BaseField::setValueType()` 和 `BaseField::setEditorHint()` 不再把越界枚举整数静默修正为 `InvalidType` 或 `AutoEditor`。调用方必须传入已定义的枚举值；反序列化得到的原始整数应在数据边界完成校验。

内部的 `normalizeValueType()` 和 `normalizeEditorHint()` 已删除。

### QML

| 已删除或更名 | 替代用法 |
| --- | --- |
| `AppBridgeUtils.normalizeFieldValue()` | `AppBridgeUtils.normalizedValue()` |
| `AppFormContent.normalizeFieldValue()` | 直接发送字段值，由组件统一处理 `undefined` |
| `AppFormContent.normalizeActionPayload()` | `AppFormContent.objectPayload()` |
| `AppMenuPane.normalizedValue()` | 由 `handleFieldEdited()` 统一处理 |
| `AppColorControl.normalizedDialogColor()` | 内部直接解析并设置对话框颜色 |

## 2026-07-23 通用视觉语义角色枚举化

`SurfaceTone`、`TextTone` 和 `TypographyRole` 已加入 `UiStyleEnums.h`。皮肤继续通过主题 Token 替换各角色的值，但不能再通过任意名称字符串增加公共角色。

### QML

以下公共视觉语义改为 `UiStyle` 枚举：

| 原用法 | 新用法 |
| --- | --- |
| `surfaceTone: "section"` | `surfaceTone: UiStyle.SurfaceTone.Section` |
| `textTone: "primary"` | `textTone: UiStyle.TextTone.Primary` |
| `styleRole: "bodyM"` | `styleRole: UiStyle.TypographyRole.BodyM` |
| `titleRole: "sectionTitle"` | `titleRole: UiStyle.TypographyRole.SectionTitle` |

对应 QML 属性由 `string` 改为 `int`，包括基础组件的 `surfaceTone`、`AppText.textTone/styleRole`、Pane 的 `titleRole/subtitleRole` 及 `AppFieldBlock` 的文本角色属性。Forms、Shell 等动态对象中的同名字段也必须提供对应枚举整数。

以下兼容或中间属性已删除：

| 已删除属性 | 替代用法 |
| --- | --- |
| `AppFieldBlock.labelTone` | `AppFieldBlock.labelTextTone` |
| `AppFieldBlock.subtitleTone` | `AppFieldBlock.subtitleTextTone` |
| `AppPopup.resolvedSurfaceTone` | `AppPopup.surfaceTone` |
| `AppTextField.resolvedSurfaceTone` | `AppTextField.surfaceTone` |
| `AppText.resolvedTextTone` | `AppText.textTone` |
| `AppTheme.textToneColors` | 覆盖主题 `colors` 中的对应 Token |

颜色、尺寸、字体、圆角和动画等主题内部 Token 名称仍使用字符串。

### C++

`AppFormField` 接口类型迁移：

| 原类型 | 新类型 |
| --- | --- |
| `QString textTone` | `UICore::UiStyle::TextTone` |
| `QString surfaceTone` | `UICore::UiStyle::SurfaceTone` |

例如：

```cpp
field->setTextTone(UICore::UiStyle::TextTone::Primary);
field->setSurfaceTone(UICore::UiStyle::SurfaceTone::Section);
```

## 2026-07-23 Forms 枚举归位

Forms schema 枚举以 `UiFormEnums.h` 为唯一来源。旧 `qml/foundation/Enums.qml` 及其 `qmldir` 已删除，不提供兼容别名。

### QML

新增模块导入：

```qml
import UICore.Forms 1.0
```

类型迁移：

| 原用法 | 新用法 |
| --- | --- |
| `Enums.SurfaceMode.Section` | `UiForm.SurfaceMode.Section` |
| `Enums.FormFieldKind.TextField` | `UiForm.FieldKind.TextField` |
| `Enums.MenuBlockKind.Form` | `UiForm.MenuBlockKind.Form` |
| `Enums.FormNodeKind.Section` | `UiForm.NodeKind.Section` |

以下辅助函数已删除，调用方应直接提供对应枚举整数；实际消费位置通过比较或 `switch/default` 处理未知值：

- `Enums.normalizeSurfaceMode()`
- `Enums.normalizeFormFieldKind()`
- `Enums.normalizeMenuBlockKind()`
- `Enums.normalizeFormNodeKind()`

### C++

新增头文件：

```cpp
#include <UICore/Forms/UiFormEnums.h>
```

类型迁移：

| 原类型或接口 | 新类型 |
| --- | --- |
| `AppForm::SurfaceMode` | `UICore::UiForm::SurfaceMode` |
| `AppFormField::Kind` | `UICore::UiForm::FieldKind` |
| `int menuBlockKind` | `UICore::UiForm::MenuBlockKind` |
| `int formNodeKind` | `UICore::UiForm::NodeKind` |

枚举使用强作用域语法，例如：

```cpp
UICore::UiForm::SurfaceMode::Section
UICore::UiForm::FieldKind::TextField
```

## 2026-07-23 通用 Style 枚举统一

### QML

新增模块导入：

```qml
import UICore.Style 1.0
```

通用 Style 枚举改为 `UiStyle.<Enum>.<Value>`：

| 原用法 | 新用法 |
| --- | --- |
| `Enums.LayoutMode.Horizontal` | `UiStyle.LayoutMode.Horizontal` |
| `Enums.ControlAppearance.Ghost` | `UiStyle.ControlAppearance.Ghost` |
| `Enums.ButtonVariant.Primary` | `UiStyle.ButtonVariant.Primary` |
| `Enums.ButtonSize.Medium` | `UiStyle.ButtonSize.Medium` |
| `Enums.ShapeRole.Panel` | `UiStyle.ShapeRole.Panel` |

以下公共属性由 `var` 改为 `int`，只接受对应枚举整数，不再接受名称字符串：

- `AppButton.variant`
- `AppButton.size`
- `AppSelect.appearance`
- `AppTextField.appearance`
- `AppFieldBlock.layoutMode`
- `AppFieldForm.layoutMode`
- `AppFieldFormPane.layoutMode`
- `AppSurface.shapeRole` 及其基础属性

调用方需要按以下方式迁移：

| 原用法 | 新用法 |
| --- | --- |
| `variant: "primary"` | `variant: UiStyle.ButtonVariant.Primary` |
| `size: "medium"` | `size: UiStyle.ButtonSize.Medium` |
| `appearance: "ghost"` | `appearance: UiStyle.ControlAppearance.Ghost` |
| `layoutMode: "horizontal"` | `layoutMode: UiStyle.LayoutMode.Horizontal` |
| `shapeRole: "panel"` | `shapeRole: UiStyle.ShapeRole.Panel` |
| `shapeRole: undefined` | 省略赋值或使用 `UiStyle.ShapeRole.Auto` |

Forms schema、Shell 配置及其他动态对象中的上述字段也必须提供枚举整数。外部 JSON 若仍使用名称字符串，应在上层应用的数据适配层转换后再传入 UICore。

以下通用 Style 辅助函数已删除，调用方应直接使用枚举，并在实际消费位置通过 `switch/default` 处理默认行为：

- `Enums.normalizeLayoutMode()`
- `Enums.normalizeAppearance()`
- `Enums.normalizeButtonVariant()`
- `Enums.normalizeButtonSize()`
- `Enums.normalizeShapeRole()`
- `AppFormContent.layoutModeName()`

以下只读中间属性已删除：

| 原属性 | 替代用法 |
| --- | --- |
| `AppButton.resolvedVariant` | `AppButton.variant` |
| `AppButton.resolvedSize` | `AppButton.size` |
| `AppSelect.resolvedAppearance` | `AppSelect.appearance` |
| `AppTextField.resolvedAppearance` | `AppTextField.appearance` |
| `AppSurface.resolvedShapeRole` | `AppSurface.shapeRole` |
| `AppFieldBlock.resolvedLayoutMode` | `AppFieldBlock.layoutMode` |
| `AppFieldBlock.resolvedLayoutModeName` | 根据 `AppFieldBlock.horizontalMode` 判断 |
| `AppFieldForm.resolvedLayoutModeValue` | `AppFieldForm.layoutMode` |
| `AppFieldForm.resolvedLayoutModeName` | `AppFieldForm.resolvedLayoutMode` |

### C++

新增头文件：

```cpp
#include <UICore/Style/UiStyleEnums.h>
```

类型迁移：

| 原类型 | 新类型 |
| --- | --- |
| `AppForm::LayoutMode` | `UICore::UiStyle::LayoutMode` |
| `AppFormSection::LayoutMode` | `UICore::UiStyle::LayoutMode` |
| `AppFormField::Appearance` | `UICore::UiStyle::ControlAppearance` |
| `AppFormField::Variant` | `UICore::UiStyle::ButtonVariant` |

枚举使用强作用域语法，例如：

```cpp
UICore::UiStyle::LayoutMode::Horizontal
UICore::UiStyle::ButtonVariant::Ghost
```

原 `GhostVariant` 更名为 `Ghost`，未提供旧 API 兼容别名。

C++ Forms setter 不再修正非法枚举整数。上层应传入已定义的 `UiStyle` 枚举值；视觉层在实际 `switch` 的 `default` 分支提供安全样式。

### 初始化

QML 引擎创建前必须调用：

```cpp
UICore::initialize();
```

该函数会注册 `UICore.Style 1.0` 和 `UICore.Forms 1.0`；已有此初始化调用的应用无需调整。
